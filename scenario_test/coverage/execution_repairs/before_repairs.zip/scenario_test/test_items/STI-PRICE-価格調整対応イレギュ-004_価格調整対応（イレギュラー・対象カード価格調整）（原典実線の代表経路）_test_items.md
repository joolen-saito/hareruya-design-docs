<!-- generated-by: hareruya-scenario-test-items -->
# 価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M03-01 | テスト項目化 | あり | 業務操作 |
| M03-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-30 | テスト項目化 | あり | CSV/帳票、金額整合 |
| M03-31 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-32 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-33 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-36 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-01 | テスト項目化 | あり | 業務操作 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「同じ商品コードの基準価格と販売価格が指定値に反映される」を確認する	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M03-01, M04-01, M03-30; 判定不能=1; 未実装指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M03-01, M04-01, M03-30; 判定不能=1; 未実装指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
3. 正常系#1: 顧客戦略チームが「情報取得として、突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定する。 希少なカードを仕入れた場合は状態や市場の状況に応じて 価格を新たに設定したり調整を行う」を実施する
   対象: 変更後価格=550円
4. 正常系#2: 顧客戦略チームが商品管理 — 商品検索・一覧で「同じ商品コードで商品一覧と在庫一覧を検索し、通販・支店・バックヤードを店舗および在庫区分で分けて現在庫数を記録し、価格調整の判断材料にする」を実施する
   対象: 変更後価格=550円
5. 正常系#3: 顧客戦略チームが商品管理 — 価格変更CSV登録で「価格変更対象の商品コードと価格をCSVで登録し、商品規格価格を再表示する（実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。）」を実施する
   対象: 変更後価格=550円
【操作後確認】
6. 最終業務状態「同じ商品コードの基準価格と販売価格が指定値に反映されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ商品コードの基準価格と販売価格が指定値に反映されること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 照合キー: 商品コード・店舗・在庫区分 / 出典: scenario_test/markdown/11_価格管理.md:75 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1438#sheet-4 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1440#sheet-4 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1441#sheet-4 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:1356#sheet-4 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:1357#sheet-4 / 設計差・留意点: 原典の価格/在庫履歴はHTML0204 sheet62で廃止記載。現HTMLの店舗別在庫を参照できる商品一覧と在庫一覧で現在値を確認する。 / 照合キー: 商品コード / 出典: scenario_test/markdown/11_価格管理.md:68 / scenario_test/markdown/11_価格管理.md:77 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:5679#sheet-42 / 設計差・留意点: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。 / 同じ商品コードの基準価格と販売価格が指定値に反映されること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-CARD-PRICE-004-R01
合格条件: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1"
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-002	-	データ更新	P1	正常系 #1: 顧客戦略チームが「情報取得として、突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定する。 希少なカードを仕入れた場合は状態や市場の状況に応じて 価格を新たに設定したり調整を行う」を行い「突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
2. 「情報取得として、突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定する。 希少なカードを仕入れた場合は状態や市場の状況に応じて 価格を新たに設定したり調整を行う」を実施する
【操作後確認】
3. 商品・カードで、突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01 の対応を記録する"	突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-004-R01
合格条件: 突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1"
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-003	M03-01,M04-01	業務操作	P1	正常系 #2: 顧客戦略チームが「同じ商品コードで商品一覧と在庫一覧を検索し、通販・支店・バックヤードを店舗および在庫区分で分けて現在庫数を記録し、価格調整の判断材料にする」を行い「同じ商品コードの店舗別・区分別在庫を参照でき、判断に使った基準日時と数量が記録される」を確認する	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md（商品管理 — 商品検索・一覧）
- この工程で通過する機能: M03-01 商品管理 — 商品検索・一覧 → M04-01 在庫管理 — 在庫検索/一覧"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md（商品管理 — 商品検索・一覧）
14. この工程で通過する機能: M03-01 商品管理 — 商品検索・一覧 → M04-01 在庫管理 — 在庫検索/一覧
【操作】
1. 管理画面で 商品管理 — 商品検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
3. 通過する機能: M03-01 → M04-01。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「同じ商品コードで商品一覧と在庫一覧を検索し、通販・支店・バックヤードを店舗および在庫区分で分けて現在庫数を記録し、価格調整の判断材料にする」を実施する
【操作後確認】
5. 商品管理 — 商品検索・一覧 で対象キーと 処理後の画面表示 を記録する"	同じ商品コードの店舗別・区分別在庫を参照でき、判断に使った基準日時と数量が記録されること。	"確認場所: 商品管理 — 商品検索・一覧（M03-01,M04-01） / 照合キー: 商品コード・店舗・在庫区分 / 出典: scenario_test/markdown/11_価格管理.md:75 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1438#sheet-4 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1440#sheet-4 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1441#sheet-4 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:1356#sheet-4 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:1357#sheet-4 / 設計差・留意点: 原典の価格/在庫履歴はHTML0204 sheet62で廃止記載。現HTMLの店舗別在庫を参照できる商品一覧と在庫一覧で現在値を確認する。
照合キー: 商品コード=ST-CARD-PRICE-004-R01
合格条件: 同じ商品コードの店舗別・区分別在庫を参照でき、判断に使った基準日時と数量が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1"
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-004	M03-30	CSV/帳票	P1	正常系 #3: 顧客戦略チームが「価格変更対象の商品コードと価格をCSVで登録し、商品規格価格を再表示する（実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。）」を行い「同じ商品コードの基準価格と販売価格が指定値に反映されること。 実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31が利用される」を確認する	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
- 必須入力欄: CSVファイル
- 解除条件:  価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
14. 必須入力欄: CSVファイル
【操作】
1. 管理画面で 商品管理 — 価格変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
3. 「価格変更対象の商品コードと価格をCSVで登録し、商品規格価格を再表示する（実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。）」を実施する
【操作後確認】
4. 商品管理 — 価格変更CSV登録 で対象キーと 登録が完了しました。 を記録する"	同じ商品コードの基準価格と販売価格が指定値に反映されること。 実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31が利用されること。	"確認場所: 商品管理 — 価格変更CSV登録（M03-30） / 照合キー: 商品コード / 出典: scenario_test/markdown/11_価格管理.md:68 / scenario_test/markdown/11_価格管理.md:77 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:5679#sheet-42 / 設計差・留意点: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。
照合キー: 商品コード=ST-CARD-PRICE-004-R01
合格条件: 同じ商品コードの基準価格と販売価格が指定値に反映されること。 実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31が利用されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 登録が完了しました。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1"
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-005	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #33 商品*2	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M03-01, M04-01, M03-30; 判定不能=1; 未実装指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
連鎖ID=DL-01
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M03-01, M04-01, M03-30; 判定不能=1; 未実装指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
3. 正常系#1: 顧客戦略チームが「情報取得として、突発的な事象により価格調整が必要な場合 主にSNSなどで、大会後や新商品発表、禁止改定やトレンドの変化など の情報収集を行い、急遽価格調整を行う必要があるカードを特定する。 希少なカードを仕入れた場合は状態や市場の状況に応じて 価格を新たに設定したり調整を行う」を実施する
   対象: 変更後価格=550円
4. 正常系#2: 顧客戦略チームが商品管理 — 商品検索・一覧で「同じ商品コードで商品一覧と在庫一覧を検索し、通販・支店・バックヤードを店舗および在庫区分で分けて現在庫数を記録し、価格調整の判断材料にする」を実施する
   対象: 変更後価格=550円
5. 正常系#3: 顧客戦略チームが商品管理 — 価格変更CSV登録で「価格変更対象の商品コードと価格をCSVで登録し、商品規格価格を再表示する（実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。）」を実施する
   対象: 変更後価格=550円
【操作後確認】
6. 最終業務状態「同じ商品コードの基準価格と販売価格が指定値に反映されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#32 価格/在庫履歴、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#33 商品*2をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #32 価格/在庫履歴 の成果物 #33 商品*2 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #33 商品*2
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #32 価格/在庫履歴 の成果物 #33 商品*2 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
価格管理 — 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）	STI-PRICE-004-006	M03-30	金額整合	P1	正常系 工程#3 判定: 基準価格変更の販売価格への反映	"元シナリオ: SCN-PRICE-価格調整対応イレギュ-004 価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ商品コードの基準価格と販売価格が指定値に反映されること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-004-r01 / 会員番号=ST-MEMBER-PRICE-004-R01 / 商品コード=ST-CARD-PRICE-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 対象商品コード=ST-CARD-PRICE-004-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
- 必須入力欄: CSVファイル
- 解除条件:  価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 判定用準備: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。
- 判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-42（セールフラグ無効時の基準/販売/買取価格更新）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
判定用具体値: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
14. 必須入力欄: CSVファイル
【操作】
1. 管理画面で 商品管理 — 価格変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-price-004-r01 / 商品コード=ST-CARD-PRICE-004-R01 / 価格変更CSV=ST-PRICE-PRICE-004-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-004-R01
3. 「価格変更対象の商品コードと価格をCSVで登録し、商品規格価格を再表示する（実施保留条件: 価格反映の画面を基準価格CSVへ一意には限定できないため、原典の価格変更CSV登録経路に限る補完。セールの場合はM03-31を利用する。）」を実施する
【操作後確認】
4. 商品管理 — 価格変更CSV登録 で対象キーと 登録が完了しました。 を記録する
具体照合: 入力CSVと更新後の商品規格詳細を商品ID・言語IDで照合し、更新後価格を1,200円・1,200円・500円の組と比較する。"	対象の商品ID・言語IDで、基準価格と販売価格がともに1,200円、買取価格が500円の状態であること。	"確認場所: 商品管理 — 価格変更CSV登録（M03-30） / 基準価格変更CSV・商品規格詳細
照合キー: 商品コード=ST-CARD-PRICE-004-R01
合格条件: 対象の商品ID・言語IDで、基準価格と販売価格がともに1,200円、買取価格が500円の状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 登録が完了しました。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-004-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-004-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-価格調整対応イレギュ-004_価格調整対応（イレギュラー・対象カード価格調整）（原典実線の代表経路）.md / 価格管理 / パターン4 / 経路1
判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-42（セールフラグ無効時の基準/販売/買取価格更新）
比較規則: 入力CSVと更新後の商品規格詳細を商品ID・言語IDで照合し、更新後価格を1,200円・1,200円・500円の組と比較する。"
```
