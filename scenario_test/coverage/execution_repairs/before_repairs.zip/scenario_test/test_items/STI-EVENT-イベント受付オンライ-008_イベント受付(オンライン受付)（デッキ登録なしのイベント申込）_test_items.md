<!-- generated-by: hareruya-scenario-test-items -->
# イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M13-06 | テスト項目化 | あり | 代替フロー、代替業務 |
| M13-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-001	-	業務経路	P1	代替系 経路全体 R04: 主要代替として「同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R04
4. 代替系#2: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R04
5. 代替系#3: お客様が「キャンペーン対象を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R04
【操作後確認】
6. 最終業務状態「同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。	"確認場所: 一覧・詳細に追加された対象データ / 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。 / 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:50 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。 / 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4"
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-002	M13-06	代替フロー	P1	代替系 #1: お客様が「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を行い「オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）
【操作】
1. 管理画面で イベント管理 — イベント申込検索 を開く
2. 対象データ: 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
3. 「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
【操作後確認】
4. イベント管理 — イベント申込検索 で対象キーと 処理後の画面表示 を記録する"	オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: イベント管理 — イベント申込検索（M13-06） / 一覧・詳細に追加された対象データ
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4"
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-003	-	代替業務	P1	代替系 #2: お客様が「キャンセル有無を行う」を行い「判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態である」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
2. 「キャンセル有無を行う」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。で、判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進めること。の実値と対象データ 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし の対応を記録する"	判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: 判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4"
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-004	-	代替フロー	P1	代替系 #3: お客様が「キャンペーン対象を行う」を行い「判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態である」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
2. 「キャンペーン対象を行う」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:50 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。で、判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進めること。の実値と対象データ 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし の対応を記録する"	判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:50 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: 判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4"
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-005	M13-06	代替業務	P1	代替系 A1 #1: 店舗チームが「イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）」を行い「イベントID=ST-EVENT-EVENT-002-R04 の処理結果が イベント管理 — イベント申込検索 に登録される」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
入力=商品コード=ST-CARD-EVENT-002-R04-A1 / オンライン受付=あり / デッキ登録設定=なし"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）
【操作】
1. 管理画面で イベント管理 — イベント申込検索 を開く
2. 対象データ: 商品コード=ST-CARD-EVENT-002-R04-A1 / オンライン受付=あり / デッキ登録設定=なし
3. 分岐条件「オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。」を成立させる
4. 「イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）」を実施する
【操作後確認】
5. イベント管理 — イベント申込検索 で対象キーと 処理後の画面表示 を記録する"	イベントID=ST-EVENT-EVENT-002-R04 の処理結果が イベント管理 — イベント申込検索 に登録されること。	"確認場所: イベント管理 — イベント申込検索（M13-06） / 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡した
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: イベントID=ST-EVENT-EVENT-002-R04 の処理結果が イベント管理 — イベント申込検索 に登録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4"
イベント管理 — イベント受付(オンライン受付)（デッキ登録なしのイベント申込）	STI-EVENT-008-006	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #14 イベント情報*1	"元シナリオ: SCN-EVENT-イベント受付オンライ-008 イベント受付(オンライン受付)（デッキ登録なしのイベント申込）
業務: イベント管理
経路ID: R04
経路種別: 主要代替
業務経路条件: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）
最終業務状態: 同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 オンライン受付あり・デッキ登録なしのイベント日程を用意して顧客が申し込む。
シードデータ: 担当者アカウント=st-user-event-002-r04 / 会員番号=ST-MEMBER-EVENT-002-R04 / 商品コード=ST-CARD-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R04 / イベント名=システムテスト大会 EVENT-002-R04 / 定員=8名 / 受付状態=受付前 / オンライン受付=あり / デッキ登録設定=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md データ連鎖 DL-01 / イベント管理 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
連鎖ID=DL-01
照合キー=イベントID=ST-EVENT-EVENT-002-R04"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「イベント設定=デッキ登録なし、キャンセルなし、キャンペーン対象外（原典本文 08_イベント管理.md R59–66「デッキ登録ありでイベント作成されている場合」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r04 / 商品コード=ST-CARD-EVENT-002-R04 / イベントID=ST-EVENT-EVENT-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / オンライン受付=あり / デッキ登録設定=なし
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R04
4. 代替系#2: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R04
5. 代替系#3: お客様が「キャンペーン対象を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R04
【操作後確認】
6. 最終業務状態「同じイベント申込を登録し、デッキ登録へ進まずイベント受付へ引き渡したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#13 イベント・大会申込、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-002-R04。
【操作】
産出工程の完了直後に#14 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #13 イベント・大会申込 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #14 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-002-R04
合格条件: 産出工程 #13 イベント・大会申込 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-008-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-008-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md / イベント管理 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-008_イベント受付(オンライン受付)（デッキ登録なしのイベント申込）.md データ連鎖 DL-01 / イベント管理 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
