<!-- generated-by: hareruya-scenario-test-items -->
# ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| F06-13 | テスト項目化 | あり | データ更新 |
| M08-10 | テスト項目化 | あり | メール/通知、データ更新 |
| M07-01 | テスト項目化 | あり | メール/通知 |
| M07-03 | テスト項目化 | あり | メール/通知 |
| F05-03 | テスト項目化 | あり | 照合 |
| F05-04 | テスト項目化 | あり | 照合 |
| F05-05 | テスト項目化 | あり | 照合 |
| F05-06 | テスト項目化 | あり | メール/通知 |
| M08-08 | テスト項目化 | あり | メール/通知 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 正常系#1: お客様がF05-03（ネット買取商品一覧）で「買取対象商品を選択しカートへ追加する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
4. 正常系#2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
5. 正常系#3: お客様がネット買取 — 買取手続き〜完了で「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
6. 正常系#4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
7. 正常系#5: お客様が会員 — オンライン本人確認で「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
8. 正常系#6: お客様が会員管理 — オンライン本人確認で「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
9. 正常系#7: 顧客戦略チームがネット買取管理 — 買取検索一覧で「本人確認受付通知メール受領を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
10. 正常系#8: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
11. 正常系#9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
12. 正常系#10: 顧客戦略チームが会員管理 — オンライン本人確認で「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
13. 正常系#11: 顧客戦略チームが会員管理 — 手動メール通知で「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
14. 正常系#12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
【操作後確認】
15. 最終業務状態「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: 照合キー: 商品コード・数量 / 出典: scenario_test/markdown/14_ネット買取.md:24 / excel_to_html/output/0305_基本設計仕様書(フロント_ネット買取).html:1995#sheet-7 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 受信したメール/通知の内容と受信日時 / 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-002	F05-03,F05-04,F05-05	照合	P1	正常系 #1: お客様が「買取対象商品を選択しカートへ追加する」を行い「えらんで買取とまとめて買取の対象商品が同じ申込カートに入り、商品・数量が選択内容と一致される」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/f05-03_front_online_purchase_buy_product_list.md（F05-03（ネット買取商品一覧））
- この工程で通過する機能: F05-03 F05-03（ネット買取商品一覧） → F05-04 F05-04（ネット買取商品詳細） → F05-05 F05-05（ネット買取カート）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/f05-03_front_online_purchase_buy_product_list.md（F05-03（ネット買取商品一覧））
14. この工程で通過する機能: F05-03 F05-03（ネット買取商品一覧） → F05-04 F05-04（ネット買取商品詳細） → F05-05 F05-05（ネット買取カート）
【操作】
1. フロント画面で F05-03（ネット買取商品一覧） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 通過する機能: F05-03 → F05-04 → F05-05。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「買取対象商品を選択しカートへ追加する」を実施する
【操作後確認】
5. F05-03（ネット買取商品一覧） で対象キーと 処理後の画面表示 を記録する"	えらんで買取とまとめて買取の対象商品が同じ申込カートに入り、商品・数量が選択内容と一致されること。	"確認場所: F05-03（ネット買取商品一覧）（F05-03,F05-04,F05-05） / 照合キー: 商品コード・数量 / 出典: scenario_test/markdown/14_ネット買取.md:24 / excel_to_html/output/0305_基本設計仕様書(フロント_ネット買取).html:1995#sheet-7
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: えらんで買取とまとめて買取の対象商品が同じ申込カートに入り、商品・数量が選択内容と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f05-03_front_online_purchase_buy_product_list.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-003	-	データ更新	P1	正常系 #2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を行い「カート内の買取希望の商品を確認し、買取依頼処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
2. 「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
【操作後確認】
3. 商品で、カート内の買取希望の商品を確認し、買取依頼処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 の対応を記録する"	カート内の買取希望の商品を確認し、買取依頼処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: カート内の買取希望の商品を確認し、買取依頼処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-004	F05-06	メール/通知	P1	正常系 #3: お客様が「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を行い「買取依頼処理が完了すると システムからメールが顧客宛に送付されることを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md（ネット買取 — 買取手続き〜完了）
- 必須入力欄: ご職業 / 生年月日 / 銀行名 / 支店名 / 口座種別 / 口座番号 / 口座名義 / 個口数 / 自動承諾 / 適格請求書発行事業者の登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md（ネット買取 — 買取手続き〜完了）
14. 必須入力欄: ご職業 / 生年月日 / 銀行名 / 支店名 / 口座種別 / 口座番号 / 口座名義 / 個口数 / 自動承諾 / 適格請求書発行事業者の登録番号
【操作】
1. フロント画面で ネット買取 — 買取手続き〜完了 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
【操作後確認】
4. ネット買取 — 買取手続き〜完了 で対象キーと 処理後の画面表示 を記録する"	買取依頼処理が完了すると システムからメールが顧客宛に送付されることを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: ネット買取 — 買取手続き〜完了（F05-06） / 受信したメール/通知の内容と受信日時
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 買取依頼処理が完了すると システムからメールが顧客宛に送付されることを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-005	-	データ更新	P1	正常系 #4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を行い「買取希望のカードを顧客が晴れる屋に郵送することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
2. 「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
【操作後確認】
3. カードで、買取希望のカードを顧客が晴れる屋に郵送することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 の対応を記録する"	買取希望のカードを顧客が晴れる屋に郵送することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 買取希望のカードを顧客が晴れる屋に郵送することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-006	F06-13	データ更新	P1	正常系 #5: お客様が「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を行い「PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/f06-13_front_member_mypage_online_identification.md（会員 — オンライン本人確認）
- 必須入力欄: 撮影する身分証の種類 / 撮影画像（本人写真・身分証オモテ・ウラ等） / 最新画像であることへの同意"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/f06-13_front_member_mypage_online_identification.md（会員 — オンライン本人確認）
14. 必須入力欄: 撮影する身分証の種類 / 撮影画像（本人写真・身分証オモテ・ウラ等） / 最新画像であることへの同意
【操作】
1. フロント画面で 会員 — オンライン本人確認 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
【操作後確認】
4. 会員 — オンライン本人確認 で対象キーと 処理後の画面表示 を記録する"	PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 会員 — オンライン本人確認（F06-13） / 照合/査定結果（一致・可否）と後続処理の可否
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f06-13_front_member_mypage_online_identification.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-007	M08-10	メール/通知	P1	正常系 #6: お客様が「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を行い「本人確認作業が完了すると、 本人確認受付メールが送付されることを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）
【操作】
1. 管理画面で 会員管理 — オンライン本人確認 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
【操作後確認】
4. 会員管理 — オンライン本人確認 で対象キーと 処理後の画面表示 を記録する"	本人確認作業が完了すると、 本人確認受付メールが送付されることを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: 会員管理 — オンライン本人確認（M08-10） / 受信したメール/通知の内容と受信日時
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 本人確認作業が完了すると、 本人確認受付メールが送付されることを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-008	M07-01	メール/通知	P1	正常系 #7: 顧客戦略チームが「本人確認受付通知メール受領を行う」を行い「本人確認受付通知メールを受領することを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘6件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘6件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）
【操作】
1. 管理画面で ネット買取管理 — 買取検索一覧 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認受付通知メール受領を行う」を実施する
【操作後確認】
4. ネット買取管理 — 買取検索一覧 で対象キーと 処理後の画面表示 を記録する"	本人確認受付通知メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: ネット買取管理 — 買取検索一覧（M07-01） / 受信したメール/通知の内容と受信日時
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 本人確認受付通知メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-009	M07-03	メール/通知	P1	正常系 #8: 顧客戦略チームが「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を行い「お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 登録が完了しました。 / 実在庫登録が完了しました。 を記録する"	お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 送信されたメール/通知の内容と送信状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 登録が完了しました。 / 実在庫登録が完了しました。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-010	-	データ更新	P1	正常系 #9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を行い「身分証の内容に問題があったり、登録情報に問題がないか確認することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
2. 「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、身分証の内容に問題があったり、登録情報に問題がないか確認することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 の対応を記録する"	身分証の内容に問題があったり、登録情報に問題がないか確認することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 身分証の内容に問題があったり、登録情報に問題がないか確認することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-011	M08-10	データ更新	P1	正常系 #10: 顧客戦略チームが「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を行い「身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）
【操作】
1. 管理画面で 会員管理 — オンライン本人確認 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
【操作後確認】
4. 会員管理 — オンライン本人確認 で対象キーと 保存しました を記録する"	身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 会員管理 — オンライン本人確認（M08-10） / 一覧・詳細に追加された対象データ
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-012	M08-08	メール/通知	P1	正常系 #11: 顧客戦略チームが「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を行い「お客様にオンライン本人確認が完了したことをメール通知することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md（会員管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md（会員管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
【操作】
1. 管理画面で 会員管理 — 手動メール通知 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
【操作後確認】
4. 会員管理 — 手動メール通知 で対象キーと 処理後の画面表示 を記録する"	お客様にオンライン本人確認が完了したことをメール通知することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 会員管理 — 手動メール通知（M08-08） / 送信されたメール/通知の内容と送信状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: お客様にオンライン本人確認が完了したことをメール通知することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-012、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-013	-	メール/通知	P1	正常系 #12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を行い「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
2. 「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
【操作後確認】
3. 本人確認完了メールで、本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 の対応を記録する"	本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-014	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #3 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-01 / ネット買取 / パターン1 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
連鎖ID=DL-01
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 正常系#1: お客様がF05-03（ネット買取商品一覧）で「買取対象商品を選択しカートへ追加する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
4. 正常系#2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
5. 正常系#3: お客様がネット買取 — 買取手続き〜完了で「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
6. 正常系#4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
7. 正常系#5: お客様が会員 — オンライン本人確認で「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
8. 正常系#6: お客様が会員管理 — オンライン本人確認で「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
9. 正常系#7: 顧客戦略チームがネット買取管理 — 買取検索一覧で「本人確認受付通知メール受領を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
10. 正常系#8: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
11. 正常系#9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
12. 正常系#10: 顧客戦略チームが会員管理 — オンライン本人確認で「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
13. 正常系#11: 顧客戦略チームが会員管理 — 手動メール通知で「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
14. 正常系#12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
【操作後確認】
15. 最終業務状態「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#2 買取希望品カート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01。
【操作】
産出工程の完了直後に#3 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #2 買取希望品カート の成果物 #3 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #3 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 産出工程 #2 買取希望品カート の成果物 #3 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-01 / ネット買取 / パターン1 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-015	-	データ連鎖	P1	正常系 DL-02: 産出値と消費値の照合 — #13 会員*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 産出値と消費値の照合
- 原典判定: 起点（産出元の記載なし・消費工程で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-02 / ネット買取 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/14_ネット買取.md 本文・原典ノード/接続表
- 解除条件:  原典上で未記載の産出元と#13 会員*1の取得方法を確定する。 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
連鎖ID=DL-02
照合キー=会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"【準備確認】
DL-02:  原典上で未記載の産出元と#13 会員*1の取得方法を確定する。 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #13 会員*1
照合キー: 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-02 / ネット買取 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/14_ネット買取.md 本文・原典ノード/接続表
連鎖判定: 起点（産出元の記載なし・消費工程で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-016	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #26 本人確認完了メール	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-03 / ネット買取 / パターン1 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
連鎖ID=DL-03
照合キー=会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 正常系#1: お客様がF05-03（ネット買取商品一覧）で「買取対象商品を選択しカートへ追加する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
4. 正常系#2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
5. 正常系#3: お客様がネット買取 — 買取手続き〜完了で「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
6. 正常系#4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
7. 正常系#5: お客様が会員 — オンライン本人確認で「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
8. 正常系#6: お客様が会員管理 — オンライン本人確認で「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
9. 正常系#7: 顧客戦略チームがネット買取管理 — 買取検索一覧で「本人確認受付通知メール受領を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
10. 正常系#8: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
11. 正常系#9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
12. 正常系#10: 顧客戦略チームが会員管理 — オンライン本人確認で「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
13. 正常系#11: 顧客戦略チームが会員管理 — 手動メール通知で「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
14. 正常系#12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
【操作後確認】
15. 最終業務状態「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#25 会員マスター手動メール通知、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01。
【操作】
産出工程の完了直後に#26 本人確認完了メールをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #25 会員マスター手動メール通知 の成果物 #26 本人確認完了メール の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #26 本人確認完了メール
照合キー: 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
合格条件: 産出工程 #25 会員マスター手動メール通知 の成果物 #26 本人確認完了メール の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md データ連鎖 DL-03 / ネット買取 / パターン1 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-017	F05-06	メール/通知	P1	正常系 工程#3 判定: 買取依頼受付メール受領の宛先と対象案件	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md（ネット買取 — 買取手続き〜完了）
- 必須入力欄: ご職業 / 生年月日 / 銀行名 / 支店名 / 口座種別 / 口座番号 / 口座名義 / 個口数 / 自動承諾 / 適格請求書発行事業者の登録番号
- 判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
判定用具体値: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。"	"担当者: お客様
【準備確認】
判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md（ネット買取 — 買取手続き〜完了）
14. 必須入力欄: ご職業 / 生年月日 / 銀行名 / 支店名 / 口座種別 / 口座番号 / 口座名義 / 個口数 / 自動承諾 / 適格請求書発行事業者の登録番号
【操作】
1. フロント画面で ネット買取 — 買取手続き〜完了 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
【操作後確認】
4. ネット買取 — 買取手続き〜完了 で対象キーと 処理後の画面表示 を記録する
具体照合: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"	「買取依頼受付メール受領」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。	"確認場所: ネット買取 — 買取手続き〜完了（F05-06） / 買取依頼受付メール受領の受信原本・対象案件の通知履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 「買取依頼受付メール受領」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-017、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f05-06_front_online_purchase_buy_shopping_complete.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1
比較規則: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-018	M08-10	メール/通知	P1	正常系 工程#6 判定: 本人確認受付メール受領の宛先と対象案件	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）
- 判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
判定用具体値: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。"	"担当者: お客様
【準備確認】
判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md（会員管理 — オンライン本人確認）
【操作】
1. 管理画面で 会員管理 — オンライン本人確認 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
【操作後確認】
4. 会員管理 — オンライン本人確認 で対象キーと 処理後の画面表示 を記録する
具体照合: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"	「本人確認受付メール受領」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。	"確認場所: 会員管理 — オンライン本人確認（M08-10） / 本人確認受付メール受領の受信原本・対象案件の通知履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 「本人確認受付メール受領」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-018、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m08-10_admin_customer_customer_online_identification.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1
比較規則: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-019	M08-08	メール/通知	P1	正常系 工程#11 判定: 本人確認完了メール送付の宛先と対象案件	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md（会員管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文
- 判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
判定用具体値: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md（会員管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
【操作】
1. 管理画面で 会員管理 — 手動メール通知 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-001-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01
3. 「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
【操作後確認】
4. 会員管理 — 手動メール通知 で対象キーと 処理後の画面表示 を記録する
具体照合: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"	「本人確認完了メール送付」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。	"確認場所: 会員管理 — 手動メール通知（M08-08） / 本人確認完了メール送付の受信原本・対象案件の通知履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 「本人確認完了メール送付」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-019、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m08-08_admin_customer_customer_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md 実行手順 / ネット買取 / パターン1 / 経路1
比較規則: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-020	-	業務データ差分	P1	正常系 DP-N002: PCからスマートフォンへ本人確認を引き継ぐ（	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
- 判定根拠: PCからスマートフォンへ本人確認を引き継ぐ（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=PCからスマートフォンへ本人確認を引き継ぐ（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）
入力=商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N002 / 開始端末=PC / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N002
条件設定: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N002 / 開始端末=PC / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証
3. 正常系#1: お客様がF05-03（ネット買取商品一覧）で「買取対象商品を選択しカートへ追加する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
4. 正常系#2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
5. 正常系#3: お客様がネット買取 — 買取手続き〜完了で「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
6. 正常系#4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
   差分条件を適用: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
7. 正常系#5: お客様が会員 — オンライン本人確認で「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N002 / 開始端末=PC / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
8. 正常系#6: お客様が会員管理 — オンライン本人確認で「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
9. 正常系#7: 顧客戦略チームがネット買取管理 — 買取検索一覧で「本人確認受付通知メール受領を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
10. 正常系#8: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
11. 正常系#9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
12. 正常系#10: 顧客戦略チームが会員管理 — オンライン本人確認で「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
13. 正常系#11: 顧客戦略チームが会員管理 — 手動メール通知で「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
14. 正常系#12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
【操作後確認】
15. 最終業務状態「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#5
差分固有判定: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡ること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡る状態であること。	"確認場所: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡ること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡る状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
差分判定根拠: PCからスマートフォンへ本人確認を引き継ぐ（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
ネット買取 — ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）	STI-ONLINE-KAITORI-001-021	-	業務データ差分	P1	正常系 DP-N003: スマートフォンで本人確認（	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理お客様-001 ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合
最終業務状態: 本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N003
データパターン種別: 正常系 業務データ差分
前提差分: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
シードデータ: 担当者アカウント=st-user-online-kaitori-001-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-001-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-001-R01 / 振込先=テスト銀行 普通 1234567
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
- 判定根拠: スマートフォンで本人確認（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）"	"データパターンID=DP-N003
種別=正常系 業務データ差分
目的=スマートフォンで本人確認（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）
入力=商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N003 / 開始端末=スマートフォン / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N003
条件設定: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F05-03, F05-04, F05-05, F05-06, M08-10, M08-08; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-online-kaitori-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「身分証問題ないかの判断結果として実線で「会員マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N003 / 開始端末=スマートフォン / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証
3. 正常系#1: お客様がF05-03（ネット買取商品一覧）で「買取対象商品を選択しカートへ追加する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
4. 正常系#2: お客様が「買取申し込み処理として、カート内の買取希望の商品を確認し、買取依頼処理を行う。 ※必須項目のご職業が未入力の場合はバリエーションが入る （会員登録時にはバリエーションチェックが入らない）」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
5. 正常系#3: お客様がネット買取 — 買取手続き〜完了で「買取依頼受付メール受領として、買取依頼処理が完了すると システムからメールが顧客宛に送付される」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
6. 正常系#4: お客様が「買取希望カード郵送として、買取希望のカードを顧客が晴れる屋に郵送する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
   差分条件を適用: PC開始時は表示されたQRコードをスマートフォンで読み取り、スマートフォン開始時は本人確認フォームから撮影する。
7. 正常系#5: お客様が会員 — オンライン本人確認で「オンライン本人確認として、PCの場合マイページ内のオンライン本人確認画面よりQRコードが 表示されるのでスマートフォンで読み取る スマートフォンの場合は身分証の登録フォームに進み、 スマートフォンのカメラ機能を使用して画像を登録する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01-DP-N003 / 開始端末=スマートフォン / 撮影端末=スマートフォン / 身分証=同じテスト会員の身分証（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
8. 正常系#6: お客様が会員管理 — オンライン本人確認で「本人確認受付メール受領として、本人確認作業が完了すると、 本人確認受付メールが送付される お客様の本人確認書類の作業が完了した通知メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
9. 正常系#7: 顧客戦略チームがネット買取管理 — 買取検索一覧で「本人確認受付通知メール受領を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
10. 正常系#8: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「本人確認書類確認として、お客様に通知したメールと同じメールがネット買取に届くため、 それを見てオンライン本人確認がされたことを確認し、 身分証が登録されていることと、その内容と登録情報を確認する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
11. 正常系#9: 通販チームが「本人確認書類確認判定として、身分証の内容に問題があったり、登録情報に問題がないか確認」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
12. 正常系#10: 顧客戦略チームが会員管理 — オンライン本人確認で「身分証に問題がない場合として、身分証と登録情報を確認し問題がなければ オンライン本人確認済みに変更 オンライン本人確認済みに変更する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
13. 正常系#11: 顧客戦略チームが会員管理 — 手動メール通知で「本人確認完了メール送付として、お客様にオンライン本人確認が完了したことをメール通知する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
14. 正常系#12: お客様が「本人確認完了メール受領として、本人確認完了メールを受領」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-001-R01
【操作後確認】
15. 最終業務状態「本人確認完了メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#5
差分固有判定: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡ること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡る状態であること。	"確認場所: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡ること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-001-R01
合格条件: 同じ会員の本人確認フォームへ到達し、撮影した本人確認画像が対象会員の確認担当者へ渡る状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-001-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-001-021、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理お客様-001_ネット買取処理（お客様の申し込みから郵送までの業務）（原典実線の代表経路）.md / ネット買取 / パターン1 / 経路1
差分判定根拠: スマートフォンで本人確認（原典本文 14_ネット買取.md R39「PCの場合マイページ内のオンライン本人確認画面よりQRコードが」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
