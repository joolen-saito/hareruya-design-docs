<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-16 | テスト項目化 | あり | CSV/帳票 |
| M04-01 | テスト項目化 | あり | データ更新 |
| M04-08 | テスト項目化 | あり | 照合 |
| M04-09 | テスト項目化 | あり | データ更新、在庫整合 |
| M04-24 | テスト項目化 | あり | 照合、CSV/帳票、状態遷移 |
| M04-25 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-26 | テスト項目化 | あり | CSV/帳票 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B02-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-28 | テスト項目化 | あり | CSV/帳票 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。	"確認場所: 在庫数と在庫変更履歴 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-002	M04-16	CSV/帳票	P1	正常系 #1: 店舗チームが「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を行い「在庫リコメンドが登録されていることを確認することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m04-16_admin_stock_product_stock_recommend_csv_export.md（在庫管理 — 在庫リコメンドCSV出力）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m04-16_admin_stock_product_stock_recommend_csv_export.md（在庫管理 — 在庫リコメンドCSV出力）
【操作】
1. 管理画面で 在庫管理 — 在庫リコメンドCSV出力 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
【操作後確認】
4. 在庫管理 — 在庫リコメンドCSV出力 で対象キーと 処理後の画面表示 を記録する"	在庫リコメンドが登録されていることを確認することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫リコメンドCSV出力（M04-16） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 在庫リコメンドが登録されていることを確認することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-16_admin_stock_product_stock_recommend_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-003	-	業務操作	P1	正常系 #2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を行い「自店→自店 区分を変えられることを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
【操作後確認】
3. リコメンドファイル・リコメンド作業をするためにリコメンドファイルで、自店→自店 区分を変えられることを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	自店→自店 区分を変えられることを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 自店→自店 区分を変えられることを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-004	M04-01	データ更新	P1	正常系 #3: 支店担当者が「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を行い「支店側がリコメンドファイルを確認し、本店に配送を行うことを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 検索パターン名を登録しました。 を記録する"	支店側がリコメンドファイルを確認し、本店に配送を行うことを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 支店側がリコメンドファイルを確認し、本店に配送を行うことを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索パターン名を登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-005	M04-09	データ更新	P1	正常系 #4: 出庫元店舗の承認者が「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を行い「対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録される」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 出庫元店舗の承認者
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 出庫元店舗の承認者が同じ在庫移動ID を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
【操作後確認】
4. 出庫元店舗の承認者が同じ在庫移動ID で対象キーと 処理後の画面表示 を記録する"	対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録されること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 在庫移動・振替ID・商品コード・出庫元店舗 / 出典: scenario_test/markdown/12_在庫管理.md:122 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2971#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2999#sheet-14
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-006	M04-08,M04-24	照合	P1	正常系 #5: 支店担当者が「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を行い「採番された移動指示IDへ選択した在庫移動IDが紐づき、店舗組合せと商品・移動点数が元の移動に一致される」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md（在庫管理 — 在庫移動・振替検索/一覧）
- この工程で通過する機能: M04-08 在庫管理 — 在庫移動・振替検索/一覧 → M04-24 在庫管理 — 在庫移動指示リスト作成/検索"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md（在庫管理 — 在庫移動・振替検索/一覧）
14. この工程で通過する機能: M04-08 在庫管理 — 在庫移動・振替検索/一覧 → M04-24 在庫管理 — 在庫移動指示リスト作成/検索
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 通過する機能: M04-08 → M04-24。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
【操作後確認】
5. 在庫管理 — 在庫移動・振替検索/一覧 で対象キーと 登録が完了しました。 を記録する"	採番された移動指示IDへ選択した在庫移動IDが紐づき、店舗組合せと商品・移動点数が元の移動に一致されること。	"確認場所: 在庫管理 — 在庫移動・振替検索/一覧（M04-08,M04-24） / 照合キー: 在庫移動・振替ID・移動指示ID / 出典: scenario_test/markdown/12_在庫管理.md:124 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2404#sheet-13
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 採番された移動指示IDへ選択した在庫移動IDが紐づき、店舗組合せと商品・移動点数が元の移動に一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 登録が完了しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-007	M04-24,M04-26,M04-28	CSV/帳票	P1	正常系 #6: 支店担当者が「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を行い「商品コード・移動点数がピッキングリストで移動内容と一致し、送り状CSVの店舗・配送先が移動先と一致すること。 実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留される」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
- この工程で通過する機能: M04-24 在庫管理 — 在庫移動指示リスト作成/検索 → M04-26 M04-26（ピッキングリスト印刷） → M04-28 M04-28（送り状CSV出力）
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
14. この工程で通過する機能: M04-24 在庫管理 — 在庫移動指示リスト作成/検索 → M04-26 M04-26（ピッキングリスト印刷） → M04-28 M04-28（送り状CSV出力）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 通過する機能: M04-24 → M04-26 → M04-28。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
【操作後確認】
5. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 処理後の画面表示 を記録する"	商品コード・移動点数がピッキングリストで移動内容と一致し、送り状CSVの店舗・配送先が移動先と一致すること。 実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留されること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24,M04-26,M04-28） / 照合キー: 移動指示ID・商品コード / 出典: scenario_test/markdown/12_在庫管理.md:125 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:6795#sheet-32 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:7068#sheet-34 / 設計差・留意点: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 商品コード・移動点数がピッキングリストで移動内容と一致し、送り状CSVの店舗・配送先が移動先と一致すること。 実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-008	-	データ更新	P1	正常系 #7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を行い「ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-009	-	CSV/帳票	P1	正常系 #8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を行い「印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
【操作後確認】
3. カードで、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認することを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-010	-	データ更新	P1	正常系 #9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を行い「ピックした商品に対して在庫差異があるか確認を行うことを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
【操作後確認】
3. 商品で、ピックした商品に対して在庫差異があるか確認を行うことを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	ピックした商品に対して在庫差異があるか確認を行うことを、在庫数と在庫変更履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: ピックした商品に対して在庫差異があるか確認を行うことを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-011	M04-24	CSV/帳票	P1	正常系 #10: 支店担当者が「移動指示IDと送り状No.を記載したCSVを登録する」を行い「対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態である」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する"	対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 照合キー: 移動指示ID・送り状No. / 出典: scenario_test/markdown/12_在庫管理.md:141 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:6797#sheet-32 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:6804#sheet-32 / 設計差・留意点: 原業務フローの旧称「入庫確認待ち」を現行HTML主本文の「移動中」へ具体化。HTML別添sheet52は旧状態名のため主本文を採用。
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-012	-	データ更新	P1	正常系 #11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を行い「発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
【操作後確認】
3. 商品で、発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-013	-	データ更新	P1	正常系 #12: 支店担当者が「通販受注管理 発送業務」を行い「引き継ぎ対象の商品コード・数量または申込番号を、後続の「通販受注管理 発送業務」の開始時と完了時に照合できること。 実施保留条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要状態である」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。に対する機能Noと操作手段を確定する
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 解除条件:  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。に対する機能Noと操作手段を確定する
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「通販受注管理 発送業務」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:144 / 設計差・留意点: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。で、引き継ぎ対象の商品コード・数量または申込番号を、後続の「通販受注管理 発送業務」の開始時と完了時に照合できること。 実施保留条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	引き継ぎ対象の商品コード・数量または申込番号を、後続の「通販受注管理 発送業務」の開始時と完了時に照合できること。 実施保留条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:144 / 設計差・留意点: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「通販受注管理 発送業務」の開始時と完了時に照合できること。 実施保留条件: 在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-014	-	データ更新	P1	正常系 #13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を行い「ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
【操作後確認】
3. ここでピッキングリスト・解体作業を行い段ボールに入っているピッキングリスト・段ボール・商品で、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する"	ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-015	M04-09	データ更新	P1	正常系 #14: トレードチームが「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を行い「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録される」を確認する	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 在庫移動・振替ID・商品コード・入庫先店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:155 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3203#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3291#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 同一店舗と店舗間を分けて実施。店舗内移動の新HTMLには独立承認工程がない。
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-015、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-016	-	データ連鎖	P1	正常系 DL-01: 産出値と消費値の照合 — #86 商品*2	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 産出値と消費値の照合
- 原典判定: 起点（産出元の記載なし・消費工程で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-01 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
- 解除条件:  原典上で未記載の産出元と#86 商品*2の取得方法を確定する。 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-01
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"【準備確認】
DL-01:  原典上で未記載の産出元と#86 商品*2の取得方法を確定する。 未確定理由: 原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #86 商品*2
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-01 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
連鎖判定: 起点（産出元の記載なし・消費工程で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-017	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #89 リコメンドファイル	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-02 / 在庫管理 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-02 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
- 解除条件: #89 リコメンドファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-02
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-02: #89 リコメンドファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #89 リコメンドファイル
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-02 / 在庫管理 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-02 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-018	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #94 在庫移動	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-03 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-03
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#93 在庫移動・振替CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#94 在庫移動をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #93 在庫移動・振替CSV登録 の成果物 #94 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #94 在庫移動
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #93 在庫移動・振替CSV登録 の成果物 #94 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-03 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-019	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #99 在庫履歴	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-04 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-04
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#93 在庫移動・振替CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#99 在庫履歴をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #93 在庫移動・振替CSV登録 の成果物 #99 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #99 在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #93 在庫移動・振替CSV登録 の成果物 #99 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-04 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-020	-	データ連鎖	P1	正常系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #96 在庫（出庫）	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-05 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-05
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#93 在庫移動・振替CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#96 在庫（出庫）をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #93 在庫移動・振替CSV登録 の成果物 #96 在庫（出庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #96 在庫（出庫）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #93 在庫移動・振替CSV登録 の成果物 #96 在庫（出庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-05 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-021	-	データ連鎖	P1	正常系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #102 在庫移動指示	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-06 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-06
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-06。以下の#番号は原典ノード番号。産出=#101 在庫移動指示リスト作成検索、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#102 在庫移動指示をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #101 在庫移動指示リスト作成検索 の成果物 #102 在庫移動指示 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #102 在庫移動指示
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #101 在庫移動指示リスト作成検索 の成果物 #102 在庫移動指示 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-021、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-06 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-022	-	データ連鎖	P1	正常系 DL-07: 終端の成果物確認（後続工程への受け渡しは未判定） — #104 ピッキングリスト	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-07
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-07 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-34"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-07
照合キー=選択した在庫移動ID＋原本の商品名・略称・言語/状態の組"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-07。以下の#番号は原典ノード番号。産出=#103 在庫移動指示リストエクスポート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=選択した在庫移動ID＋原本の商品名・略称・言語/状態の組。出力対象の在庫移動IDとPDF原本を対応付ける。明細の商品名から略称・言語・状態・色・レアリティを取り除いた表示値と照合する。原本に商品コード列を仮定しない。
【操作】
産出工程の完了直後に#104 ピッキングリストをproducer原本として保存する。
産出原本から 商品名・略称・言語/状態・数・基準価格 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #103 在庫移動指示リストエクスポート の成果物 #104 ピッキングリスト の商品名・略称・言語/状態・数・基準価格が、照合キー 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組 に対応する作業元の確定値と一致する状態であること。	"確認場所: #104 ピッキングリスト
照合キー: 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組
合格条件: 産出工程 #103 在庫移動指示リストエクスポート の成果物 #104 ピッキングリスト の商品名・略称・言語/状態・数・基準価格が、照合キー 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-022/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-022、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-07 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-34
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-023	-	データ連鎖	P1	正常系 DL-08: 終端の成果物確認（後続工程への受け渡しは未判定） — #105 送り状CSV	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-08
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-08 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-35"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-08
照合キー=オーダーID（在庫移動指示ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-08。以下の#番号は原典ノード番号。産出=#103 在庫移動指示リストエクスポート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=オーダーID（在庫移動指示ID）。CSVのオーダーIDを在庫移動指示IDに対応付け、注文者氏名は移動元店舗、配送先氏名は移動先店舗から照合する。
【操作】
産出工程の完了直後に#105 送り状CSVをproducer原本として保存する。
産出原本から オーダーID・注文者氏名・配送先氏名・注文金額合計 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #103 在庫移動指示リストエクスポート の成果物 #105 送り状CSV のオーダーID・注文者氏名・配送先氏名・注文金額合計が、照合キー オーダーID（在庫移動指示ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #105 送り状CSV
照合キー: オーダーID（在庫移動指示ID）
合格条件: 産出工程 #103 在庫移動指示リストエクスポート の成果物 #105 送り状CSV のオーダーID・注文者氏名・配送先氏名・注文金額合計が、照合キー オーダーID（在庫移動指示ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-023/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-023、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-08 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-35
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-024	-	データ連鎖	P1	正常系 DL-09: 産出値と消費値の照合 — #106 在庫移動実績入力用CSV	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-09
- 対象範囲: 産出値と消費値の照合
- 原典判定: 連鎖あり
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-09 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-09
照合キー=移動指示ID（当該シードの在庫移動IDに紐づく実ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-09。以下の#番号は原典ノード番号。産出=#103 在庫移動指示リストエクスポート、消費=#118 在庫移動実績インポート。
照合キー=移動指示ID（当該シードの在庫移動IDに紐づく実ID）。産出CSVの移動指示IDを記録し、その行の送り状No.に1234-5678を入力する。CSVに商品コード列を追加しない。
【操作】
産出工程の完了直後に#106 在庫移動実績入力用CSVをproducer原本として保存する。
#118 在庫移動実績インポートで実際に参照した原本をconsumer原本として保存し、移動指示ID・送り状No.をproducer原本と同じ照合キーで比較する。工程間で変更した列は原典に明記された変換だけを許容し、その計算過程を別記する。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	#103 在庫移動指示リストエクスポートで産出した#106 在庫移動実績入力用CSVの移動指示ID・送り状No.が、#118 在庫移動実績インポートが参照した値と照合キー 移動指示ID（当該シードの在庫移動IDに紐づく実ID） で一致する状態であること。	"確認場所: #106 在庫移動実績入力用CSV
照合キー: 移動指示ID（当該シードの在庫移動IDに紐づく実ID）
合格条件: #103 在庫移動指示リストエクスポートで産出した#106 在庫移動実績入力用CSVの移動指示ID・送り状No.が、#118 在庫移動実績インポートが参照した値と照合キー 移動指示ID（当該シードの在庫移動IDに紐づく実ID） で一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-024/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-024、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-09 / 在庫管理 / パターン2 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32
連鎖判定: 連鎖あり
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-025	-	データ連鎖	P1	正常系 DL-10: 終端の成果物確認（後続工程への受け渡しは未判定） — #136 在庫移動	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-10
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-10 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-10
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-10。以下の#番号は原典ノード番号。産出=#135 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#136 在庫移動をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #135 在庫移動・振替登録 編集 の成果物 #136 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #136 在庫移動
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #135 在庫移動・振替登録 編集 の成果物 #136 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-025/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-025、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-10 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-026	-	データ連鎖	P1	正常系 DL-11: 終端の成果物確認（後続工程への受け渡しは未判定） — #140 在庫履歴	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-11
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-11 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-11
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-11。以下の#番号は原典ノード番号。産出=#135 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#140 在庫履歴をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #135 在庫移動・振替登録 編集 の成果物 #140 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #140 在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #135 在庫移動・振替登録 編集 の成果物 #140 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-026/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-026、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-11 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-027	-	データ連鎖	P1	正常系 DL-12: 終端の成果物確認（後続工程への受け渡しは未判定） — #139 在庫（入庫）	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。 /  在庫発送の呼出しである。通販発送#4には受注出荷と在庫移動実績登録が混在し、受注番号ベースの全工程を在庫移動IDへ無条件に置き換えられない。17 R67の在庫移動実績登録自体はM04-24で特定済みだが、呼出し範囲と取込順の確定が必要。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-12
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-12 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
連鎖ID=DL-12
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-16, M04-01, M04-09, M04-08, M04-24, M04-26, M04-28, （機能未特定）発送業務へ進む; 判定不能=2; 未実装指摘あり=6（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 正常系#1: 店舗チームが在庫管理 — 在庫リコメンドCSV出力で「1週間に1回になっているとして、在庫リコメンドが登録されていることを確認する スタンダートと、それ以外の区分けで対応している 支店がトレードチームに商品を送る業務となる トレードチーム宛の移動はすべて3Fに入庫し、その後店舗等に移動する 3FECCUBE宛か、3Fスマレジ宛かのどちらかあてに移動を作成する 自店→他店 区分を変えない」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが「リコメンドファイル作成として、自店→自店 区分を変えられる リコメンド作業をするためにリコメンドファイル作成を行う 2F トレードと店舗の共用 ※マクロなど使用している」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
5. 正常系#3: 支店担当者が在庫管理 — 在庫検索/一覧で「在庫移動登録として、支店側がリコメンドファイルを確認し、本店に配送を行う 地下 ECCUBE 在庫移動登録を行い、移動対象の商品の在庫をおさえる」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: 支店担当者が在庫管理 — 在庫移動・振替検索/一覧で「出庫承認済みで出庫元と入庫先の組合せが同じ移動を選択して在庫移動指示を作成する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「同じ移動指示IDを選択してピッキングリストと送り状CSVを出力する（実施保留条件: M04-27実績入力用CSVは目次で廃止・sheet32で存続が衝突するため、その出力は別途保留する。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: 支店担当者が「発送ラベル発行として、ラベル印字アプリにてラベル発行 ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
10. 正常系#8: 支店担当者が「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング 移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 支店担当者が「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
12. 正常系#10: 支店担当者が在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
13. 正常系#11: 支店担当者が「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
14. 正常系#12: 支店担当者が同じ対象データを引き継いで「通販受注管理 発送業務」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
15. 正常系#13: トレードチームが「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-002-R01
16. 正常系#14: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 移動元ロケーション=本店バックヤード
【操作後確認】
17. 最終業務状態「同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-12。以下の#番号は原典ノード番号。産出=#135 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-002-R01。
【操作】
産出工程の完了直後に#139 在庫（入庫）をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #135 在庫移動・振替登録 編集 の成果物 #139 在庫（入庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #139 在庫（入庫）
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 産出工程 #135 在庫移動・振替登録 編集 の成果物 #139 在庫（入庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-027/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-027、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md データ連鎖 DL-12 / 在庫管理 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-028	-	在庫整合	P1	正常系 工程#9 判定: ピック作業の現物と作業元明細の一致	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 支店担当者
【準備確認】
判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「ピック作業として、ピックした商品に対して在庫差異があるか確認を行う」を実施する
【操作後確認】
3. 商品で、ピックした商品に対して在庫差異があるか確認を行うことを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「ピック作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 商品・商品別数量照合表
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 「ピック作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-028/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-028、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-029	M04-24	CSV/帳票	P1	正常系 工程#10 判定: 在庫移動実績CSVの送り状番号反映	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
- 判定用準備: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（移動指示ID・送り状No.）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。"	"担当者: 支店担当者
【準備確認】
判定用準備: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する
具体照合: CSV原本と取込後の在庫移動指示詳細を移動指示IDで照合し、送り状No.を文字列比較する。"	在庫移動指示検索で、取り込んだ移動指示IDの送り状No.がCSVの値1234-5678と一致する状態であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 在庫移動実績CSV・在庫移動指示検索/詳細
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 在庫移動指示検索で、取り込んだ移動指示IDの送り状No.がCSVの値1234-5678と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-029/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-029、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（移動指示ID・送り状No.）
比較規則: CSV原本と取込後の在庫移動指示詳細を移動指示IDで照合し、送り状No.を文字列比較する。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-030	M04-24	状態遷移	P1	正常系 工程#10 判定: 在庫移動実績CSVの発送状態	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
- 判定用準備: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（送り状登録後の状態）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。"	"担当者: 支店担当者
【準備確認】
判定用準備: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する
具体照合: 移動指示IDと在庫移動IDの対応を保ったまま、指示の発送状況と移動のステータスを照合する。"	CSVを取り込んだ移動指示の発送状況が「済」、紐づく在庫移動のステータスが「移動中」であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 在庫移動指示検索・在庫移動詳細
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: CSVを取り込んだ移動指示の発送状況が「済」、紐づく在庫移動のステータスが「移動中」であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-030/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-030、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（送り状登録後の状態）
比較規則: 移動指示IDと在庫移動IDの対応を保ったまま、指示の発送状況と移動のステータスを照合する。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-031	-	在庫整合	P1	正常系 工程#11 判定: 梱包作業の現物と作業元明細の一致	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 支店担当者
【準備確認】
判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「梱包作業として、発送する商品の梱包作業を行う 発送業務へ」を実施する
【操作後確認】
3. 商品で、発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「梱包作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 商品・商品別数量照合表
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 「梱包作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-031/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-031、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-032	-	在庫整合	P1	正常系 工程#13 判定: 入荷作業の現物と作業元明細の一致	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: トレードチーム
【準備確認】
判定用準備: ST-STOCK-ZAIKO-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
2. 「入荷作業として、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う」を実施する
【操作後確認】
3. ここでピッキングリスト・解体作業を行い段ボールに入っているピッキングリスト・段ボール・商品で、ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「入荷作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: ここでピッキングリスト・解体作業を行い段ボールに入っているピッキングリスト・段ボール・商品・商品別数量照合表
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 「入荷作業」で扱った商品 ST-STOCK-ZAIKO-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-032/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-032、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md 実行手順 / 在庫管理 / パターン2 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
在庫管理 — 在庫リコメンド対応（物品移動）（数量一致で入庫）	STI-ZAIKO-002-033	M04-09	在庫整合	P1	正常系 工程#14 判定: 移動先の入庫数量と原価	"元シナリオ: SCN-ZAIKO-在庫リコメンド対応物-002 在庫リコメンド対応（物品移動）（数量一致で入庫）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」）
最終業務状態: 同じ移動IDの受入数量が現物と一致し、承認者による入庫完了と移動先在庫の加算履歴を照合できたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 出荷指示数量=3、ピック数量=3、受入数量=3、商品状態の差異なし（原典本文 12_在庫管理.md R256–305「移動で編集できるのは数量のみで、商品の振替は不可のため、入庫してから振替を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ移動IDと商品コードについて指定の指示数・ピック数・受入数を準備し、送り元と承認者の双方の操作記録を保存する。状態差異は入庫してから振替を実施する。
シードデータ: 担当者アカウント=st-user-zaiko-002-r01 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
- 判定用準備: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-14（入庫承認時の在庫と原価）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
判定用具体値: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。"	"担当者: トレードチーム
【準備確認】
判定用準備: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-002-r01 / 商品コード=ST-STOCK-ZAIKO-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-002-R01 / 移動元ロケーション=本店バックヤード / 出荷指示数量=3 / ピック数量=3 / 受入数量=3 / 商品状態差異=なし
3. 「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する
具体照合: 移動IDに紐づく入庫履歴と前後在庫を比較し、移動先在庫5+3=8点、総原価500+300=800円を確認する。"	同一在庫移動IDの入庫先で、在庫が実入庫数3点、総原価が300円増加する状態であること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 在庫移動・振替登録/編集・在庫一覧・在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-002-R01
合格条件: 同一在庫移動IDの入庫先で、在庫が実入庫数3点、総原価が300円増加する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-002-033/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-002-033、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-在庫リコメンド対応物-002_在庫リコメンド対応（物品移動）（数量一致で入庫）.md / 在庫管理 / パターン2 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-14（入庫承認時の在庫と原価）
比較規則: 移動IDに紐づく入庫履歴と前後在庫を比較し、移動先在庫5+3=8点、総原価500+300=800円を確認する。"
```
