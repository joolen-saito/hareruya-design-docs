<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-01 | テスト項目化 | あり | 代替フロー |
| M04-12 | テスト項目化 | あり | 代替フロー |
| M04-13 | テスト項目化 | あり | 代替フロー |
| M04-14 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割）	STI-ZAIKO-027-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-027 商品入荷時インポート作業（BOXから既知のパックへ分割）
業務: 在庫管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
最終業務状態: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r02 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-12, M04-13; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-12, M04-13; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
3. 代替系#1: 商品管理チームが在庫管理 — 在庫検索/一覧で「1として、分割対象のボックスを選択 在庫検索一覧画面から開封したいボックスを選択し、在庫分割登録ボタンを クリックする（右画像参照）」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R02
4. 代替系#2: トレードチームが在庫管理 — 在庫分割結合検索/一覧で「2として、分割先のパックを選択して分割作成 （分割元の在庫をおさえる） 在庫分割結合登録編集画面で、分割先にボックスに入っている パック商品を選択し、数量を入力して分割登録を行う ここで分割元のボックスの在庫が減る（出庫）」を実施する
   対象: 移動数量=3
5. 代替系#3: トレードチームが在庫管理 — 在庫分割結合登録/編集で「3として、分割結果確認・入庫 トレードチームの承認者が分割のデータを確認し、 ボックスの数に対するパックの数が正しければ入庫済みにする ここで分割先のパックの在庫が増える（入庫）」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R02
【操作後確認】
6. 最終業務状態「分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。	"確認場所: 画面表示・処理ステータス・処理履歴 / 一覧・詳細に追加された対象データ / 在庫数と在庫変更履歴 / 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R02
合格条件: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-027-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-027-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md / 在庫管理 / パターン1 / 経路2"
在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割）	STI-ZAIKO-027-002	M04-01	代替フロー	P1	代替系 #1: 商品管理チームが「1として、分割対象のボックスを選択 在庫検索一覧画面から開封したいボックスを選択し、在庫分割登録ボタンを クリックする（右画像参照）」を行い「分割対象のボックスを選択することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-027 商品入荷時インポート作業（BOXから既知のパックへ分割）
業務: 在庫管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
最終業務状態: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r02 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3"	"担当者: 商品管理チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
3. 「1として、分割対象のボックスを選択 在庫検索一覧画面から開封したいボックスを選択し、在庫分割登録ボタンを クリックする（右画像参照）」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 検索パターン名を登録しました。 を記録する"	分割対象のボックスを選択することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 画面表示・処理ステータス・処理履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R02
合格条件: 分割対象のボックスを選択することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索パターン名を登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-027-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-027-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md / 在庫管理 / パターン1 / 経路2"
在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割）	STI-ZAIKO-027-003	M04-12	代替フロー	P1	代替系 #2: トレードチームが「2として、分割先のパックを選択して分割作成 （分割元の在庫をおさえる） 在庫分割結合登録編集画面で、分割先にボックスに入っている パック商品を選択し、数量を入力して分割登録を行う ここで分割元のボックスの在庫が減る（出庫）」を行い「分割先のパックを選択して分割作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-027 商品入荷時インポート作業（BOXから既知のパックへ分割）
業務: 在庫管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
最終業務状態: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r02 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-12_admin_stock_stock_split_join_search_list.md（在庫管理 — 在庫分割結合検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-12_admin_stock_stock_split_join_search_list.md（在庫管理 — 在庫分割結合検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
3. 「2として、分割先のパックを選択して分割作成 （分割元の在庫をおさえる） 在庫分割結合登録編集画面で、分割先にボックスに入っている パック商品を選択し、数量を入力して分割登録を行う ここで分割元のボックスの在庫が減る（出庫）」を実施する
【操作後確認】
4. 在庫管理 — 在庫分割結合検索/一覧 で対象キーと 処理後の画面表示 を記録する"	分割先のパックを選択して分割作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 在庫管理 — 在庫分割結合検索/一覧（M04-12） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R02
合格条件: 分割先のパックを選択して分割作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-027-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-027-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-12_admin_stock_stock_split_join_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md / 在庫管理 / パターン1 / 経路2"
在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割）	STI-ZAIKO-027-004	M04-13	代替フロー	P1	代替系 #3: トレードチームが「3として、分割結果確認・入庫 トレードチームの承認者が分割のデータを確認し、 ボックスの数に対するパックの数が正しければ入庫済みにする ここで分割先のパックの在庫が増える（入庫）」を行い「分割結果確認・入庫することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-027 商品入荷時インポート作業（BOXから既知のパックへ分割）
業務: 在庫管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
最終業務状態: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r02 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-027-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-027-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
3. 「3として、分割結果確認・入庫 トレードチームの承認者が分割のデータを確認し、 ボックスの数に対するパックの数が正しければ入庫済みにする ここで分割先のパックの在庫が増える（入庫）」を実施する
【操作後確認】
4. 在庫管理 — 在庫分割結合登録/編集 で対象キーと 処理後の画面表示 を記録する"	分割結果確認・入庫することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫分割結合登録/編集（M04-13） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R02
合格条件: 分割結果確認・入庫することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-027-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-027-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md / 在庫管理 / パターン1 / 経路2"
在庫管理 — 商品入荷時インポート作業（BOXから既知のパックへ分割）	STI-ZAIKO-027-005	-	代替フロー	P1	代替系 A1 #1: トレードチームが「分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）」を行い「分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-027 商品入荷時インポート作業（BOXから既知のパックへ分割）
業務: 在庫管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
最終業務状態: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r02 / 会員番号=ST-MEMBER-ZAIKO-001-R02 / 商品コード=ST-STOCK-ZAIKO-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）
入力=商品コード=ST-STOCK-ZAIKO-001-R02-A1 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 商品コード=ST-STOCK-ZAIKO-001-R02-A1 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3
2. 分岐条件「対象商品コードと加工前の在庫数量を記録する。分割・結合では構成商品の対応と数量をテストマスタに登録し、登録時と承認後の双方で元/先在庫を照合する。」を成立させる
3. 「分割元=BOX、分割先=登録済みパック（原典本文 12_在庫管理.md R69–84「ボックスをパックに分割」）」を実施する
【操作後確認】
4. 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したで、分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。の実値と対象データ 商品コード=ST-STOCK-ZAIKO-001-R02-A1 / 入荷・加工区分=BOXから既知のパックへ分割 / 原価=500円 / 処理数量=3 の対応を記録する"	分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。	"確認場所: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致した
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R02
合格条件: 分割元BOXの出庫数量と承認した分割先パックの入庫数量が分割記録と一致したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-027-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-027-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-027_商品入荷時インポート作業（BOXから既知のパックへ分割）.md / 在庫管理 / パターン1 / 経路2"
```
