<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — お客様EC購入フロー（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| F01-01 | テスト項目化 | あり | 業務操作 |
| F03-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F03-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F03-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F04-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F04-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F04-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F04-04 | テスト項目化 | あり | メール/通知 |
| M05-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「購入完了することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R01（正常代表）の条件「決済方法確認の判断結果として実線で「購入完了」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
3. 正常系#1: お客様がF01-01（本店トップページ表示）で「本店ECトップページを表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
4. 正常系#2: お客様が「商品をカートに入れるとして、商品購入のため商品一覧からカートに商品を投入」を実施する
   対象: 商品コード=ST-CARD-TSUHAN-001-R01
5. 正常系#3: 通販チームが「注文処理として、カート画面にて、購入処理を進める」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
6. 正常系#4: お客様がカート — 決済〜購入完了で「購入内容を確定して注文完了画面を表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
7. 正常系#5: お客様がカート — 決済〜購入完了で「メール受領として、メールを受領する コンビニ決済の場合は支払方法に関するメールが別で送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
8. 正常系#6: 通販チームが「決済手段による分岐として、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
9. 正常系#7: お客様が「購入完了として、購入完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
【操作後確認】
10. 最終業務状態「購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/16_通販受注管理.md:33 / excel_to_html/output/0301_基本設計仕様書(フロント_トップ).html:1016#sheet-3 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-002	F01-01	業務操作	P1	正常系 #1: お客様が「本店ECトップページを表示する」を行い「商品一覧・検索へ移動する入口が表示され、購入フローを開始できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/f01-01_front_top_home_main.md（F01-01（本店トップページ表示））"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/f01-01_front_top_home_main.md（F01-01（本店トップページ表示））
【操作】
1. フロント画面で F01-01（本店トップページ表示） を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
3. 「本店ECトップページを表示する」を実施する
【操作後確認】
4. F01-01（本店トップページ表示） で対象キーと 処理後の画面表示 を記録する"	商品一覧・検索へ移動する入口が表示され、購入フローを開始できること。	"確認場所: F01-01（本店トップページ表示）（F01-01） / 照合キー: / 出典: scenario_test/markdown/16_通販受注管理.md:33 / excel_to_html/output/0301_基本設計仕様書(フロント_トップ).html:1016#sheet-3
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 商品一覧・検索へ移動する入口が表示され、購入フローを開始できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f01-01_front_top_home_main.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-003	-	データ更新	P1	正常系 #2: お客様が「商品をカートに入れるとして、商品購入のため商品一覧からカートに商品を投入」を行い「商品購入のため商品一覧からカートに商品を投入が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
2. 「商品をカートに入れるとして、商品購入のため商品一覧からカートに商品を投入」を実施する
【操作後確認】
3. 商品で、商品購入のため商品一覧からカートに商品を投入が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01 の対応を記録する"	商品購入のため商品一覧からカートに商品を投入が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 商品購入のため商品一覧からカートに商品を投入が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-004	-	データ更新	P1	正常系 #3: 通販チームが「注文処理として、カート画面にて、購入処理を進める」を行い「カート画面にて、購入処理を進めることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
2. 「注文処理として、カート画面にて、購入処理を進める」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、カート画面にて、購入処理を進めることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01 の対応を記録する"	カート画面にて、購入処理を進めることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: カート画面にて、購入処理を進めることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-005	F04-04	メール/通知	P1	正常系 #4: お客様が「購入内容を確定して注文完了画面を表示する」を行い「採番された受注番号の注文内容が管理画面に登録され、顧客宛の注文完了メールと商品・数量・金額が一致される」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）
【操作】
1. フロント画面で カート — 決済〜購入完了 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
3. 「購入内容を確定して注文完了画面を表示する」を実施する
【操作後確認】
4. カート — 決済〜購入完了 で対象キーと 処理後の画面表示 を記録する"	採番された受注番号の注文内容が管理画面に登録され、顧客宛の注文完了メールと商品・数量・金額が一致されること。	"確認場所: カート — 決済〜購入完了（F04-04） / 照合キー: 受注番号・商品コード・顧客メールアドレス / 出典: scenario_test/markdown/16_通販受注管理.md:36 / excel_to_html/output/0304_基本設計仕様書(フロント_注文).html:2030#sheet-7
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 採番された受注番号の注文内容が管理画面に登録され、顧客宛の注文完了メールと商品・数量・金額が一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-006	F04-04	メール/通知	P1	正常系 #5: お客様が「メール受領として、メールを受領する コンビニ決済の場合は支払方法に関するメールが別で送付される」を行い「メールを受領することを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）
【操作】
1. フロント画面で カート — 決済〜購入完了 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
3. 「メール受領として、メールを受領する コンビニ決済の場合は支払方法に関するメールが別で送付される」を実施する
【操作後確認】
4. カート — 決済〜購入完了 で対象キーと 処理後の画面表示 を記録する"	メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: カート — 決済〜購入完了（F04-04） / 受信したメール/通知の内容と受信日時
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: メールを受領することを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-007	-	データ更新	P1	正常系 #6: 通販チームが「決済手段による分岐として、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐」を行い「クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐が完了したことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
2. 「決済手段による分岐として、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐」を実施する
【操作後確認】
3. カードで、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐が完了したことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01 の対応を記録する"	クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐が完了したことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐が完了したことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-008	-	データ更新	P1	正常系 #7: お客様が「購入完了として、購入完了」を行い「購入完了することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 決済方法確認の判断結果として実線で「購入完了」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 先行工程#4で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01
2. 「購入完了として、購入完了」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-001-r01 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-001-R01 の対応を記録する"	購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-009	-	業務データ差分	P1	正常系 DP-N002: クレジットカードで購入（	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 差分設定: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
- 判定根拠: クレジットカードで購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=クレジットカードで購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）
入力=受注番号=ST-ORDER-TSUHAN-001-R01-DP-N002 / 支払方法=クレジットカード / 注文商品=3点 / 支払額=注文確定画面に表示された総額"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N002
条件設定: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R01（正常代表）の条件「決済方法確認の判断結果として実線で「購入完了」へ進む場合」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-ORDER-TSUHAN-001-R01-DP-N002 / 支払方法=クレジットカード / 注文商品=3点 / 支払額=注文確定画面に表示された総額
3. 正常系#1: お客様がF01-01（本店トップページ表示）で「本店ECトップページを表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
4. 正常系#2: お客様が「商品をカートに入れるとして、商品購入のため商品一覧からカートに商品を投入」を実施する
   対象: 商品コード=ST-CARD-TSUHAN-001-R01
5. 正常系#3: 通販チームが「注文処理として、カート画面にて、購入処理を進める」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
6. 正常系#4: お客様がカート — 決済〜購入完了で「購入内容を確定して注文完了画面を表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
7. 正常系#5: お客様がカート — 決済〜購入完了で「メール受領として、メールを受領する コンビニ決済の場合は支払方法に関するメールが別で送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
   差分条件を適用: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
8. 正常系#6: 通販チームが「決済手段による分岐として、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01-DP-N002 / 支払方法=クレジットカード / 注文商品=3点 / 支払額=注文確定画面に表示された総額（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
9. 正常系#7: お客様が「購入完了として、購入完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
【操作後確認】
10. 最終業務状態「購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#6
差分固有判定: 同じ受注の注文完了を確認し、振込・入金手続きへ進まないこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ受注の注文完了を確認でき、振込・入金手続きへ進まない状態であること。	"確認場所: 同じ受注の注文完了を確認し、振込・入金手続きへ進まないこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 同じ受注の注文完了を確認でき、振込・入金手続きへ進まない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1
差分判定根拠: クレジットカードで購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
通販受注管理 — お客様EC購入フロー（原典実線の代表経路）	STI-TSUHAN-EC-001-010	-	業務データ差分	P1	正常系 DP-N003: 代金引換で購入（	"元シナリオ: SCN-TSUHAN-お客様EC購入フロー-001 お客様EC購入フロー（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 決済方法確認の判断結果として実線で「購入完了」へ進む場合
最終業務状態: 購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N003
データパターン種別: 正常系 業務データ差分
前提差分: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
シードデータ: 担当者アカウント=st-user-tsuhan-001-r01 / 会員番号=ST-MEMBER-TSUHAN-001-R01 / 商品コード=ST-CARD-TSUHAN-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-001-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
- 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 差分設定: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
- 判定根拠: 代金引換で購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）"	"データパターンID=DP-N003
種別=正常系 業務データ差分
目的=代金引換で購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）
入力=受注番号=ST-ORDER-TSUHAN-001-R01-DP-N003 / 支払方法=代金引換 / 注文商品=3点 / 支払額=注文確定画面に表示された総額"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N003
条件設定: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F01-01; 未実装指摘あり=1; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-ec-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-ec-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-001-R01 に対応付ける
10. 初回採番データ: 受注番号=工程#4の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 受注番号は未採番/未作成として開始し、工程#4の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R01（正常代表）の条件「決済方法確認の判断結果として実線で「購入完了」へ進む場合」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-ORDER-TSUHAN-001-R01-DP-N003 / 支払方法=代金引換 / 注文商品=3点 / 支払額=注文確定画面に表示された総額
3. 正常系#1: お客様がF01-01（本店トップページ表示）で「本店ECトップページを表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
4. 正常系#2: お客様が「商品をカートに入れるとして、商品購入のため商品一覧からカートに商品を投入」を実施する
   対象: 商品コード=ST-CARD-TSUHAN-001-R01
5. 正常系#3: 通販チームが「注文処理として、カート画面にて、購入処理を進める」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
6. 正常系#4: お客様がカート — 決済〜購入完了で「購入内容を確定して注文完了画面を表示する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
7. 正常系#5: お客様がカート — 決済〜購入完了で「メール受領として、メールを受領する コンビニ決済の場合は支払方法に関するメールが別で送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
   差分条件を適用: 指定の支払方法が選択できるテスト注文を用意する。支払方法に応じて決済検証環境・銀行/郵便の入金記録を準備し、実受注番号を採番後に控える。
8. 正常系#6: 通販チームが「決済手段による分岐として、クレジットカード・代金引換以外の場合、 振込や入金手続きが必要なため分岐」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01-DP-N003 / 支払方法=代金引換 / 注文商品=3点 / 支払額=注文確定画面に表示された総額（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
9. 正常系#7: お客様が「購入完了として、購入完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-001-R01
【操作後確認】
10. 最終業務状態「購入完了することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#6
差分固有判定: 同じ受注の注文完了を確認し、振込・入金手続きへ進まないこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ受注の注文完了を確認でき、振込・入金手続きへ進まない状態であること。	"確認場所: 同じ受注の注文完了を確認し、振込・入金手続きへ進まないこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-001-R01
合格条件: 同じ受注の注文完了を確認でき、振込・入金手続きへ進まない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-EC-001-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-EC-001-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様EC購入フロー-001_お客様EC購入フロー（原典実線の代表経路）.md / 通販受注管理 / パターン1 / 経路1
差分判定根拠: 代金引換で購入（原典本文 16_通販受注管理.md R48「クレジットカード・代金引換以外の場合」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
