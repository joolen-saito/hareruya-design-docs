<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — お客様対応（メーラーでのみの対応）（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — お客様対応（メーラーでのみの対応）（原典実線の代表経路）	STI-TSUHAN-009-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「同じ受注番号の注文完了メールが顧客が受信される」を確認する	"元シナリオ: SCN-TSUHAN-お客様対応メーラーで-009 お客様対応（メーラーでのみの対応）（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ受注番号の注文完了メールを顧客が受信すること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-006-r01 / 会員番号=ST-MEMBER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-009-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-006-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-006-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-009-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-006-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-006-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01
3. 正常系#1: 通販チームがメール/電話/外部アプリ（Thunderbird等）で「お客様対応として、欠品などが発生した場合などでのEC-CUBEを使わない場合の顧客対応 メール・電話での対応など 問合せなどThunderbirdでのみの対応 ※お客さんからお問い合わせが来てその返信対応を行う場合」を実施する
   対象: 商品コード=ST-CARD-TSUHAN-006-R01
4. 正常系#2: お客様が「メール受領を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-006-R01
【操作後確認】
5. 最終業務状態「同じ受注番号の注文完了メールを顧客が受信すること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ受注番号の注文完了メールが顧客が受信されること。	"確認場所: メール/外部アプリの対応記録、EC-CUBEの受注・在庫の更新有無 / 照合キー: / 出典: scenario_test/markdown/16_通販受注管理.md:132 / scenario_test/markdown/16_通販受注管理.md:138 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。 / 同じ受注番号の注文完了メールを顧客が受信すること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-006-R01
合格条件: 同じ受注番号の注文完了メールが顧客が受信されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-009-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-009-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md / 通販受注管理 / パターン6 / 経路1"
通販受注管理 — お客様対応（メーラーでのみの対応）（原典実線の代表経路）	STI-TSUHAN-009-002	-	メール/通知	P1	正常系 #1: 通販チームが「お客様対応として、欠品などが発生した場合などでのEC-CUBEを使わない場合の顧客対応 メール・電話での対応など 問合せなどThunderbirdでのみの対応 ※お客さんからお問い合わせが来てその返信対応を行う場合」を行い「メール/電話/外部アプリ側の対応記録が存在し、EC-CUBEの受注・在庫が更新されていないことを確認できる」を確認する	"元シナリオ: SCN-TSUHAN-お客様対応メーラーで-009 お客様対応（メーラーでのみの対応）（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ受注番号の注文完了メールを顧客が受信すること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-006-r01 / 会員番号=ST-MEMBER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01
2. 「お客様対応として、欠品などが発生した場合などでのEC-CUBEを使わない場合の顧客対応 メール・電話での対応など 問合せなどThunderbirdでのみの対応 ※お客さんからお問い合わせが来てその返信対応を行う場合」を実施する
【操作後確認】
3. Thunderbirdで、メール/電話/外部アプリ側の対応記録が存在し、EC-CUBEの受注・在庫が更新されていないことを確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01 の対応を記録する"	メール/電話/外部アプリ側の対応記録が存在し、EC-CUBEの受注・在庫が更新されていないことを確認できること。	"確認場所: メール/外部アプリの対応記録、EC-CUBEの受注・在庫の更新有無
照合キー: 受注番号=ST-ORDER-TSUHAN-006-R01
合格条件: メール/電話/外部アプリ側の対応記録が存在し、EC-CUBEの受注・在庫が更新されていないことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-009-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-009-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md / 通販受注管理 / パターン6 / 経路1"
通販受注管理 — お客様対応（メーラーでのみの対応）（原典実線の代表経路）	STI-TSUHAN-009-003	-	メール/通知	P1	正常系 #2: お客様が「メール受領を行う」を行い「同じ受注番号の注文完了メールが顧客が受信される」を確認する	"元シナリオ: SCN-TSUHAN-お客様対応メーラーで-009 お客様対応（メーラーでのみの対応）（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ受注番号の注文完了メールを顧客が受信すること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-006-r01 / 会員番号=ST-MEMBER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01
2. 「メール受領を行う」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/16_通販受注管理.md:132 / scenario_test/markdown/16_通販受注管理.md:138 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。で、同じ受注番号の注文完了メールを顧客が受信すること。の実値と対象データ 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01 の対応を記録する"	同じ受注番号の注文完了メールが顧客が受信されること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/16_通販受注管理.md:132 / scenario_test/markdown/16_通販受注管理.md:138 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: 受注番号=ST-ORDER-TSUHAN-006-R01
合格条件: 同じ受注番号の注文完了メールが顧客が受信されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-009-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-009-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md / 通販受注管理 / パターン6 / 経路1"
通販受注管理 — お客様対応（メーラーでのみの対応）（原典実線の代表経路）	STI-TSUHAN-009-004	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #128 顧客への確認メール	"元シナリオ: SCN-TSUHAN-お客様対応メーラーで-009 お客様対応（メーラーでのみの対応）（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 同じ受注番号の注文完了メールを顧客が受信すること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-006-r01 / 会員番号=ST-MEMBER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-009-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-006-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-006-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン6 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01
連鎖ID=DL-01
照合キー=会員番号=ST-MEMBER-TSUHAN-006-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-009-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-006-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-009-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-006-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-006-r01 / 受注番号=ST-ORDER-TSUHAN-006-R01 / 商品コード=ST-CARD-TSUHAN-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-006-R01
3. 正常系#1: 通販チームがメール/電話/外部アプリ（Thunderbird等）で「お客様対応として、欠品などが発生した場合などでのEC-CUBEを使わない場合の顧客対応 メール・電話での対応など 問合せなどThunderbirdでのみの対応 ※お客さんからお問い合わせが来てその返信対応を行う場合」を実施する
   対象: 商品コード=ST-CARD-TSUHAN-006-R01
4. 正常系#2: お客様が「メール受領を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-006-R01
【操作後確認】
5. 最終業務状態「同じ受注番号の注文完了メールを顧客が受信すること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#127 顧客対応、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=会員番号=ST-MEMBER-TSUHAN-006-R01。
【操作】
産出工程の完了直後に#128 顧客への確認メールをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #127 顧客対応 の成果物 #128 顧客への確認メール の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-TSUHAN-006-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #128 顧客への確認メール
照合キー: 会員番号=ST-MEMBER-TSUHAN-006-R01
合格条件: 産出工程 #127 顧客対応 の成果物 #128 顧客への確認メール の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-TSUHAN-006-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-009-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-009-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md / 通販受注管理 / パターン6 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-お客様対応メーラーで-009_お客様対応（メーラーでのみの対応）（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン6 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
