<!-- generated-by: hareruya-scenario-test-items -->
# 商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M14-01 | テスト項目化 | あり | CSV/帳票 |
| M14-04 | テスト項目化 | あり | CSV/帳票、照合 |
| M14-05 | テスト項目化 | あり | CSV/帳票 |
| M14-06 | テスト項目化 | あり | CSV/帳票 |
| M14-08 | テスト項目化 | あり | CSV/帳票 |
| M03-26 | テスト項目化 | あり | CSV/帳票 |
| M03-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-35 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-38 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-002	-	業務操作	P1	正常系 #1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を行い「公式からカードリストが公開されたタイミングで、 作成することを、公開状態で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
【操作後確認】
3. カードリスト・公式からカードリスト・公式サイトのイメージギャラリーよりカードリスト・カードで、公式からカードリストが公開されたタイミングで、 作成することを、公開状態で確認できること。の実値と対象データ 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	公式からカードリストが公開されたタイミングで、 作成することを、公開状態で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 公式からカードリストが公開されたタイミングで、 作成することを、公開状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-003	-	業務操作	P1	正常系 #2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を行い「公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードすることを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
【操作後確認】
3. 画像ファイル・カード・商品で、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードすることを、取込結果と対象件数・エラー行で確認できること。の実値と対象データ 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードすることを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードすることを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-004	-	業務操作	P1	正常系 #3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を行い「ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 店舗統括チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
【操作後確認】
3. カード・商品で、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-005	M14-01	CSV/帳票	P1	正常系 #4: 顧客戦略チームが「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を行い「新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））
【操作】
1. 管理画面で カード管理 — カード検索（一覧・条件抽出） を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
【操作後確認】
4. カード管理 — カード検索（一覧・条件抽出） で対象キーと 保存しました を記録する"	新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — カード検索（一覧・条件抽出）（M14-01） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-006	M14-04	CSV/帳票	P1	正常系 #5: 顧客戦略チームが「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を行い「登録用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
- 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
14. 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）
【操作】
1. 管理画面で カード管理 — 新規登録・編集・削除（詳細フォーム） を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
【操作後確認】
4. カード管理 — 新規登録・編集・削除（詳細フォーム） で対象キーと 保存しました を記録する"	登録用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — 新規登録・編集・削除（詳細フォーム）（M14-04） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 登録用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-007	M14-05	CSV/帳票	P1	正常系 #6: 顧客戦略チームが「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を行い「作成したカード登録CSVを投入し、カードを登録することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-05_admin_card_card_csv_import.md（カード管理 — カード CSV 登録（取込））
- 必須入力欄: CSV, TSVファイル選択"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-05_admin_card_card_csv_import.md（カード管理 — カード CSV 登録（取込））
14. 必須入力欄: CSV, TSVファイル選択
【操作】
1. 管理画面で カード管理 — カード CSV 登録（取込） を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
【操作後確認】
4. カード管理 — カード CSV 登録（取込） で対象キーと 処理後の画面表示 を記録する"	作成したカード登録CSVを投入し、カードを登録することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — カード CSV 登録（取込）（M14-05） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 作成したカード登録CSVを投入し、カードを登録することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-05_admin_card_card_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-008	M14-06	CSV/帳票	P1	正常系 #7: 顧客戦略チームが「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を行い「商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘5件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m14-06_admin_card_cardset_list.md（カード管理 — カードセット一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘5件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m14-06_admin_card_cardset_list.md（カード管理 — カードセット一覧）
【操作】
1. 管理画面で カード管理 — カードセット一覧 を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
【操作後確認】
4. カード管理 — カードセット一覧 で対象キーと 処理後の画面表示 を記録する"	商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — カードセット一覧（M14-06） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-06_admin_card_cardset_list.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-009	M14-08	CSV/帳票	P1	正常系 #8: 顧客戦略チームが「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を行い「カード商品CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m14-08_admin_card_cardset_register_update_delete.md（カード管理 — カードセット新規登録・編集・削除）
- 必須入力欄: カードセット名日本語 / カードセット名英語 / 略称 / リリース日 / 並び順"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m14-08_admin_card_cardset_register_update_delete.md（カード管理 — カードセット新規登録・編集・削除）
14. 必須入力欄: カードセット名日本語 / カードセット名英語 / 略称 / リリース日 / 並び順
【操作】
1. 管理画面で カード管理 — カードセット新規登録・編集・削除 を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
【操作後確認】
4. カード管理 — カードセット新規登録・編集・削除 で対象キーと 保存しました を記録する"	カード商品CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — カードセット新規登録・編集・削除（M14-08） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: カード商品CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-08_admin_card_cardset_register_update_delete.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-010	M03-26	CSV/帳票	P1	正常系 #9: 顧客戦略チームが「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を行い「作成したCSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
- 必須入力欄: CSV ファイル"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
14. 必須入力欄: CSV ファイル
【操作】
1. 管理画面で 商品管理 — カード商品CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
【操作後確認】
4. 商品管理 — カード商品CSV登録 で対象キーと 処理後の画面表示 を記録する"	作成したCSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — カード商品CSV登録（M03-26） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 作成したCSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-010、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-011	M14-04	照合	P1	正常系 #10: 顧客戦略チームが「対象カードIDの情報を編集して保存する」を行い「同じカードIDの編集した項目が保存値と一致される」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
- 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
14. 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）
【操作】
1. 管理画面で カード管理 — 新規登録・編集・削除（詳細フォーム） を開く
2. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「対象カードIDの情報を編集して保存する」を実施する
【操作後確認】
4. カード管理 — 新規登録・編集・削除（詳細フォーム） で対象キーと 保存しました を記録する"	同じカードIDの編集した項目が保存値と一致されること。	"確認場所: カード管理 — 新規登録・編集・削除（詳細フォーム）（M14-04） / 照合キー: カードID / 出典: scenario_test/markdown/09_商品登録・編集.md:63 / excel_to_html/output/0208_基本設計仕様書(カード管理).html:1400#sheet-6
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 同じカードIDの編集した項目が保存値と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-012	-	照合	P1	正常系 #11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を行い「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。 実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない状態である」を確認する	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。に対する機能Noと操作手段を確定する
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。に対する機能Noと操作手段を確定する
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
【操作後確認】
3. 商品で、引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。 実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。の実値と対象データ 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。 実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/09_商品登録・編集.md:65 / 設計差・留意点: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
照合キー: 商品コード=ST-PRODUCT-PRODUCT-002-R01
合格条件: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。 実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-013	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #9 AWS　S3	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-01 / 商品登録・編集 / パターン2 / 経路1 / scenario_test/markdown/09_商品登録・編集.md R44-R51/R62-R70/R90-R91"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-01
照合キー=商品名＋S3画像パス"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#8 カード画像取得、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品名＋S3画像パス。元画像と商品名を対応付け、S3へアップロードした実画像パスを保存する。パス対応表とカード登録CSVの画像パスを文字列比較し、そのパスから取得した画像をアップロード原本と比較する。
【操作】
産出工程の完了直後に#9 AWS　S3をproducer原本として保存する。
産出原本から 商品名・S3画像パス・対応する画像内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #8 カード画像取得 の成果物 #9 AWS S3 の商品名・S3画像パス・対応する画像内容が、照合キー 商品名＋S3画像パス に対応する作業元の確定値と一致する状態であること。	"確認場所: #9 AWS　S3
照合キー: 商品名＋S3画像パス
合格条件: 産出工程 #8 カード画像取得 の成果物 #9 AWS　S3 の商品名・S3画像パス・対応する画像内容が、照合キー 商品名＋S3画像パス に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-01 / 商品登録・編集 / パターン2 / 経路1 / scenario_test/markdown/09_商品登録・編集.md R44-R51/R62-R70/R90-R91
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-014	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #12 カード画像パス対応表	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-02 / 商品登録・編集 / パターン2 / 経路1 / scenario_test/markdown/09_商品登録・編集.md R44-R51/R62-R70/R90-R91"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-02
照合キー=商品名＋S3画像パス"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#11 カード画像パス対応表作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品名＋S3画像パス。元画像と商品名を対応付け、S3へアップロードした実画像パスを保存する。パス対応表とカード登録CSVの画像パスを文字列比較し、そのパスから取得した画像をアップロード原本と比較する。
【操作】
産出工程の完了直後に#12 カード画像パス対応表をproducer原本として保存する。
産出原本から 商品名・S3画像パス・対応する画像内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #11 カード画像パス対応表作成 の成果物 #12 カード画像パス対応表 の商品名・S3画像パス・対応する画像内容が、照合キー 商品名＋S3画像パス に対応する作業元の確定値と一致する状態であること。	"確認場所: #12 カード画像パス対応表
照合キー: 商品名＋S3画像パス
合格条件: 産出工程 #11 カード画像パス対応表作成 の成果物 #12 カード画像パス対応表 の商品名・S3画像パス・対応する画像内容が、照合キー 商品名＋S3画像パス に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-02 / 商品登録・編集 / パターン2 / 経路1 / scenario_test/markdown/09_商品登録・編集.md R44-R51/R62-R70/R90-R91
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-015	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #16 カード登録CSV	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-03 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0208_基本設計仕様書(カード管理).html#sheet-8"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-03
照合キー=カード詳細ID（登録対象の実ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#13 カード管理、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=カード詳細ID（登録対象の実ID）。カード詳細IDとシード商品のカード詳細の対応を保存する。新規採番時はCSV行と登録後カード詳細IDの対応を保存する。
【操作】
産出工程の完了直後に#16 カード登録CSVをproducer原本として保存する。
産出原本から カード詳細ID・カード名(日本語)・カード名(英語) を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #13 カード管理 の成果物 #16 カード登録CSV のカード詳細ID・カード名(日本語)・カード名(英語)が、照合キー カード詳細ID（登録対象の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #16 カード登録CSV
照合キー: カード詳細ID（登録対象の実ID）
合格条件: 産出工程 #13 カード管理 の成果物 #16 カード登録CSV のカード詳細ID・カード名(日本語)・カード名(英語)が、照合キー カード詳細ID（登録対象の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-03 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0208_基本設計仕様書(カード管理).html#sheet-8
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-016	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #16 カード登録CSV	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-04 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0208_基本設計仕様書(カード管理).html#sheet-8"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-04
照合キー=カード詳細ID（登録対象の実ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#15 カード登録CSV作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=カード詳細ID（登録対象の実ID）。カード詳細IDとシード商品のカード詳細の対応を保存する。新規採番時はCSV行と登録後カード詳細IDの対応を保存する。
【操作】
産出工程の完了直後に#16 カード登録CSVをproducer原本として保存する。
産出原本から カード詳細ID・カード名(日本語)・カード名(英語) を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #15 カード登録CSV作成 の成果物 #16 カード登録CSV のカード詳細ID・カード名(日本語)・カード名(英語)が、照合キー カード詳細ID（登録対象の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #16 カード登録CSV
照合キー: カード詳細ID（登録対象の実ID）
合格条件: 産出工程 #15 カード登録CSV作成 の成果物 #16 カード登録CSV のカード詳細ID・カード名(日本語)・カード名(英語)が、照合キー カード詳細ID（登録対象の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-04 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0208_基本設計仕様書(カード管理).html#sheet-8
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-017	-	データ連鎖	P1	正常系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #22 カード商品CSV*1	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-05 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-10"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-05
照合キー=商品ID（更新時）またはカード詳細(ID)＋言語(ID)（新規登録時）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#21 カード商品CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID（更新時）またはカード詳細(ID)＋言語(ID)（新規登録時）。新規登録と更新を区別し、対象CSV行・採番された商品ID・カード詳細(ID)を対応付ける。
【操作】
産出工程の完了直後に#22 カード商品CSV*1をproducer原本として保存する。
産出原本から カード詳細(ID)・言語(ID)・商品ID を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #21 カード商品CSV登録 の成果物 #22 カード商品CSV*1 のカード詳細(ID)・言語(ID)・商品IDが、照合キー 商品ID（更新時）またはカード詳細(ID)＋言語(ID)（新規登録時） に対応する作業元の確定値と一致する状態であること。	"確認場所: #22 カード商品CSV*1
照合キー: 商品ID（更新時）またはカード詳細(ID)＋言語(ID)（新規登録時）
合格条件: 産出工程 #21 カード商品CSV登録 の成果物 #22 カード商品CSV*1 のカード詳細(ID)・言語(ID)・商品IDが、照合キー 商品ID（更新時）またはカード詳細(ID)＋言語(ID)（新規登録時） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-05 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-10
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-018	-	データ連鎖	P1	正常系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #25 カード登録作業ファイル	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-06 / 商品登録・編集 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-06 / scenario_test/markdown/09_商品登録・編集.md 本文・原典ノード/接続表
- 解除条件: #25 カード登録作業ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-06
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-06: #25 カード登録作業ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #25 カード登録作業ファイル
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-06 / 商品登録・編集 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-06 / scenario_test/markdown/09_商品登録・編集.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-019	-	データ連鎖	P1	正常系 DL-07: 終端の成果物確認（後続工程への受け渡しは未判定） — #30 商品規格*1	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-07
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-07 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-07
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-07。以下の#番号は原典ノード番号。産出=#29 カード商品CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#30 商品規格*1をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #29 カード商品CSV登録 の成果物 #30 商品規格*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #30 商品規格*1
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #29 カード商品CSV登録 の成果物 #30 商品規格*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-07 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）	STI-PRODUCT-2-002-020	-	データ連鎖	P1	正常系 DL-08: 終端の成果物確認（後続工程への受け渡しは未判定） — #30 商品規格*1	"元シナリオ: SCN-PRODUCT-新弾発表発売週の2週-002 新弾発表 発売週の2週間前 予約シングルの販売準備（原典実線の代表経路）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-002-r01 / 会員番号=ST-MEMBER-PRODUCT-002-R01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-08
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-08 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-08
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M14-01, M14-04, M14-05, M14-08, M03-26, （機能未特定）発売日1週間前として、プレリリース業務へ移る; 判定不能=1; 未実装指摘あり=6; 実装違い指摘あり=1（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-2-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-2-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-2-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-002-r01 / 商品コード=ST-PRODUCT-PRODUCT-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 正常系#1: 顧客戦略チームが「カードリストとして、公式からカードリストが公開されたタイミングで、 作成 公式サイトのイメージギャラリーよりカードリストの作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
4. 正常系#2: 顧客戦略チームが「カード画像として、公式サイトのイメージギャラリーより 取得 画像ファイルをブラウザのアドインを使用し 商品画像をAWSのS3にアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
5. 正常系#3: 店舗統括チームが「カード画像として、ITチームにて、トレードチームがS3にアップした画像と商品名を パス対応表 紐づけ表を作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
6. 正常系#4: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「カード管理からとして、新弾の販売予定のシングルカードの登録を行うため、 フォーマットを 登録用のCSVをカード管理画面よりフォーマットをダウンロード」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
7. 正常系#5: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カード登録として、登録用CSVを作成する CSV作成 作成したカード画像パス対応表を使い画像パスをCSVに入力する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
8. 正常系#6: 顧客戦略チームがカード管理 — カード CSV 登録（取込）で「カード管理として、作成したカード登録CSVを投入し、カードを登録 CSV登録 画像についてはAWSにアップされているリンクを紐づけるため EC-CUBEでの作業は不要 カードセットへの紐づけ処理もこのタイミングで行われる ※バリエーションとしてはNMしか登録しない想定」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
9. 正常系#7: 顧客戦略チームがカード管理 — カードセット一覧で「カード商品CSVとして、商品マスターに登録するために、 フォーマット CSVフォーマットをカード商品CSV登録画面よりダウンロード ダウンロード ※メニュー名と画面での名称が不一致」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
10. 正常系#8: 顧客戦略チームがカード管理 — カードセット新規登録・編集・削除で「カード商品CSVとして、カード商品CSVを作成する 作成 公式サイトのほか、scryfall.comなどを参照し BLB本体.xlsxを作成（作業ファイル）しそこから、CSVを作成する ※BLBはブルームバロウの略でエキスパンションによって変わる」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
11. 正常系#9: 顧客戦略チームが商品管理 — カード商品CSV登録で「カード商品として、作成したCSVをアップロードし商品登録を行う CSV登録 この際に画像登録も同時に行われる（S3の画像を参照できるように登録） 予約商品なので購入上限数も規格にて登録する ※在庫数には余裕があるため全体数での在庫制限などはやってない」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
12. 正常系#10: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「対象カードIDの情報を編集して保存する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
13. 正常系#11: 店舗チームが「発売1週間前に同じ商品コードと予約準備結果をプレリリース担当へ引き継ぐ。引継ぎ結果までを記録し、プレリリース本体の実行範囲は未確定として残す。（実施保留条件: 原典09 R101/10 R131にプレリリースへ移るとあるが、全業務フローにプレリリース業務本文・作業順がない。HTMLの個別画面からプレリリースの業務工程を組み立てない。）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-002-R01
【操作後確認】
14. 最終業務状態「引き継ぎ対象の商品コード・数量または申込番号を、後続の「プレリリース業務」の開始時と完了時に照合できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-08。以下の#番号は原典ノード番号。産出=#31 商品マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#30 商品規格*1をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #31 商品マスター の成果物 #30 商品規格*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #30 商品規格*1
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #31 商品マスター の成果物 #30 商品規格*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-2-002-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-2-002-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md / 商品登録・編集 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新弾発表発売週の2週-002_新弾発表_発売週の2週間前_予約シングルの販売準備（原典実線の代表経路）.md データ連鎖 DL-08 / 商品登録・編集 / パターン2 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
