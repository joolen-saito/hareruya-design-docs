<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-01 | テスト項目化 | あり | 代替フロー |
| M04-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-13 | テスト項目化 | あり | 代替フロー |
| M04-14 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-23 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-001	-	業務経路	P1	代替系 経路全体 R06: 主要代替として「分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-13, M04-23; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-13, M04-23; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R06（主要代替）の条件「商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 代替系#1: トレードチームが在庫管理 — 在庫検索/一覧で「分割元のパックを選択として、分割元のオリパ・福袋を選択し、分割先を未指定で分割登録する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
4. 代替系#2: トレードチームが在庫管理 — 在庫分割結合登録/編集で「在庫検索一覧から分割元商品を選び、分割数量を入力して登録する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
5. 代替系#3: 店舗チームが「対象のパックまたはオリパ・福袋を開封し、カードをソートして商品コード・状態・枚数を打ち込みファイルへ記録する。別担当者が現物とファイルをWチェックする」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
6. 代替系#4: トレードチームが「4として、インポートファイル作成 EC-CUBEにインポートを行うためのファイルを作成 本店システムと支店システム用のインポートファイル作成 ※バックヤード店にも登録を行っているため」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
7. 代替系#5: トレードチームが在庫管理 — 在庫分割結合登録/編集で「同じオリパ・福袋の分割IDに、開封結果のカードコード・数量を記載した分割先CSVを登録し、分割先と数量を確認して承認申請する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 代替系#6: トレードチームが在庫管理 — 在庫分割結合登録/編集で「登録者と異なる承認権限者が同じ分割IDの開封結果と分割先数量を照合し、承認ボタンを押して確定する」を実施する
   対象: 移動数量=3
【操作後確認】
9. 最終業務状態「分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。	"確認場所: 一覧・詳細に追加された対象データ / 照合キー: 在庫分割結合ID・分割元商品コード / 出典: scenario_test/markdown/12_在庫管理.md:75 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:4097#sheet-18 / 照合キー: 分割ID・開封元商品コード・分割先商品コード・状態 / 出典: scenario_test/markdown/12_在庫管理.md:77 / 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-002	M04-01	代替フロー	P1	代替系 #1: トレードチームが「分割元のパックを選択として、分割元のオリパ・福袋を選択し、分割先を未指定で分割登録する」を行い「分割元のオリパ・福袋を選択し、分割先を未指定で分割登録することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 「分割元のパックを選択として、分割元のオリパ・福袋を選択し、分割先を未指定で分割登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 検索パターン名を登録しました。 を記録する"	分割元のオリパ・福袋を選択し、分割先を未指定で分割登録することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 分割元のオリパ・福袋を選択し、分割先を未指定で分割登録することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索パターン名を登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-003	M04-13	代替フロー	P1	代替系 #2: トレードチームが「在庫検索一覧から分割元商品を選び、分割数量を入力して登録する」を行い「同じ在庫分割結合IDの分割元数量が登録され、分割元在庫が分割数量分減少される」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 「在庫検索一覧から分割元商品を選び、分割数量を入力して登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫分割結合登録/編集 で対象キーと 在庫分割を登録しました。 / 保存しました を記録する"	同じ在庫分割結合IDの分割元数量が登録され、分割元在庫が分割数量分減少されること。	"確認場所: 在庫管理 — 在庫分割結合登録/編集（M04-13） / 照合キー: 在庫分割結合ID・分割元商品コード / 出典: scenario_test/markdown/12_在庫管理.md:75 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:4097#sheet-18
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 同じ在庫分割結合IDの分割元数量が登録され、分割元在庫が分割数量分減少されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 在庫分割を登録しました。 / 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-004	-	代替フロー	P1	代替系 #3: 店舗チームが「対象のパックまたはオリパ・福袋を開封し、カードをソートして商品コード・状態・枚数を打ち込みファイルへ記録する。別担当者が現物とファイルをWチェックする」を行い「現物のカード合計枚数と打ち込み合計が一致し、開封元商品と分割先カードの対応を記録できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
2. 「対象のパックまたはオリパ・福袋を開封し、カードをソートして商品コード・状態・枚数を打ち込みファイルへ記録する。別担当者が現物とファイルをWチェックする」を実施する
【操作後確認】
3. カードをソートして商品コード・状態・枚数を打ち込みファイル・別担当者が現物とファイル・カード・商品・現物で、現物のカード合計枚数と打ち込み合計が一致し、開封元商品と分割先カードの対応を記録できるの実値と対象データ 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3 の対応を記録する"	現物のカード合計枚数と打ち込み合計が一致し、開封元商品と分割先カードの対応を記録できること。	"確認場所: 照合キー: 分割ID・開封元商品コード・分割先商品コード・状態 / 出典: scenario_test/markdown/12_在庫管理.md:77
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 現物のカード合計枚数と打ち込み合計が一致し、開封元商品と分割先カードの対応を記録できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-005	-	代替フロー	P1	代替系 #4: トレードチームが「4として、インポートファイル作成 EC-CUBEにインポートを行うためのファイルを作成 本店システムと支店システム用のインポートファイル作成 ※バックヤード店にも登録を行っているため」を行い「開封結果の商品コード・数量が本店用と支店用の指定ファイルへ引き継がれる状態である」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
2. 「4として、インポートファイル作成 EC-CUBEにインポートを行うためのファイルを作成 本店システムと支店システム用のインポートファイル作成 ※バックヤード店にも登録を行っているため」を実施する
【操作後確認】
3. インポートファイル・CUBEにインポートを行うためのファイル・本店システムと支店システム用のインポートファイルで、開封結果の商品コード・数量が本店用と支店用の指定ファイルへ引き継がれること。の実値と対象データ 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3 の対応を記録する"	開封結果の商品コード・数量が本店用と支店用の指定ファイルへ引き継がれる状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:81 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 開封結果の商品コード・数量が本店用と支店用の指定ファイルへ引き継がれる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-006	M04-13,M04-23	代替フロー	P1	代替系 #5: トレードチームが「同じオリパ・福袋の分割IDに、開封結果のカードコード・数量を記載した分割先CSVを登録し、分割先と数量を確認して承認申請する」を行い「分割先カードと数量が開封結果に一致し、状態は現HTMLの分割承認待ちとなる。承認前には分割先在庫は加算されない」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘10件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）
- この工程で通過する機能: M04-13 在庫管理 — 在庫分割結合登録/編集 → M04-23 在庫管理 — 在庫分割結合CSV登録"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘10件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）
14. この工程で通過する機能: M04-13 在庫管理 — 在庫分割結合登録/編集 → M04-23 在庫管理 — 在庫分割結合CSV登録
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 通過する機能: M04-13 → M04-23。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「同じオリパ・福袋の分割IDに、開封結果のカードコード・数量を記載した分割先CSVを登録し、分割先と数量を確認して承認申請する」を実施する
【操作後確認】
5. 在庫管理 — 在庫分割結合登録/編集 で対象キーと 在庫分割を登録しました。 / 保存しました を記録する"	分割先カードと数量が開封結果に一致し、状態は現HTMLの分割承認待ちとなる。承認前には分割先在庫は加算されないこと。	"確認場所: 在庫管理 — 在庫分割結合登録/編集（M04-13,M04-23） / 照合キー: 在庫分割結合ID・商品コード / 出典: scenario_test/markdown/12_在庫管理.md:84 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:4286#sheet-18 / 設計差・留意点: フローの旧称「入庫待ち」はHTMLの分割承認待ちで観測する。
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 分割先カードと数量が開封結果に一致し、状態は現HTMLの分割承認待ちとなる。承認前には分割先在庫は加算されないこと。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 在庫分割を登録しました。 / 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-007	M04-13	代替フロー	P1	代替系 #6: トレードチームが「登録者と異なる承認権限者が同じ分割IDの開封結果と分割先数量を照合し、承認ボタンを押して確定する」を行い「状態は入庫完了となり、分割先在庫は承認直前の在庫数＋分割先数量になる。承認者・承認日時が同じ分割IDに記録される」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘7件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md（在庫管理 — 在庫分割結合登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 「登録者と異なる承認権限者が同じ分割IDの開封結果と分割先数量を照合し、承認ボタンを押して確定する」を実施する
【操作後確認】
4. 在庫管理 — 在庫分割結合登録/編集 で対象キーと 在庫分割を登録しました。 / 保存しました を記録する"	状態は入庫完了となり、分割先在庫は承認直前の在庫数＋分割先数量になる。承認者・承認日時が同じ分割IDに記録されること。	"確認場所: 在庫管理 — 在庫分割結合登録/編集（M04-13） / 照合キー: 在庫分割結合ID・商品コード / 出典: scenario_test/markdown/12_在庫管理.md:88 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:4099#sheet-18 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:4216#sheet-18
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 状態は入庫完了となり、分割先在庫は承認直前の在庫数＋分割先数量になる。承認者・承認日時が同じ分割IDに記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 在庫分割を登録しました。 / 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-13_admin_stock_stock_split_join_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-008	M04-23	代替フロー	P1	代替系 A1 #1: トレードチームが「商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）」を行い「分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-23_admin_stock_stock_split_join_csv_import.md（在庫管理 — 在庫分割結合CSV登録）"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
入力=商品コード=ST-STOCK-ZAIKO-001-R06-A1 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-23_admin_stock_stock_split_join_csv_import.md（在庫管理 — 在庫分割結合CSV登録）
【操作】
1. 管理画面で 在庫管理 — 在庫分割結合CSV登録 を開く
2. 対象データ: 商品コード=ST-STOCK-ZAIKO-001-R06-A1 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 分岐条件「元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。」を成立させる
4. 「商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）」を実施する
【操作後確認】
5. 在庫管理 — 在庫分割結合CSV登録 で対象キーと %count% 件の分割を登録し、承認申請まで進めました。 / %count% 件の結合を登録し、欠品入力まで進めました。 を記録する"	分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。	"確認場所: 在庫管理 — 在庫分割結合CSV登録（M04-23） / 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫した
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R06
合格条件: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: %count% 件の分割を登録し、承認申請まで進めました。 / %count% 件の結合を登録し、欠品入力まで進めました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-23_admin_stock_stock_split_join_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-009	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #44 打ち込みファイル*1	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M04-01, M04-13, M04-23; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-01 / 在庫管理 / パターン1 / 経路6 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
- 解除条件: #44 打ち込みファイル*1の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
連鎖ID=DL-01
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-01: #44 打ち込みファイル*1の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #44 打ち込みファイル*1
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6
判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-01 / 在庫管理 / パターン1 / 経路6 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
在庫管理 — 商品入荷時インポート作業（オリパ・福袋を開封して分割）	STI-ZAIKO-031-010	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #47 インポートCSV	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-031 商品入荷時インポート作業（オリパ・福袋を開封して分割）
業務: 在庫管理
経路ID: R06
経路種別: 主要代替
業務経路条件: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）
最終業務状態: 分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r06 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-13, M04-23; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-02 / 在庫管理 / パターン1 / 経路6 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-18 / scenario_test/markdown/12_在庫管理.md R114-R124"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
連鎖ID=DL-02
照合キー=在庫分割ID＋分割先商品コード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-13, M04-23; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-031-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R06 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-031-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R06"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R06 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-001-r06 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R06（主要代替）の条件「商品種別=オリパ・福袋、分割先=開封後に確定（原典本文 12_在庫管理.md R168–189,図形#81–84「分割データ作成の流れは1-③新品パックを開封してシングルカードとして登録（分割先がわからない）と同様となる」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-001-r06 / 商品コード=ST-STOCK-ZAIKO-001-R06 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R06 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=オリパ・福袋を開封して分割 / 処理数量=3
3. 代替系#1: トレードチームが在庫管理 — 在庫検索/一覧で「分割元のパックを選択として、分割元のオリパ・福袋を選択し、分割先を未指定で分割登録する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
4. 代替系#2: トレードチームが在庫管理 — 在庫分割結合登録/編集で「在庫検索一覧から分割元商品を選び、分割数量を入力して登録する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
5. 代替系#3: 店舗チームが「対象のパックまたはオリパ・福袋を開封し、カードをソートして商品コード・状態・枚数を打ち込みファイルへ記録する。別担当者が現物とファイルをWチェックする」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
6. 代替系#4: トレードチームが「4として、インポートファイル作成 EC-CUBEにインポートを行うためのファイルを作成 本店システムと支店システム用のインポートファイル作成 ※バックヤード店にも登録を行っているため」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R06
7. 代替系#5: トレードチームが在庫管理 — 在庫分割結合登録/編集で「同じオリパ・福袋の分割IDに、開封結果のカードコード・数量を記載した分割先CSVを登録し、分割先と数量を確認して承認申請する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 代替系#6: トレードチームが在庫管理 — 在庫分割結合登録/編集で「登録者と異なる承認権限者が同じ分割IDの開封結果と分割先数量を照合し、承認ボタンを押して確定する」を実施する
   対象: 移動数量=3
【操作後確認】
9. 最終業務状態「分割先を未指定で登録し、開封結果をCSVで同じ分割記録へ紐付けて入庫したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#46 インポートファイル作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=在庫分割ID＋分割先商品コード。原典の開封結果を紐づける分割CSVとして扱う。在庫分割IDと元パックを記録し、ヘッダ「商品コード,分割先分割在庫数」で開封結果のカードと実枚数を設定する。他の在庫変更CSVへ置き換えない。
【操作】
産出工程の完了直後に#47 インポートCSVをproducer原本として保存する。
産出原本から 商品コード・分割先分割在庫数 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #46 インポートファイル作成 の成果物 #47 インポートCSV の商品コード・分割先分割在庫数が、照合キー 在庫分割ID＋分割先商品コード に対応する作業元の確定値と一致する状態であること。	"確認場所: #47 インポートCSV
照合キー: 在庫分割ID＋分割先商品コード
合格条件: 産出工程 #46 インポートファイル作成 の成果物 #47 インポートCSV の商品コード・分割先分割在庫数が、照合キー 在庫分割ID＋分割先商品コード に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-031-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-031-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md / 在庫管理 / パターン1 / 経路6
判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-031_商品入荷時インポート作業（オリパ・福袋を開封して分割）.md データ連鎖 DL-02 / 在庫管理 / パターン1 / 経路6 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-18 / scenario_test/markdown/12_在庫管理.md R114-R124
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
