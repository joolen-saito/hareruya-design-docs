<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — フロア間移動（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-01 | テスト項目化 | あり | データ更新 |
| M04-08 | テスト項目化 | あり | 業務操作 |
| M04-09 | テスト項目化 | あり | データ更新、在庫整合 |
| M04-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-22 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | テスト項目化 | あり | CSV/帳票 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-32 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-24 | テスト項目化 | あり | 業務操作、CSV/帳票、状態遷移 |
| M04-26 | テスト項目化 | あり | CSV/帳票 |
| M04-28 | テスト項目化 | あり | CSV/帳票 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「振替することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	振替することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 在庫数と在庫変更履歴 / 照合キー: 在庫移動・振替ID・商品コード・出庫元店舗 / 出典: scenario_test/markdown/12_在庫管理.md:211 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2971#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2999#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2666#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2667#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2861#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。 / 振替することを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-002	-	データ更新	P1	正常系 #1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を行い「NMとSP以下で分けて、SP以下はショーケース品として本店に移動することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
2. 「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
【操作後確認】
3. 商品で、NMとSP以下で分けて、SP以下はショーケース品として本店に移動することを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	NMとSP以下で分けて、SP以下はショーケース品として本店に移動することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: NMとSP以下で分けて、SP以下はショーケース品として本店に移動することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-003	M04-09	データ更新	P1	正常系 #2: 店舗チームが「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を行い「在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行うことを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行うことを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行うことを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-004	M04-09	データ更新	P1	正常系 #3: 出庫元店舗の承認者が「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を行い「対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録されること。 実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない状態である」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 出庫元店舗の承認者
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 出庫元店舗の承認者が同じ在庫移動ID を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
【操作後確認】
4. 出庫元店舗の承認者が同じ在庫移動ID で対象キーと 保存しました を記録する"	対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録されること。 実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない状態であること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 在庫移動・振替ID・商品コード・出庫元店舗 / 出典: scenario_test/markdown/12_在庫管理.md:211 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2971#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2999#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2666#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2667#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2861#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 対象移動が出庫承認済みとなり、出庫承認日・承認者と状態履歴が記録されること。 実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-005	M04-08,M04-24	業務操作	P1	正常系 #4: トレードチームが「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を行い「選択した移動が同じ在庫移動指示へ紐づき、移動指示一覧で指示IDと対象移動IDを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md（在庫管理 — 在庫移動・振替検索/一覧）
- この工程で通過する機能: M04-08 在庫管理 — 在庫移動・振替検索/一覧 → M04-24 在庫管理 — 在庫移動指示リスト作成/検索"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md（在庫管理 — 在庫移動・振替検索/一覧）
14. この工程で通過する機能: M04-08 在庫管理 — 在庫移動・振替検索/一覧 → M04-24 在庫管理 — 在庫移動指示リスト作成/検索
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 通過する機能: M04-08 → M04-24。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
【操作後確認】
5. 在庫管理 — 在庫移動・振替検索/一覧 で対象キーと 登録が完了しました。 を記録する"	選択した移動が同じ在庫移動指示へ紐づき、移動指示一覧で指示IDと対象移動IDを確認できること。	"確認場所: 在庫管理 — 在庫移動・振替検索/一覧（M04-08,M04-24） / 照合キー: 在庫移動・振替ID・移動指示ID / 出典: scenario_test/markdown/12_在庫管理.md:213 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2404#sheet-13
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 選択した移動が同じ在庫移動指示へ紐づき、移動指示一覧で指示IDと対象移動IDを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 登録が完了しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-08_admin_stock_stock_move_transfer_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-006	M04-26,M04-27,M04-28	CSV/帳票	P1	正常系 #5: トレードチームが「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を行い「移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-26_admin_stock_stock_move_instruction_picking_list_print.md（M04-26（ピッキングリスト印刷））
- この工程で通過する機能: M04-26 M04-26（ピッキングリスト印刷） → M04-27 M04-27（在庫移動実績入力用CSV出力） → M04-28 M04-28（送り状CSV出力）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-26_admin_stock_stock_move_instruction_picking_list_print.md（M04-26（ピッキングリスト印刷））
14. この工程で通過する機能: M04-26 M04-26（ピッキングリスト印刷） → M04-27 M04-27（在庫移動実績入力用CSV出力） → M04-28 M04-28（送り状CSV出力）
【操作】
1. 管理画面で M04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28） を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 通過する機能: M04-26 → M04-27 → M04-28。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
【操作後確認】
5. M04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28） で対象キーと 処理後の画面表示 を記録する"	移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: M04-26（ピッキングリスト印刷）（M04-26,M04-27,M04-28） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-26_admin_stock_stock_move_instruction_picking_list_print.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-007	-	照合	P1	正常系 #6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を行い「依頼の商品コード・移動点数とピックした現物の商品・点数の一致または差異が記録される」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
2. 「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
【操作後確認】
3. カードで、依頼の商品コード・移動点数とピックした現物の商品・点数の一致または差異が記録されること。の実値と対象データ 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	依頼の商品コード・移動点数とピックした現物の商品・点数の一致または差異が記録されること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:216 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 依頼の商品コード・移動点数とピックした現物の商品・点数の一致または差異が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-008	M04-24	CSV/帳票	P1	正常系 #7: トレードチームが「移動指示IDと送り状No.を記載したCSVを登録する」を行い「対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態である」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する"	対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 照合キー: 移動指示ID・送り状No. / 出典: scenario_test/markdown/12_在庫管理.md:223 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:6797#sheet-32 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:6804#sheet-32 / 設計差・留意点: 原業務フローの旧称「入庫確認待ち」を現行HTML主本文の「移動中」へ具体化。HTML別添sheet52は旧状態名のため主本文を採用。
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 対象指示に送り状No.が登録され、紐づく在庫移動の状態が移動中となる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-009	-	データ更新	P1	正常系 #8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を行い「トレードチームか店舗チームで3Fから2Fへ移動することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
2. 「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
【操作後確認】
3. 解体作業を行い段ボールに入っているピッキングリスト・ここでピッキングリスト・商品・段ボールで、トレードチームか店舗チームで3Fから2Fへ移動することを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	トレードチームか店舗チームで3Fから2Fへ移動することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: トレードチームか店舗チームで3Fから2Fへ移動することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-010	M04-09	データ更新	P1	正常系 #9: 店舗チームが「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を行い「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録される」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 在庫移動・振替ID・商品コード・入庫先店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:230 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3203#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3291#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 同一店舗と店舗間を分けて実施。店舗内移動の新HTMLには独立承認工程がない。
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-010、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-011	M04-01	データ更新	P1	正常系 #10: 店舗チームが「振替を行う」を行い「振替することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「振替を行う」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 処理後の画面表示 を記録する"	振替することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 画面表示・処理ステータス・処理履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-012	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #196 在庫移動指示	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン7 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-01
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#195 在庫移動指示リスト作成検索、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01。
【操作】
産出工程の完了直後に#196 在庫移動指示をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #195 在庫移動指示リスト作成検索 の成果物 #196 在庫移動指示 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #196 在庫移動指示
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 産出工程 #195 在庫移動指示リスト作成検索 の成果物 #196 在庫移動指示 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン7 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-013	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #198 ピッキングリスト	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-02 / 在庫管理 / パターン7 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-34"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-02
照合キー=選択した在庫移動ID＋原本の商品名・略称・言語/状態の組"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#197 在庫移動指示リストエクスポート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=選択した在庫移動ID＋原本の商品名・略称・言語/状態の組。出力対象の在庫移動IDとPDF原本を対応付ける。明細の商品名から略称・言語・状態・色・レアリティを取り除いた表示値と照合する。原本に商品コード列を仮定しない。
【操作】
産出工程の完了直後に#198 ピッキングリストをproducer原本として保存する。
産出原本から 商品名・略称・言語/状態・数・基準価格 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #197 在庫移動指示リストエクスポート の成果物 #198 ピッキングリスト の商品名・略称・言語/状態・数・基準価格が、照合キー 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組 に対応する作業元の確定値と一致する状態であること。	"確認場所: #198 ピッキングリスト
照合キー: 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組
合格条件: 産出工程 #197 在庫移動指示リストエクスポート の成果物 #198 ピッキングリスト の商品名・略称・言語/状態・数・基準価格が、照合キー 選択した在庫移動ID＋原本の商品名・略称・言語/状態の組 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-02 / 在庫管理 / パターン7 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-34
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-014	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #199 在庫移動実績入力用CSV	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-03 / 在庫管理 / パターン7 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-03
照合キー=移動指示ID（当該シードの在庫移動IDに紐づく実ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#197 在庫移動指示リストエクスポート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=移動指示ID（当該シードの在庫移動IDに紐づく実ID）。産出CSVの移動指示IDを記録し、その行の送り状No.に1234-5678を入力する。CSVに商品コード列を追加しない。
【操作】
産出工程の完了直後に#199 在庫移動実績入力用CSVをproducer原本として保存する。
産出原本から 移動指示ID・送り状No. を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #197 在庫移動指示リストエクスポート の成果物 #199 在庫移動実績入力用CSV の移動指示ID・送り状No.が、照合キー 移動指示ID（当該シードの在庫移動IDに紐づく実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #199 在庫移動実績入力用CSV
照合キー: 移動指示ID（当該シードの在庫移動IDに紐づく実ID）
合格条件: 産出工程 #197 在庫移動指示リストエクスポート の成果物 #199 在庫移動実績入力用CSV の移動指示ID・送り状No.が、照合キー 移動指示ID（当該シードの在庫移動IDに紐づく実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-03 / 在庫管理 / パターン7 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-015	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #220 在庫移動	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-04 / 在庫管理 / パターン7 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-04
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#219 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01。
【操作】
産出工程の完了直後に#220 在庫移動をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #219 在庫移動・振替登録 編集 の成果物 #220 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #220 在庫移動
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 産出工程 #219 在庫移動・振替登録 編集 の成果物 #220 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-04 / 在庫管理 / パターン7 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-016	-	データ連鎖	P1	正常系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #226 在庫履歴	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-05 / 在庫管理 / パターン7 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-05
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#219 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01。
【操作】
産出工程の完了直後に#226 在庫履歴をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #219 在庫移動・振替登録 編集 の成果物 #226 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #226 在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 産出工程 #219 在庫移動・振替登録 編集 の成果物 #226 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-05 / 在庫管理 / パターン7 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-017	-	データ連鎖	P1	正常系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #222 在庫（入庫）	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-06 / 在庫管理 / パターン7 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-06
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M04-09, M04-08, M04-24, M04-01; 判定不能=1; 未実装指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: トレードチームが「移動商品チェックとして、NMとSP以下で分けて、SP以下はショーケース品として本店に移動する ショーケース品はTCチームにてチェックを行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「3Fから店舗への在庫移動登録として、在庫はすべて3Fに入庫されるため、ショーケースに出すものは 3F在庫から2F在庫への移動を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: 出庫元店舗の承認者が出庫元店舗の承認者が同じ在庫移動IDで「出庫元店舗の承認者が同じ在庫移動IDを開き、移動商品・移動点数・欠品点数を照合し承認する（実施保留条件: 原典12のフロア間移動は発送を伴う出庫/入庫承認経路だが、現HTML0202 sheet14では店舗種別が本店の店舗同士は店舗内移動となり、店舗内入庫確定で直接入庫完了になる。3F/2Fの店舗種別と採用する業務経路を確定するまで、この発送付き経路は実施保留とする。テストマスタを恣意的に支店種別へ変更して差異を隠さない。）」を実施する
   対象: 移動元ロケーション=本店バックヤード
6. 正常系#4: トレードチームが在庫管理 — 在庫移動・振替検索/一覧で「同じ出庫元・入庫先で出庫承認済みの移動を選択し、在庫移動指示作成を実行して採番された指示IDを控える」を実施する
   対象: 移動元ロケーション=本店バックヤード
7. 正常系#5: トレードチームがM04-27（在庫移動実績入力用CSV出力） ほか（M04-26・M04-27・M04-28）で「ピッキングリスト、在庫移動実績として、移動指示からピッキングリストと送り状と在庫移動実績入力用CSVを出力する」を実施する
   対象: 移動元ロケーション=本店バックヤード
8. 正常系#6: トレードチームが「ピッキングとして、移動対象のカードをピックし依頼に対して差異が無いか確認する」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動指示リスト作成/検索で「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
   対象: 移動元ロケーション=本店バックヤード
10. 正常系#8: 店舗チームが「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
   対象: 移動元ロケーション=本店バックヤード
11. 正常系#9: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
12. 正常系#10: 店舗チームが在庫管理 — 在庫検索/一覧で「振替を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-007-R01
【操作後確認】
13. 最終業務状態「振替することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-06。以下の#番号は原典ノード番号。産出=#219 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-007-R01。
【操作】
産出工程の完了直後に#222 在庫（入庫）をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #219 在庫移動・振替登録 編集 の成果物 #222 在庫（入庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #222 在庫（入庫）
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 産出工程 #219 在庫移動・振替登録 編集 の成果物 #222 在庫（入庫） の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-007-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md データ連鎖 DL-06 / 在庫管理 / パターン7 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-018	M04-24	CSV/帳票	P1	正常系 工程#7 判定: 在庫移動実績CSVの送り状番号反映	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
- 判定用準備: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（移動指示ID・送り状No.）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
判定用具体値: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。"	"担当者: トレードチーム
【準備確認】
判定用準備: 出庫承認済みの移動指示を1件作成し、実IDを記録する。ヘッダ「移動指示ID,送り状No.」、データ「実ID,1234-5678」のCSVを準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する
具体照合: CSV原本と取込後の在庫移動指示詳細を移動指示IDで照合し、送り状No.を文字列比較する。"	在庫移動指示検索で、取り込んだ移動指示IDの送り状No.がCSVの値1234-5678と一致する状態であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 在庫移動実績CSV・在庫移動指示検索/詳細
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 在庫移動指示検索で、取り込んだ移動指示IDの送り状No.がCSVの値1234-5678と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-018、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（移動指示ID・送り状No.）
比較規則: CSV原本と取込後の在庫移動指示詳細を移動指示IDで照合し、送り状No.を文字列比較する。"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-019	M04-24	状態遷移	P1	正常系 工程#7 判定: 在庫移動実績CSVの発送状態	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
- 判定用準備: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（送り状登録後の状態）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
判定用具体値: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。"	"担当者: トレードチーム
【準備確認】
判定用準備: 移動指示IDに紐づく在庫移動IDと出庫承認済み状態を取込前に保存する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md（在庫管理 — 在庫移動指示リスト作成/検索）
【操作】
1. 管理画面で 在庫管理 — 在庫移動指示リスト作成/検索 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「移動指示IDと送り状No.を記載したCSVを登録する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動指示リスト作成/検索 で対象キーと 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。 を記録する
具体照合: 移動指示IDと在庫移動IDの対応を保ったまま、指示の発送状況と移動のステータスを照合する。"	CSVを取り込んだ移動指示の発送状況が「済」、紐づく在庫移動のステータスが「移動中」であること。	"確認場所: 在庫管理 — 在庫移動指示リスト作成/検索（M04-24） / 在庫移動指示検索・在庫移動詳細
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: CSVを取り込んだ移動指示の発送状況が「済」、紐づく在庫移動のステータスが「移動中」であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました / 送り状No.を登録しました。 / 送り状No.を一括登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-019、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-24_admin_stock_stock_move_instruction_search_create.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-32（送り状登録後の状態）
比較規則: 移動指示IDと在庫移動IDの対応を保ったまま、指示の発送状況と移動のステータスを照合する。"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-020	-	在庫整合	P1	正常系 工程#8 判定: 入荷作業の現物と作業元明細の一致	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-STOCK-ZAIKO-007-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md 実行手順 / 在庫管理 / パターン7 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
判定用具体値: ST-STOCK-ZAIKO-007-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 店舗チーム
【準備確認】
判定用準備: ST-STOCK-ZAIKO-007-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
2. 「入荷作業として、トレードチームか店舗チームで3Fから2Fへ移動 商品を入荷したら、解体作業を行い段ボールに入っているピッキングリストをもとに 内容の確認を行う ここでピッキングリストの内容と実際に段ボールに入っている商品数が異なる場合は 発送先であるトレードチームが棄却を行う」を実施する
【操作後確認】
3. 解体作業を行い段ボールに入っているピッキングリスト・ここでピッキングリスト・商品・段ボールで、トレードチームか店舗チームで3Fから2Fへ移動することを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「入荷作業」で扱った商品 ST-STOCK-ZAIKO-007-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 解体作業を行い段ボールに入っているピッキングリスト・ここでピッキングリスト・商品・段ボール・商品別数量照合表
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 「入荷作業」で扱った商品 ST-STOCK-ZAIKO-007-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md 実行手順 / 在庫管理 / パターン7 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
在庫管理 — フロア間移動（原典実線の代表経路）	STI-ZAIKO-010-021	M04-09	在庫整合	P1	正常系 工程#9 判定: 移動先の入庫数量と原価	"元シナリオ: SCN-ZAIKO-フロア間移動-010 フロア間移動（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合
最終業務状態: 振替することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 在庫差異確認欠品あり？の判断結果として実線で「在庫移動実績インポート」へ進む場合、かつ在庫差異確認欠品あり？の判断結果として実線で「在庫移動・振替登録 編集（店舗チーム / 承認者）」へ進む場合、かつ在庫振替対象あり？の判断結果として実線で「振替（店舗チーム / 承認者）」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-007-r01 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
- 判定用準備: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。
- 判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-14（入庫承認時の在庫と原価）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
判定用具体値: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。"	"担当者: 店舗チーム
【準備確認】
判定用準備: 試験用具体値: 移動予定3点・出庫総原価300円、実到着3点、移動先の処理前在庫=5点・総原価500円。入庫承認者でログインし、移動ID・商品コード・出庫元店舗・入庫先店舗を記録する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-010-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-007-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-010-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-007-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-007-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-007-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-007-r01 / 商品コード=ST-STOCK-ZAIKO-007-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-007-R01 / 移動元ロケーション=本店バックヤード
3. 「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する
具体照合: 移動IDに紐づく入庫履歴と前後在庫を比較し、移動先在庫5+3=8点、総原価500+300=800円を確認する。"	同一在庫移動IDの入庫先で、在庫が実入庫数3点、総原価が300円増加する状態であること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 在庫移動・振替登録/編集・在庫一覧・在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-007-R01
合格条件: 同一在庫移動IDの入庫先で、在庫が実入庫数3点、総原価が300円増加する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-010-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-010-021、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-フロア間移動-010_フロア間移動（原典実線の代表経路）.md / 在庫管理 / パターン7 / 経路1
判定根拠: excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-14（入庫承認時の在庫と原価）
比較規則: 移動IDに紐づく入庫履歴と前後在庫を比較し、移動先在庫5+3=8点、総原価500+300=800円を確認する。"
```
