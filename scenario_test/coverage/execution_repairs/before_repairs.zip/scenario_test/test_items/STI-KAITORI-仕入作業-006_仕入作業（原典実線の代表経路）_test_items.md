<!-- generated-by: hareruya-scenario-test-items -->
# 店頭買取 — 仕入作業（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M06-01 | テスト項目化 | あり | CSV/帳票 |
| M06-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M06-11 | テスト項目化 | あり | CSV/帳票 |
| M06-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M06-01, M06-11; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M06-01, M06-11; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
3. 正常系#1: 店舗チームが店頭買取管理 — 買取検索一覧で「入庫待ちまたは入庫済みで棚戻し未完了の買取を選び、戻しリストPDFを出力する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-002-R01
4. 正常系#2: 店舗チームが「価格ソートとして、2Fでの商品の保管場所に応じて価格ソートする 並び順ファイルの『色分け』にある『NM価格orPLD価格』をコピーして、 販売価格の列に『書式設定(R)』で貼り付けする 販売価格に色が付くので、金庫→キャビネット→通販棚の順になるよう色で 並べ替えを行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
5. 正常系#3: 店舗チームが「スリーブ入れとして、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼る」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
6. 正常系#4: 店舗チームが「棚に戻すとして、棚に戻す」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
【操作後確認】
7. 最終業務状態「棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 照合キー: 査定ID・商品コード / 出典: scenario_test/markdown/06_店頭買取.md:64 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1263#sheet-4 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1268#sheet-4 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-002	M06-01,M06-11	CSV/帳票	P1	正常系 #1: 店舗チームが「入庫待ちまたは入庫済みで棚戻し未完了の買取を選び、戻しリストPDFを出力する」を行い「同じ査定IDの実在庫の商品・数量がPDFに出力され、対象買取の棚戻し済みフラグが立つ状態である」を確認する	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m06-01_admin_store_purchase_purchase_store_search_list.md（店頭買取管理 — 買取検索一覧）
- この工程で通過する機能: M06-01 店頭買取管理 — 買取検索一覧 → M06-11 M06-11（戻しリストPDF出力）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m06-01_admin_store_purchase_purchase_store_search_list.md（店頭買取管理 — 買取検索一覧）
14. この工程で通過する機能: M06-01 店頭買取管理 — 買取検索一覧 → M06-11 M06-11（戻しリストPDF出力）
【操作】
1. 管理画面で 店頭買取管理 — 買取検索一覧 を開く
2. 対象データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
3. 通過する機能: M06-01 → M06-11。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「入庫待ちまたは入庫済みで棚戻し未完了の買取を選び、戻しリストPDFを出力する」を実施する
【操作後確認】
5. 店頭買取管理 — 買取検索一覧 で対象キーと 処理後の画面表示 を記録する"	同じ査定IDの実在庫の商品・数量がPDFに出力され、対象買取の棚戻し済みフラグが立つ状態であること。	"確認場所: 店頭買取管理 — 買取検索一覧（M06-01,M06-11） / 照合キー: 査定ID・商品コード / 出典: scenario_test/markdown/06_店頭買取.md:64 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1263#sheet-4 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1268#sheet-4
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 同じ査定IDの実在庫の商品・数量がPDFに出力され、対象買取の棚戻し済みフラグが立つ状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m06-01_admin_store_purchase_purchase_store_search_list.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-003	-	データ更新	P1	正常系 #2: 店舗チームが「価格ソートとして、2Fでの商品の保管場所に応じて価格ソートする 並び順ファイルの『色分け』にある『NM価格orPLD価格』をコピーして、 販売価格の列に『書式設定(R)』で貼り付けする 販売価格に色が付くので、金庫→キャビネット→通販棚の順になるよう色で 並べ替えを行う」を行い「2Fでの商品の保管場所に応じて価格ソートすることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
2. 「価格ソートとして、2Fでの商品の保管場所に応じて価格ソートする 並び順ファイルの『色分け』にある『NM価格orPLD価格』をコピーして、 販売価格の列に『書式設定(R)』で貼り付けする 販売価格に色が付くので、金庫→キャビネット→通販棚の順になるよう色で 並べ替えを行う」を実施する
【操作後確認】
3. 並び順ファイル・商品・棚で、2Fでの商品の保管場所に応じて価格ソートすることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01 の対応を記録する"	2Fでの商品の保管場所に応じて価格ソートすることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 2Fでの商品の保管場所に応じて価格ソートすることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-004	-	データ更新	P1	正常系 #3: 店舗チームが「スリーブ入れとして、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼る」を行い「価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼ることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
2. 「スリーブ入れとして、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼る」を実施する
【操作後確認】
3. スリーブで、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼ることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01 の対応を記録する"	価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼ることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼ることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-005	-	データ更新	P1	正常系 #4: 店舗チームが「棚に戻すとして、棚に戻す」を行い「棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
2. 「棚に戻すとして、棚に戻す」を実施する
【操作後確認】
3. 棚で、棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01 の対応を記録する"	棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-006	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #42 棚戻し業務用PDF出力	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M06-01, M06-11; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-01 / 店頭買取 / パターン2 / 経路1 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html#sheet-9"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
連鎖ID=DL-01
照合キー=出力時の買取ID＋原本の略称・商品名・言語/状態の組"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M06-01, M06-11; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
3. 正常系#1: 店舗チームが店頭買取管理 — 買取検索一覧で「入庫待ちまたは入庫済みで棚戻し未完了の買取を選び、戻しリストPDFを出力する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-002-R01
4. 正常系#2: 店舗チームが「価格ソートとして、2Fでの商品の保管場所に応じて価格ソートする 並び順ファイルの『色分け』にある『NM価格orPLD価格』をコピーして、 販売価格の列に『書式設定(R)』で貼り付けする 販売価格に色が付くので、金庫→キャビネット→通販棚の順になるよう色で 並べ替えを行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
5. 正常系#3: 店舗チームが「スリーブ入れとして、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼る」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
6. 正常系#4: 店舗チームが「棚に戻すとして、棚に戻す」を実施する
   対象: 商品コード=ST-CARD-KAITORI-002-R01
【操作後確認】
7. 最終業務状態「棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#43 買取一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=出力時の買取ID＋原本の略称・商品名・言語/状態の組。出力対象の買取ID一覧とファイルを対応付ける。帳票に存在しない買取ID列を仮定せず、選択元明細の商品名・略称・言語/状態から表示用の組を作り、同じ組の数量を合算して比較する。
【操作】
産出工程の完了直後に#42 棚戻し業務用PDF出力をproducer原本として保存する。
産出原本から 略称・商品名・言語/状態・数・基準価格 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #43 買取一覧 の成果物 #42 棚戻し業務用PDF出力 の略称・商品名・言語/状態・数・基準価格が、照合キー 出力時の買取ID＋原本の略称・商品名・言語/状態の組 に対応する作業元の確定値と一致する状態であること。	"確認場所: #42 棚戻し業務用PDF出力
照合キー: 出力時の買取ID＋原本の略称・商品名・言語/状態の組
合格条件: 産出工程 #43 買取一覧 の成果物 #42 棚戻し業務用PDF出力 の略称・商品名・言語/状態・数・基準価格が、照合キー 出力時の買取ID＋原本の略称・商品名・言語/状態の組 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-01 / 店頭買取 / パターン2 / 経路1 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html#sheet-9
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-007	-	データ連鎖	P1	正常系 DL-02: 産出値と消費値の照合 — #45 並び順ファイル	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M06-01, M06-11; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 産出値と消費値の照合
- 原典判定: 起点（産出元の記載なし・消費工程で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-02 / 店頭買取 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/06_店頭買取.md 本文・原典ノード/接続表
- 解除条件: #45 並び順ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#45 並び順ファイルの取得方法を確定する。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
連鎖ID=DL-02
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-02: #45 並び順ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#45 並び順ファイルの取得方法を確定する。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #45 並び順ファイル
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-02 / 店頭買取 / パターン2 / 経路1 / 調査済出典: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/06_店頭買取.md 本文・原典ノード/接続表
連鎖判定: 起点（産出元の記載なし・消費工程で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
店頭買取 — 仕入作業（原典実線の代表経路）	STI-KAITORI-006-008	-	在庫整合	P1	正常系 工程#3 判定: スリーブ入れの現物と作業元明細の一致	"元シナリオ: SCN-KAITORI-仕入作業-006 仕入作業（原典実線の代表経路）
業務: 店頭買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 棚に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-kaitori-002-r01 / 会員番号=ST-MEMBER-KAITORI-002-R01 / 商品コード=ST-CARD-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 査定対象商品=ST-CARD-KAITORI-002-R01 / 査定金額=1,200円 / 買取ステータス=査定中
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-CARD-KAITORI-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md 実行手順 / 店頭買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
判定用具体値: ST-CARD-KAITORI-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 店舗チーム
【準備確認】
判定用準備: ST-CARD-KAITORI-002-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01
2. 「スリーブ入れとして、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼る」を実施する
【操作後確認】
3. スリーブで、価格ソートが完了したらそれぞれに対応したスリーブ入れと ステータスシールを貼ることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-002-r01 / 商品コード=ST-CARD-KAITORI-002-R01 / 買取受付番号=ST-BUY-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-002-R01 の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「スリーブ入れ」で扱った商品 ST-CARD-KAITORI-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: スリーブ・商品別数量照合表
照合キー: 買取受付番号=ST-BUY-KAITORI-002-R01
合格条件: 「スリーブ入れ」で扱った商品 ST-CARD-KAITORI-002-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-006-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-006-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md / 店頭買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-KAITORI-仕入作業-006_仕入作業（原典実線の代表経路）.md 実行手順 / 店頭買取 / パターン2 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
```
