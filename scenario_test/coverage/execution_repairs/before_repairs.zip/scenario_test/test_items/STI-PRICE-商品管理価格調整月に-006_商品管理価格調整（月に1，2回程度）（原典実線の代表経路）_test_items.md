<!-- generated-by: hareruya-scenario-test-items -->
# 価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M03-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-30 | テスト項目化 | あり | CSV/帳票、金額整合 |
| M03-31 | テスト項目化 | あり | CSV/帳票、金額整合 |
| M03-32 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-33 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-36 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-06 | テスト項目化 | あり | CSV/帳票 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
3. 正常系#1: トレードチームが商品管理 — カスタムデータ CSV ダウンロード（商品情報）で「商品マスターで通常作業用のカスタムCSVを選択してダウンロードする」を実施する
   対象: 商品コード=ST-CARD-PRICE-006-R01
4. 正常系#2: トレードチームが「価格確認作業として、ダウンロードした範囲に「並び順ファイル」から並び順を充てる。 在庫数や販売数、別途データがあればバックヤードの残数を参考に 販売・買取価格が適正かチェックし、変更点があれば 販売価格/買取価格の横に列を挿入し変更価格をメモしていく」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-006-R01.csv
5. 正常系#3: トレードチームが「価格変更用ファイル作成として、価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成する。 その後、変更後の価格を入力した価格変更用CSVを作成する ※価格変更共有用ファイルを関係各所へ共有する トレードに対して価格変更の確認をお願いしている」を実施する
   対象: 変更後価格=550円
6. 正常系#4: トレードチームが商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31）で「価格変更反映作業として、価格変更用csvを商品csv管理＞価格変更csvよりインポートする。 ※原則はトレードチームが対応」を実施する
   対象: 変更後価格=550円
【操作後確認】
7. 最終業務状態「価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 照合キー: 商品コード / 出典: scenario_test/markdown/11_価格管理.md:84 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1735#sheet-7 / 設計差・留意点: 通常作業用の出力設定はテスト環境に同名設定を準備する。売上分析そのものはM12-03/04。 / 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-002	M03-06	CSV/帳票	P1	正常系 #1: トレードチームが「商品マスターで通常作業用のカスタムCSVを選択してダウンロードする」を行い「対象商品コードの在庫数量と出力時点の商品情報がCSVへ引き継がれる状態である」を確認する	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-06_admin_product_product_custom_csv_export.md（商品管理 — カスタムデータ CSV ダウンロード（商品情報））
- 必須入力欄: CSV 種別 / 出力名"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-06_admin_product_product_custom_csv_export.md（商品管理 — カスタムデータ CSV ダウンロード（商品情報））
14. 必須入力欄: CSV 種別 / 出力名
【操作】
1. 管理画面で 商品管理 — カスタムデータ CSV ダウンロード（商品情報） を開く
2. 対象データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
3. 「商品マスターで通常作業用のカスタムCSVを選択してダウンロードする」を実施する
【操作後確認】
4. 商品管理 — カスタムデータ CSV ダウンロード（商品情報） で対象キーと 処理後の画面表示 を記録する"	対象商品コードの在庫数量と出力時点の商品情報がCSVへ引き継がれる状態であること。	"確認場所: 商品管理 — カスタムデータ CSV ダウンロード（商品情報）（M03-06） / 照合キー: 商品コード / 出典: scenario_test/markdown/11_価格管理.md:84 / excel_to_html/output/0204_基本設計仕様書(商品管理).html:1735#sheet-7 / 設計差・留意点: 通常作業用の出力設定はテスト環境に同名設定を準備する。売上分析そのものはM12-03/04。
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: 対象商品コードの在庫数量と出力時点の商品情報がCSVへ引き継がれる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-06_admin_product_product_custom_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-003	-	CSV/帳票	P1	正常系 #2: トレードチームが「価格確認作業として、ダウンロードした範囲に「並び順ファイル」から並び順を充てる。 在庫数や販売数、別途データがあればバックヤードの残数を参考に 販売・買取価格が適正かチェックし、変更点があれば 販売価格/買取価格の横に列を挿入し変更価格をメモしていく」を行い「ダウンロードした範囲に「並び順ファイル」から並び順を充てることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
2. 「価格確認作業として、ダウンロードした範囲に「並び順ファイル」から並び順を充てる。 在庫数や販売数、別途データがあればバックヤードの残数を参考に 販売・買取価格が適正かチェックし、変更点があれば 販売価格/買取価格の横に列を挿入し変更価格をメモしていく」を実施する
【操作後確認】
3. 並び順ファイルで、ダウンロードした範囲に「並び順ファイル」から並び順を充てることを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01 の対応を記録する"	ダウンロードした範囲に「並び順ファイル」から並び順を充てることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: ダウンロードした範囲に「並び順ファイル」から並び順を充てることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-004	-	CSV/帳票	P1	正常系 #3: トレードチームが「価格変更用ファイル作成として、価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成する。 その後、変更後の価格を入力した価格変更用CSVを作成する ※価格変更共有用ファイルを関係各所へ共有する トレードに対して価格変更の確認をお願いしている」を行い「価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
2. 「価格変更用ファイル作成として、価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成する。 その後、変更後の価格を入力した価格変更用CSVを作成する ※価格変更共有用ファイルを関係各所へ共有する トレードに対して価格変更の確認をお願いしている」を実施する
【操作後確認】
3. 価格変更用ファイル・変更価格メモを残した商品を抜粋し価格変更共有用ファイル・変更後の価格を入力した価格変更用CSV・価格変更共有用ファイル・商品で、価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01 の対応を記録する"	価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: 価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-005	M03-30,M03-31	CSV/帳票	P1	正常系 #4: トレードチームが「価格変更反映作業として、価格変更用csvを商品csv管理＞価格変更csvよりインポートする。 ※原則はトレードチームが対応」を行い「価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
- 必須入力欄: CSVファイル
- この工程で通過する機能: M03-30 商品管理 — 価格変更CSV登録 → M03-31 M03-31（セール用価格変更CSV登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
14. 必須入力欄: CSVファイル
15. この工程で通過する機能: M03-30 商品管理 — 価格変更CSV登録 → M03-31 M03-31（セール用価格変更CSV登録）
【操作】
1. 管理画面で 商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31） を開く
2. 対象データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
3. 通過する機能: M03-30 → M03-31。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「価格変更反映作業として、価格変更用csvを商品csv管理＞価格変更csvよりインポートする。 ※原則はトレードチームが対応」を実施する
【操作後確認】
5. 商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31） で対象キーと 処理後の画面表示 を記録する"	価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 商品管理 — 価格変更CSV登録（M03-30,M03-31） / 取込結果と対象件数・エラー行
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-006	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #47 並び順ファイル	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン6 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-01 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表 / scenario_test/coverage/source_contracts.json SC-118 / scenario_test/markdown/11_価格管理.md R98 / excel_to_html/output/0204_基本設計仕様書(商品管理).html  / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html  / scenario_test/coverage/source_contracts.json SC-119 / scenario_test/markdown/11_価格管理.md R113 / scenario_test/coverage/source_contracts.json SC-134 / scenario_test/markdown/11_価格管理.md R77
- 解除条件: #47 並び順ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
連鎖ID=DL-01
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-01: #47 並び順ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #47 並び順ファイル
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン6 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-01 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表 / scenario_test/coverage/source_contracts.json SC-118 / scenario_test/markdown/11_価格管理.md R98 / excel_to_html/output/0204_基本設計仕様書(商品管理).html  / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html  / scenario_test/coverage/source_contracts.json SC-119 / scenario_test/markdown/11_価格管理.md R113 / scenario_test/coverage/source_contracts.json SC-134 / scenario_test/markdown/11_価格管理.md R77
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-007	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #50 価格変更共有用ファイル	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-02 / 価格管理 / パターン6 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
- 解除条件: #50 価格変更共有用ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
連鎖ID=DL-02
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-02: #50 価格変更共有用ファイルの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #50 価格変更共有用ファイル
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-02 / 価格管理 / パターン6 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-02 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-008	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #54 商品*4	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-03 / 価格管理 / パターン6 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
連鎖ID=DL-03
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-30, M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
3. 正常系#1: トレードチームが商品管理 — カスタムデータ CSV ダウンロード（商品情報）で「商品マスターで通常作業用のカスタムCSVを選択してダウンロードする」を実施する
   対象: 商品コード=ST-CARD-PRICE-006-R01
4. 正常系#2: トレードチームが「価格確認作業として、ダウンロードした範囲に「並び順ファイル」から並び順を充てる。 在庫数や販売数、別途データがあればバックヤードの残数を参考に 販売・買取価格が適正かチェックし、変更点があれば 販売価格/買取価格の横に列を挿入し変更価格をメモしていく」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-006-R01.csv
5. 正常系#3: トレードチームが「価格変更用ファイル作成として、価格の適正チェックが完了したら、 変更価格メモを残した商品を抜粋し価格変更共有用ファイルを作成する。 その後、変更後の価格を入力した価格変更用CSVを作成する ※価格変更共有用ファイルを関係各所へ共有する トレードに対して価格変更の確認をお願いしている」を実施する
   対象: 変更後価格=550円
6. 正常系#4: トレードチームが商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31）で「価格変更反映作業として、価格変更用csvを商品csv管理＞価格変更csvよりインポートする。 ※原則はトレードチームが対応」を実施する
   対象: 変更後価格=550円
【操作後確認】
7. 最終業務状態「価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#53 価格変更CSV登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#54 商品*4をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #53 価格変更CSV登録 の成果物 #54 商品*4 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #54 商品*4
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #53 価格変更CSV登録 の成果物 #54 商品*4 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md データ連鎖 DL-03 / 価格管理 / パターン6 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
価格管理 — 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）	STI-PRICE-006-009	M03-30,M03-31	金額整合	P1	正常系 工程#4 判定: 基準価格変更の販売価格への反映	"元シナリオ: SCN-PRICE-商品管理価格調整月に-006 商品管理価格調整（月に1，2回程度）（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 価格変更用csvを商品csv管理＞価格変更csvよりインポートすることを、取込結果と対象件数・エラー行で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-006-r01 / 会員番号=ST-MEMBER-PRICE-006-R01 / 商品コード=ST-CARD-PRICE-006-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 対象商品コード=ST-CARD-PRICE-006-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
- 必須入力欄: CSVファイル
- この工程で通過する機能: M03-30 商品管理 — 価格変更CSV登録 → M03-31 M03-31（セール用価格変更CSV登録）
- 判定用準備: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。
- 判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-42（セールフラグ無効時の基準/販売/買取価格更新）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
判定用具体値: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。"	"担当者: トレードチーム
【準備確認】
判定用準備: 試験用具体値: セールフラグ=0、更新前基準価格=販売価格=1,000円。基準価格変更CSVに当該商品ID・言語ID、基準価格1,200円、買取価格500円を設定する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-006-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-006-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-006-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-006-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md（商品管理 — 価格変更CSV登録）
14. 必須入力欄: CSVファイル
15. この工程で通過する機能: M03-30 商品管理 — 価格変更CSV登録 → M03-31 M03-31（セール用価格変更CSV登録）
【操作】
1. 管理画面で 商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31） を開く
2. 対象データ: 担当者アカウント=st-user-price-006-r01 / 商品コード=ST-CARD-PRICE-006-R01 / 価格変更CSV=ST-PRICE-PRICE-006-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-006-R01
3. 通過する機能: M03-30 → M03-31。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「価格変更反映作業として、価格変更用csvを商品csv管理＞価格変更csvよりインポートする。 ※原則はトレードチームが対応」を実施する
【操作後確認】
5. 商品管理 — 価格変更CSV登録 ほか（M03-30・M03-31） で対象キーと 処理後の画面表示 を記録する
具体照合: 入力CSVと更新後の商品規格詳細を商品ID・言語IDで照合し、更新後価格を1,200円・1,200円・500円の組と比較する。"	対象の商品ID・言語IDで、基準価格と販売価格がともに1,200円、買取価格が500円の状態であること。	"確認場所: 商品管理 — 価格変更CSV登録（M03-30,M03-31） / 基準価格変更CSV・商品規格詳細
照合キー: 商品コード=ST-CARD-PRICE-006-R01
合格条件: 対象の商品ID・言語IDで、基準価格と販売価格がともに1,200円、買取価格が500円の状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-006-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-006-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-30_admin_product_product_product_price_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-商品管理価格調整月に-006_商品管理価格調整（月に1，2回程度）（原典実線の代表経路）.md / 価格管理 / パターン6 / 経路1
判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-42（セールフラグ無効時の基準/販売/買取価格更新）
比較規則: 入力CSVと更新後の商品規格詳細を商品ID・言語IDで照合し、更新後価格を1,200円・1,200円・500円の組と比較する。"
```
