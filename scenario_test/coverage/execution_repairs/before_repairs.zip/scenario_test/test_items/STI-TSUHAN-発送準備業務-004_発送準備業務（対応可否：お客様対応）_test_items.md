<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — 発送準備業務（対応可否：お客様対応） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | テスト項目化 | あり | 代替フロー |
| M05-04 | テスト項目化 | あり | 代替フロー |
| M05-05 | テスト項目化 | あり | 代替フロー |
| M05-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-18 | テスト項目化 | あり | 代替フロー |
| M05-19 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-21 | テスト項目化 | あり | 代替フロー |
| M05-22 | テスト項目化 | あり | 代替フロー |
| M05-23 | テスト項目化 | あり | 代替フロー |
| M05-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-26 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-03 | テスト項目化 | あり | 代替フロー |
| M05-06 | テスト項目化 | あり | 代替フロー |
| M05-11 | テスト項目化 | あり | 代替フロー |
| M05-12 | テスト項目化 | あり | 代替フロー |
| M05-14 | テスト項目化 | あり | 代替フロー |
| M05-15 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
4. 代替系#2: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
5. 代替系#3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
6. 代替系#4: 通販チームが受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
7. 代替系#5: 通販チームが受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23）で「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
8. 代替系#6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
9. 代替系#7: 通販チームが受注管理 — 受注情報検索・一覧で「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
10. 代替系#8: 通販チームが受注管理 — 出荷指示リスト作成で「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
11. 代替系#9: 通販チームが受注管理 — 配送CSVダウンロードで「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
12. 代替系#10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
13. 代替系#11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
14. 代替系#12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
15. 代替系#13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
16. 代替系#14: 通販チームが受注管理 — カスタム配送CSVダウンロードで「発送業務へとして、発送業務へ」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
【操作後確認】
17. 最終業務状態「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 照合キー: 受注番号・商品コード / 出典: scenario_test/markdown/16_通販受注管理.md:44 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:1880#sheet-8 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:1614#sheet-6 / 一覧・詳細に追加された対象データ / 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認） / 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-002	M05-01,M05-05,M05-03	代替フロー	P1	代替系 #1: 通販チームが「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を行い「同じ受注番号の商品・数量・配送先が各CSVに引き継がれる状態である」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
- この工程で通過する機能: M05-01 受注管理 — 受注情報検索・一覧 → M05-05 受注管理 — カスタム配送CSVダウンロード → M05-03 受注管理 — カスタム受注CSVダウンロード"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
15. この工程で通過する機能: M05-01 受注管理 — 受注情報検索・一覧 → M05-05 受注管理 — カスタム配送CSVダウンロード → M05-03 受注管理 — カスタム受注CSVダウンロード
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 通過する機能: M05-01 → M05-05 → M05-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
【操作後確認】
5. 受注管理 — 受注情報検索・一覧 で対象キーと 処理後の画面表示 を記録する"	同じ受注番号の商品・数量・配送先が各CSVに引き継がれる状態であること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01,M05-05,M05-03） / 照合キー: 受注番号・商品コード / 出典: scenario_test/markdown/16_通販受注管理.md:44 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:1880#sheet-8 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:1614#sheet-6
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 同じ受注番号の商品・数量・配送先が各CSVに引き継がれる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-003	M05-14,M05-12,M05-15,M05-06	代替フロー	P1	代替系 #2: 通販チームが「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を行い「マクロの情報から出荷指示リストの作成を行うための注文番号を生成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md（受注管理 — 受注対応状況の変更）
- 必須入力欄: 対応状況
- この工程で通過する機能: M05-14 受注管理 — 受注対応状況の変更 → M05-12 m05-12_admin_order_order_bulk_status_change（管理画面_受注管理_対応状況一括変更） → M05-15 受注管理 — 受注詳細メール通知 → M05-06 受注管理 — メール一括送信"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md（受注管理 — 受注対応状況の変更）
15. 必須入力欄: 対応状況
16. この工程で通過する機能: M05-14 受注管理 — 受注対応状況の変更 → M05-12 m05-12_admin_order_order_bulk_status_change（管理画面_受注管理_対応状況一括変更） → M05-15 受注管理 — 受注詳細メール通知 → M05-06 受注管理 — メール一括送信
【操作】
1. 管理画面で 受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06） を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 通過する機能: M05-14 → M05-12 → M05-15 → M05-06。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
【操作後確認】
5. 受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06） で対象キーと 保存しました を記録する"	マクロの情報から出荷指示リストの作成を行うための注文番号を生成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 受注管理 — 受注対応状況の変更（M05-14,M05-12,M05-15,M05-06） / 一覧・詳細に追加された対象データ
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: マクロの情報から出荷指示リストの作成を行うための注文番号を生成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-004	-	代替フロー	P1	代替系 #3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を行い「注文備考や受注内容から対応が必要か確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、注文備考や受注内容から対応が必要か確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	注文備考や受注内容から対応が必要か確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 注文備考や受注内容から対応が必要か確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-005	M05-15,M05-11	代替フロー	P1	代替系 #4: 通販チームが「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を行い「注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md（受注管理 — 受注詳細メール通知）
- 必須入力欄: 件名
- この工程で通過する機能: M05-15 受注管理 — 受注詳細メール通知 → M05-11 受注管理 — 受注情報編集"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md（受注管理 — 受注詳細メール通知）
15. 必須入力欄: 件名
16. この工程で通過する機能: M05-15 受注管理 — 受注詳細メール通知 → M05-11 受注管理 — 受注情報編集
【操作】
1. 管理画面で 受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11） を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 通過する機能: M05-15 → M05-11。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
【操作後確認】
5. 受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11） で対象キーと 保存しました を記録する"	注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 受注管理 — 受注詳細メール通知（M05-15,M05-11） / 送信されたメール/通知の内容と送信状態
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-006	M05-18,M05-21,M05-22,M05-23	代替フロー	P1	代替系 #5: 通販チームが「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を行い「マクロで生成したデータを使って、出荷指示リストの生成を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
- この工程で通過する機能: M05-18 受注管理 — 出荷指示リスト作成 → M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語） → M05-23 受注管理 — 出荷指示：納品書印刷（英語）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
15. この工程で通過する機能: M05-18 受注管理 — 出荷指示リスト作成 → M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語） → M05-23 受注管理 — 出荷指示：納品書印刷（英語）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23） を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 通過する機能: M05-18 → M05-21 → M05-22 → M05-23。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
【操作後確認】
5. 受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23） で対象キーと 保存しました を記録する"	マクロで生成したデータを使って、出荷指示リストの生成を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18,M05-21,M05-22,M05-23） / 一覧・詳細に追加された対象データ
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: マクロで生成したデータを使って、出荷指示リストの生成を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-007	-	代替フロー	P1	代替系 #6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を行い「バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行うことを、更新後の値と更新履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
【操作後確認】
3. 発送台帳・発送管理台帳で、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行うことを、更新後の値と更新履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行うことを、更新後の値と更新履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行うことを、更新後の値と更新履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-008	M05-01	代替フロー	P1	代替系 #7: 通販チームが「発送ラベルの準備として、送り状CSVをダウンロードする」を行い「送り状CSVをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
【操作後確認】
4. 受注管理 — 受注情報検索・一覧 で対象キーと 処理後の画面表示 を記録する"	送り状CSVをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 出力されたCSV/帳票の件数と内容
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 送り状CSVをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-009	M05-18	代替フロー	P1	代替系 #8: 通販チームが「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を行い「送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込むことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 保存しました を記録する"	送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込むことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 出力されたCSV/帳票の件数と内容
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込むことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-010	M05-04	代替フロー	P1	代替系 #9: 通販チームが「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を行い「ラベル印字アプリにてラベル発行が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-04_admin_order_order_shipping_csv_export.md（受注管理 — 配送CSVダウンロード）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-04_admin_order_order_shipping_csv_export.md（受注管理 — 配送CSVダウンロード）
【操作】
1. 管理画面で 受注管理 — 配送CSVダウンロード を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
【操作後確認】
4. 受注管理 — 配送CSVダウンロード で対象キーと 処理後の画面表示 を記録する"	ラベル印字アプリにてラベル発行が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — 配送CSVダウンロード（M05-04） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: ラベル印字アプリにてラベル発行が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-010、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-04_admin_order_order_shipping_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-011	-	代替フロー	P1	代替系 #10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を行い「印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリングが完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリングが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリングが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリングが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-012	-	代替フロー	P1	代替系 #11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を行い「ピッキングリストより在庫から発送予定の商品のピック作業を行うことを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
【操作後確認】
3. ピッキングリスト・商品で、ピッキングリストより在庫から発送予定の商品のピック作業を行うことを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	ピッキングリストより在庫から発送予定の商品のピック作業を行うことを、在庫数と在庫変更履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: ピッキングリストより在庫から発送予定の商品のピック作業を行うことを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-013	-	代替フロー	P1	代替系 #12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を行い「ピックした商品を発送先ごとに振り分けることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
【操作後確認】
3. 商品で、ピックした商品を発送先ごとに振り分けることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	ピックした商品を発送先ごとに振り分けることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: ピックした商品を発送先ごとに振り分けることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-014	-	代替フロー	P1	代替系 #13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を行い「発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「梱包作業として、発送する商品の梱包作業を行う」を実施する
【操作後確認】
3. 商品で、発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する"	発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-015	M05-05	代替フロー	P1	代替系 #14: 通販チームが「発送業務へとして、発送業務へ」を行い「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-05_admin_order_order_shipping_custom_csv_export.md（受注管理 — カスタム配送CSVダウンロード）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-05_admin_order_order_shipping_custom_csv_export.md（受注管理 — カスタム配送CSVダウンロード）
【操作】
1. 管理画面で 受注管理 — カスタム配送CSVダウンロード を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 「発送業務へとして、発送業務へ」を実施する
【操作後確認】
4. 受注管理 — カスタム配送CSVダウンロード で対象キーと 処理後の画面表示 を記録する"	発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — カスタム配送CSVダウンロード（M05-05） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-015、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-05_admin_order_order_shipping_custom_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-016	M05-15	代替フロー	P1	代替系 A1 #1: 通販チームが「対応可否の判断結果として実線で「お客様対応」へ進む場合」を行い「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 分岐条件を満たす対象データを、正常代表データとは別IDで用意する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md（受注管理 — 受注詳細メール通知）
- 必須入力欄: 件名"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=対応可否の判断結果として実線で「お客様対応」へ進む場合
入力=条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たす対象データ / 受注番号=ST-ORDER-TSUHAN-002-R02-A1 / 基準=受注番号=ST-ORDER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘5件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md（受注管理 — 受注詳細メール通知）
15. 必須入力欄: 件名
【操作】
1. 管理画面で 受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で 条件「対応可否の判断結果として実線 を開く
2. 対象データ: 条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たす対象データ / 受注番号=ST-ORDER-TSUHAN-002-R02-A1 / 基準=受注番号=ST-ORDER-TSUHAN-002-R02
3. 分岐条件「分岐条件を満たす対象データを、正常代表データとは別IDで用意する。」を成立させる
4. 「対応可否の判断結果として実線で「お客様対応」へ進む場合」を実施する
【操作後確認】
5. 受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で 条件「対応可否の判断結果として実線 で対象キーと 処理後の画面表示 を記録する"	発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — 受注詳細メール通知（M05-15） / 送信されたメール/通知の内容と送信状態
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-016、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m05-15_admin_order_order_mail.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-017	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #22 発送管理台帳	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-01 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
連鎖ID=DL-01
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
4. 代替系#2: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
5. 代替系#3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
6. 代替系#4: 通販チームが受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
7. 代替系#5: 通販チームが受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23）で「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
8. 代替系#6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
9. 代替系#7: 通販チームが受注管理 — 受注情報検索・一覧で「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
10. 代替系#8: 通販チームが受注管理 — 出荷指示リスト作成で「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
11. 代替系#9: 通販チームが受注管理 — 配送CSVダウンロードで「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
12. 代替系#10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
13. 代替系#11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
14. 代替系#12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
15. 代替系#13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
16. 代替系#14: 通販チームが受注管理 — カスタム配送CSVダウンロードで「発送業務へとして、発送業務へ」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
【操作後確認】
17. 最終業務状態「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#23 出荷指示リスト作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02。
【操作】
産出工程の完了直後に#22 発送管理台帳をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #23 出荷指示リスト作成 の成果物 #22 発送管理台帳 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #22 発送管理台帳
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 産出工程 #23 出荷指示リスト作成 の成果物 #22 発送管理台帳 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-01 / 通販受注管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-018	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #31 出荷指示*1	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-02 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
連鎖ID=DL-02
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
4. 代替系#2: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
5. 代替系#3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
6. 代替系#4: 通販チームが受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
7. 代替系#5: 通販チームが受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23）で「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
8. 代替系#6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
9. 代替系#7: 通販チームが受注管理 — 受注情報検索・一覧で「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
10. 代替系#8: 通販チームが受注管理 — 出荷指示リスト作成で「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
11. 代替系#9: 通販チームが受注管理 — 配送CSVダウンロードで「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
12. 代替系#10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
13. 代替系#11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
14. 代替系#12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
15. 代替系#13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
16. 代替系#14: 通販チームが受注管理 — カスタム配送CSVダウンロードで「発送業務へとして、発送業務へ」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
【操作後確認】
17. 最終業務状態「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#30 出荷指示、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02。
【操作】
産出工程の完了直後に#31 出荷指示*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #30 出荷指示 の成果物 #31 出荷指示*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #31 出荷指示*1
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 産出工程 #30 出荷指示 の成果物 #31 出荷指示*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-02 / 通販受注管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-019	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #40 発送管理台帳	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-03 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
連鎖ID=DL-03
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
4. 代替系#2: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
5. 代替系#3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
6. 代替系#4: 通販チームが受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
7. 代替系#5: 通販チームが受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23）で「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
8. 代替系#6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
9. 代替系#7: 通販チームが受注管理 — 受注情報検索・一覧で「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
10. 代替系#8: 通販チームが受注管理 — 出荷指示リスト作成で「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
11. 代替系#9: 通販チームが受注管理 — 配送CSVダウンロードで「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
12. 代替系#10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
13. 代替系#11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
14. 代替系#12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
15. 代替系#13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
16. 代替系#14: 通販チームが受注管理 — カスタム配送CSVダウンロードで「発送業務へとして、発送業務へ」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
【操作後確認】
17. 最終業務状態「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#39 台帳更新作業、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02。
【操作】
産出工程の完了直後に#40 発送管理台帳をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #39 台帳更新作業 の成果物 #40 発送管理台帳 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #40 発送管理台帳
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 産出工程 #39 台帳更新作業 の成果物 #40 発送管理台帳 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-03 / 通販受注管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-020	-	データ連鎖	P1	代替系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #42 出荷指示*1	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-04 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
連鎖ID=DL-04
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-05, M05-03, M05-14, M05-12, M05-15, M05-06, M05-04; 未実装指摘あり=5; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-002-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-004-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-002-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「対応可否の判断結果として実線で「お客様対応」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「指定時刻に台帳用の検索条件で受注を検索し、通販配送CSVと特殊商品用CSVを出力する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
4. 代替系#2: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「出荷指示リスト作成として、マクロの情報から出荷指示リストの作成を行うための注文番号を生成する ダウンロードしたファイルからマクロでデータを成型 追加があった受注も受注管理マクロに貼り付けマクロを実行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
5. 代替系#3: 通販チームが「個別対応可否確認として、注文備考や受注内容から対応が必要か確認する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
6. 代替系#4: 通販チームが受注管理 — 受注詳細メール通知 ほか（M05-15・M05-11）で「お客様対応として、注文備考や受注内容から対応が必要であれば 手動メール通知のメールテンプレートからメール対応、 必要あれば受注情報を更新」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
7. 代替系#5: 通販チームが受注管理 — 出荷指示リスト作成 ほか（M05-18・M05-21・M05-22・M05-23）で「出荷指示リスト作成として、マクロで生成したデータを使って、出荷指示リストの生成を行う 生成した出荷指示リストより、 注文備考の確認および大量注文をはじき出した上で、 ピッキングリスト・日本語納品書・英語納品書を出力する ※出荷準備は入金が無くても進めており、受注IDを使ってリストの生成を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
8. 代替系#6: 通販チームが「発送台帳更新作業として、バックオフィスでの作業完了後に 発送管理台帳の情報更新作業を行う ※同梱対応、受注欄の備考反映」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
9. 代替系#7: 通販チームが受注管理 — 受注情報検索・一覧で「発送ラベルの準備として、送り状CSVをダウンロードする」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
10. 代替系#8: 通販チームが受注管理 — 出荷指示リスト作成で「発送ラベル発行として、送り状CSVダウンロードで出力したデータをラベル印字アプリに取り込む ラベルに印字する必要がある追加要望については手動追記」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
11. 代替系#9: 通販チームが受注管理 — 配送CSVダウンロードで「発送ラベル発行処理として、ラベル印字アプリにてラベル発行」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
12. 代替系#10: 通販チームが「ペアリング対応として、印刷した情報に不備がないか確認をしながら納品書と発送ラベルをペアリング」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
13. 代替系#11: 通販チームが「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
14. 代替系#12: 通販チームが「振り分け作業として、ピックした商品を発送先ごとに振り分ける」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
15. 代替系#13: 通販チームが「梱包作業として、発送する商品の梱包作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
16. 代替系#14: 通販チームが受注管理 — カスタム配送CSVダウンロードで「発送業務へとして、発送業務へ」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-002-R02
【操作後確認】
17. 最終業務状態「発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#41 出荷指示、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-002-R02。
【操作】
産出工程の完了直後に#42 出荷指示*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #41 出荷指示 の成果物 #42 出荷指示*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #42 出荷指示*1
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 産出工程 #41 出荷指示 の成果物 #42 出荷指示*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md データ連鎖 DL-04 / 通販受注管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-021	-	在庫整合	P1	代替系 工程#11 判定: ピック作業の現物と作業元明細の一致	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md 実行手順 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
判定用具体値: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 通販チーム
【準備確認】
判定用準備: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「ピック作業として、ピッキングリストより在庫から発送予定の商品のピック作業を行う」を実施する
【操作後確認】
3. ピッキングリスト・商品で、ピッキングリストより在庫から発送予定の商品のピック作業を行うことを、在庫数と在庫変更履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「ピック作業」で扱った商品 ST-CARD-TSUHAN-002-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: ピッキングリスト・商品・商品別数量照合表
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 「ピック作業」で扱った商品 ST-CARD-TSUHAN-002-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-021、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md 実行手順 / 通販受注管理 / パターン2 / 経路2
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
通販受注管理 — 発送準備業務（対応可否：お客様対応）	STI-TSUHAN-004-022	-	在庫整合	P1	代替系 工程#13 判定: 梱包作業の現物と作業元明細の一致	"元シナリオ: SCN-TSUHAN-発送準備業務-004 発送準備業務（対応可否：お客様対応）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 対応可否の判断結果として実線で「お客様対応」へ進む場合
最終業務状態: 発送業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 対応可否の判断結果として実線で「お客様対応」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-002-r02 / 会員番号=ST-MEMBER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md 実行手順 / 通販受注管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
判定用具体値: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 通販チーム
【準備確認】
判定用準備: ST-CARD-TSUHAN-002-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02
2. 「梱包作業として、発送する商品の梱包作業を行う」を実施する
【操作後確認】
3. 商品で、発送する商品の梱包作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-002-r02 / 受注番号=ST-ORDER-TSUHAN-002-R02 / 商品コード=ST-CARD-TSUHAN-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-002-R02 の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「梱包作業」で扱った商品 ST-CARD-TSUHAN-002-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 商品・商品別数量照合表
照合キー: 受注番号=ST-ORDER-TSUHAN-002-R02
合格条件: 「梱包作業」で扱った商品 ST-CARD-TSUHAN-002-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-004-022/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-004-022、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md / 通販受注管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-発送準備業務-004_発送準備業務（対応可否：お客様対応）.md 実行手順 / 通販受注管理 / パターン2 / 経路2
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
```
