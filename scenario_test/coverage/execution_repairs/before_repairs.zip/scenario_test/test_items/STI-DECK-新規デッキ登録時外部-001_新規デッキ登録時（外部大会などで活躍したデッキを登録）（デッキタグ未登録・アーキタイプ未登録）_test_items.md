<!-- generated-by: hareruya-scenario-test-items -->
# デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| A15-13 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-16 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-07 | テスト項目化 | あり | データ更新 |
| M15-08 | テスト項目化 | あり | データ更新 |
| M15-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-05 | テスト項目化 | あり | データ更新 |
| M15-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-17 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 正常系#1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
4. 正常系#2: 顧客戦略チームがデッキ管理 — デッキタグ一覧（カスタム管理画面）で「デッキタグ登録として、登録しようとしているデッキに該当するタグが無い場合、登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
5. 正常系#3: 顧客戦略チームがpf-eccube3 — デッキ管理 — アーキタイプ検索で「アーキタイプ登録として、登録しようとしているデッキに該当するアーキタイプが無い場合、登録する ※」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
6. 正常系#4: 顧客戦略チームがデッキ管理 — 新規登録・編集・削除・複製で「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
【操作後確認】
7. 最終業務状態「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 一覧・詳細に追加された対象データ / 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: デッキID=ST-DECK-DECK-001-R01
合格条件: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-002	-	データ更新	P1	正常系 #1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を行い「イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
2. 「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、イベント情報、デッキ情報を取得 「EVENT COVERAGE」など？が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録 の対応を記録する"	イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: デッキID=ST-DECK-DECK-001-R01
合格条件: イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-003	M15-07	データ更新	P1	正常系 #2: 顧客戦略チームが「デッキタグ登録として、登録しようとしているデッキに該当するタグが無い場合、登録する」を行い「登録しようとしているデッキに該当するタグが無い場合、登録することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m15-07_admin_deck_deck_tag_list.md（デッキ管理 — デッキタグ一覧（カスタム管理画面））
- 必須入力欄: 日本語名 / 英語名 / 表示順"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m15-07_admin_deck_deck_tag_list.md（デッキ管理 — デッキタグ一覧（カスタム管理画面））
14. 必須入力欄: 日本語名 / 英語名 / 表示順
【操作】
1. 管理画面で デッキ管理 — デッキタグ一覧（カスタム管理画面） を開く
2. 対象データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 「デッキタグ登録として、登録しようとしているデッキに該当するタグが無い場合、登録する」を実施する
【操作後確認】
4. デッキ管理 — デッキタグ一覧（カスタム管理画面） で対象キーと 処理後の画面表示 を記録する"	登録しようとしているデッキに該当するタグが無い場合、登録することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: デッキ管理 — デッキタグ一覧（カスタム管理画面）（M15-07） / 一覧・詳細に追加された対象データ
照合キー: デッキID=ST-DECK-DECK-001-R01
合格条件: 登録しようとしているデッキに該当するタグが無い場合、登録することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-07_admin_deck_deck_tag_list.md
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-004	M15-08	データ更新	P1	正常系 #3: 顧客戦略チームが「アーキタイプ登録として、登録しようとしているデッキに該当するアーキタイプが無い場合、登録する ※」を行い「登録しようとしているデッキに該当するアーキタイプが無い場合、登録することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m15-08_admin_deck_deck_archetype_search.md（pf-eccube3 — デッキ管理 — アーキタイプ検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m15-08_admin_deck_deck_archetype_search.md（pf-eccube3 — デッキ管理 — アーキタイプ検索）
【操作】
1. 管理画面で pf-eccube3 — デッキ管理 — アーキタイプ検索 を開く
2. 対象データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 「アーキタイプ登録として、登録しようとしているデッキに該当するアーキタイプが無い場合、登録する ※」を実施する
【操作後確認】
4. pf-eccube3 — デッキ管理 — アーキタイプ検索 で対象キーと 処理後の画面表示 を記録する"	登録しようとしているデッキに該当するアーキタイプが無い場合、登録することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: pf-eccube3 — デッキ管理 — アーキタイプ検索（M15-08） / 一覧・詳細に追加された対象データ
照合キー: デッキID=ST-DECK-DECK-001-R01
合格条件: 登録しようとしているデッキに該当するアーキタイプが無い場合、登録することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-08_admin_deck_deck_archetype_search.md
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-005	M15-05	データ更新	P1	正常系 #4: 顧客戦略チームが「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を行い「登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致される」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
- 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
14. 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時
【操作】
1. 管理画面で デッキ管理 — 新規登録・編集・削除・複製 を開く
2. 対象データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
【操作後確認】
4. デッキ管理 — 新規登録・編集・削除・複製 で対象キーと 保存しました を記録する"	登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致されること。	"確認場所: デッキ管理 — 新規登録・編集・削除・複製（M15-05） / 照合キー: デッキID / 出典: scenario_test/markdown/18_デッキ登録.md:31 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html:1452#sheet-5
照合キー: デッキID=ST-DECK-DECK-001-R01
合格条件: 登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-006	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #3 デッキ管理	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md データ連鎖 DL-01 / デッキ登録 / パターン1 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
連鎖ID=DL-01
照合キー=デッキID（登録後の実ID）"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 正常系#1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
4. 正常系#2: 顧客戦略チームがデッキ管理 — デッキタグ一覧（カスタム管理画面）で「デッキタグ登録として、登録しようとしているデッキに該当するタグが無い場合、登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
5. 正常系#3: 顧客戦略チームがpf-eccube3 — デッキ管理 — アーキタイプ検索で「アーキタイプ登録として、登録しようとしているデッキに該当するアーキタイプが無い場合、登録する ※」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
6. 正常系#4: 顧客戦略チームがデッキ管理 — 新規登録・編集・削除・複製で「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
【操作後確認】
7. 最終業務状態「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#2 デッキタグ一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=デッキID（登録後の実ID）。登録結果のデッキIDを当該プレイヤー・イベントと対応付けて保存し、入力したデッキ内容と登録結果を比較する。
【操作】
産出工程の完了直後に#3 デッキ管理をproducer原本として保存する。
産出原本から デッキID・プレイヤー・イベント・デッキ内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #2 デッキタグ一覧 の成果物 #3 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #3 デッキ管理
照合キー: デッキID（登録後の実ID）
合格条件: 産出工程 #2 デッキタグ一覧 の成果物 #3 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md データ連鎖 DL-01 / デッキ登録 / パターン1 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）	STI-DECK-001-007	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #3 デッキ管理	"元シナリオ: SCN-DECK-新規デッキ登録時外部-001 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r01 / 会員番号=ST-MEMBER-DECK-001-R01 / 商品コード=ST-CARD-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R01 / 大会ID=ST-EVENT-DECK-001-R01 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=未登録 / アーキタイプ=未登録
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md データ連鎖 DL-02 / デッキ登録 / パターン1 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
連鎖ID=DL-02
照合キー=デッキID（登録後の実ID）"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M15-07, M15-08; 未実装指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-deck-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「デッキタグ=未登録、アーキタイプ=未登録（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-001-r01 / 商品コード=ST-CARD-DECK-001-R01 / デッキID=ST-DECK-DECK-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R01 / デッキタグ=未登録 / アーキタイプ=未登録
3. 正常系#1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
4. 正常系#2: 顧客戦略チームがデッキ管理 — デッキタグ一覧（カスタム管理画面）で「デッキタグ登録として、登録しようとしているデッキに該当するタグが無い場合、登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
5. 正常系#3: 顧客戦略チームがpf-eccube3 — デッキ管理 — アーキタイプ検索で「アーキタイプ登録として、登録しようとしているデッキに該当するアーキタイプが無い場合、登録する ※」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
6. 正常系#4: 顧客戦略チームがデッキ管理 — 新規登録・編集・削除・複製で「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R01
【操作後確認】
7. 最終業務状態「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#5 アーキタイプ管理、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=デッキID（登録後の実ID）。登録結果のデッキIDを当該プレイヤー・イベントと対応付けて保存し、入力したデッキ内容と登録結果を比較する。
【操作】
産出工程の完了直後に#3 デッキ管理をproducer原本として保存する。
産出原本から デッキID・プレイヤー・イベント・デッキ内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #5 アーキタイプ管理 の成果物 #3 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #3 デッキ管理
照合キー: デッキID（登録後の実ID）
合格条件: 産出工程 #5 アーキタイプ管理 の成果物 #3 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-001-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-001-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md / デッキ登録 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-001_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ未登録・アーキタイプ未登録）.md データ連鎖 DL-02 / デッキ登録 / パターン1 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
