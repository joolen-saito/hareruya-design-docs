<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-31 | テスト項目化 | あり | 代替フロー |
| M04-01 | テスト項目化 | あり | 代替フロー |
| M04-17 | テスト項目化 | あり | 代替フロー |
| M04-18 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-001	-	業務経路	P1	代替系 経路全体 R03: 主要代替として「商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 代替系#1: 店舗統括チームが「1として、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロード ※毎週日曜日に翌週対応する範囲を決めている」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
4. 代替系#2: 店舗統括チームが在庫管理 — 棚卸計画で「2として、棚卸計画の作成 棚卸計画を作成する TCチームと通販チームに棚卸範囲を共有する この際、TCチームには手つかずの大口ピックや視点移動ピックに」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 代替系#3: トレードチームが在庫管理 — 在庫検索/一覧で「棚卸範囲共有として、TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
6. 代替系#4: 店舗統括チームが在庫管理 — 在庫履歴検索/一覧で「4として、棚卸結果の取り込み 棚卸結果の反映を権限のある人が行う 反映すると在庫の増減が行われる」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
7. 代替系#5: トレードチームが在庫管理 — 在庫履歴CSV出力で「5として、棚卸結果の反映」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
【操作後確認】
8. 最終業務状態「商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 在庫数と在庫変更履歴 / 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-002	-	代替フロー	P1	代替系 #1: 店舗統括チームが「1として、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロード ※毎週日曜日に翌週対応する範囲を決めている」を行い「毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: 店舗統括チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
2. 「1として、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロード ※毎週日曜日に翌週対応する範囲を決めている」を実施する
【操作後確認】
3. 実施日に該当するファイルで、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム の対応を記録する"	毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロードが完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-003	M04-31	代替フロー	P1	代替系 #2: 店舗統括チームが「2として、棚卸計画の作成 棚卸計画を作成する TCチームと通販チームに棚卸範囲を共有する この際、TCチームには手つかずの大口ピックや視点移動ピックに」を行い「棚卸計画の作成することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md（在庫管理 — 棚卸計画）
- 必須入力欄: 棚卸名"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: 店舗統括チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md（在庫管理 — 棚卸計画）
14. 必須入力欄: 棚卸名
【操作】
1. 管理画面で 在庫管理 — 棚卸計画 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 「2として、棚卸計画の作成 棚卸計画を作成する TCチームと通販チームに棚卸範囲を共有する この際、TCチームには手つかずの大口ピックや視点移動ピックに」を実施する
【操作後確認】
4. 在庫管理 — 棚卸計画 で対象キーと 棚卸計画を登録しました。 / 登録が完了しました。 / 棚卸数量を登録しました。 を記録する"	棚卸計画の作成することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 棚卸計画（M04-31） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 棚卸計画の作成することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 棚卸計画を登録しました。 / 登録が完了しました。 / 棚卸数量を登録しました。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-004	M04-01	代替フロー	P1	代替系 #3: トレードチームが「棚卸範囲共有として、TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合する」を行い「TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 「棚卸範囲共有として、TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合する」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 処理後の画面表示 を記録する"	TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-005	M04-17	代替フロー	P1	代替系 #4: 店舗統括チームが「4として、棚卸結果の取り込み 棚卸結果の反映を権限のある人が行う 反映すると在庫の増減が行われる」を行い「棚卸結果の取り込み 棚卸結果の反映を権限のある人が行うことを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-17_admin_stock_stock_history_search_list.md（在庫管理 — 在庫履歴検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: 店舗統括チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘6件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-17_admin_stock_stock_history_search_list.md（在庫管理 — 在庫履歴検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫履歴検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 「4として、棚卸結果の取り込み 棚卸結果の反映を権限のある人が行う 反映すると在庫の増減が行われる」を実施する
【操作後確認】
4. 在庫管理 — 在庫履歴検索/一覧 で対象キーと 処理後の画面表示 を記録する"	棚卸結果の取り込み 棚卸結果の反映を権限のある人が行うことを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫履歴検索/一覧（M04-17） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 棚卸結果の取り込み 棚卸結果の反映を権限のある人が行うことを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-17_admin_stock_stock_history_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-006	M04-18	代替フロー	P1	代替系 #5: トレードチームが「5として、棚卸結果の反映」を行い「棚卸結果の反映することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-18_admin_stock_stock_history_csv_export.md（在庫管理 — 在庫履歴CSV出力）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-18_admin_stock_stock_history_csv_export.md（在庫管理 — 在庫履歴CSV出力）
【操作】
1. 管理画面で 在庫管理 — 在庫履歴CSV出力 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 「5として、棚卸結果の反映」を実施する
【操作後確認】
4. 在庫管理 — 在庫履歴CSV出力 で対象キーと 処理後の画面表示 を記録する"	棚卸結果の反映することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫履歴CSV出力（M04-18） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 棚卸結果の反映することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-18_admin_stock_stock_history_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-007	M04-31	代替フロー	P1	代替系 A1 #1: 商品管理チームが「未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）」を行い「商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: システム外（外部）（EC-CUBEの実行可否とは無関係）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md（在庫管理 — 棚卸計画）
- 必須入力欄: 棚卸名"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
入力=商品コード=ST-STOCK-ZAIKO-010-R03-A1 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム"	"担当者: 商品管理チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: システム外（外部）（EC-CUBEの実行可否とは無関係）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md（在庫管理 — 棚卸計画）
14. 必須入力欄: 棚卸名
【操作】
1. 管理画面で 在庫管理 — 棚卸計画 を開く
2. 対象データ: 商品コード=ST-STOCK-ZAIKO-010-R03-A1 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 分岐条件「棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。」を成立させる
4. 「未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）」を実施する
【操作後確認】
5. 在庫管理 — 棚卸計画 で対象キーと 処理後の画面表示 を記録する"	商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。	"確認場所: 在庫管理 — 棚卸計画（M04-31） / 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映された
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-31_admin_stock_stock_inventory_plan.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-008	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #292 低額棚卸作業ファイル	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md データ連鎖 DL-01 / 在庫管理 / パターン10 / 経路3"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
連鎖ID=DL-01
照合キー=商品コード=ST-STOCK-ZAIKO-010-R03"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 代替系#1: 店舗統括チームが「1として、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロード ※毎週日曜日に翌週対応する範囲を決めている」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
4. 代替系#2: 店舗統括チームが在庫管理 — 棚卸計画で「2として、棚卸計画の作成 棚卸計画を作成する TCチームと通販チームに棚卸範囲を共有する この際、TCチームには手つかずの大口ピックや視点移動ピックに」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 代替系#3: トレードチームが在庫管理 — 在庫検索/一覧で「棚卸範囲共有として、TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
6. 代替系#4: 店舗統括チームが在庫管理 — 在庫履歴検索/一覧で「4として、棚卸結果の取り込み 棚卸結果の反映を権限のある人が行う 反映すると在庫の増減が行われる」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
7. 代替系#5: トレードチームが在庫管理 — 在庫履歴CSV出力で「5として、棚卸結果の反映」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
【操作後確認】
8. 最終業務状態「商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#291 低額棚卸作業ファイル取得、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-010-R03。
【操作】
産出工程の完了直後に#292 低額棚卸作業ファイルをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #291 低額棚卸作業ファイル取得 の成果物 #292 低額棚卸作業ファイル の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-010-R03 に対応する作業元の確定値と一致する状態であること。	"確認場所: #292 低額棚卸作業ファイル
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: 産出工程 #291 低額棚卸作業ファイル取得 の成果物 #292 低額棚卸作業ファイル の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-010-R03 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3
判定根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md データ連鎖 DL-01 / 在庫管理 / パターン10 / 経路3
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）	STI-ZAIKO-039-009	-	データ連鎖	P1	代替系 DL-02: 産出値と消費値の照合 — #294 棚卸計画	"元シナリオ: SCN-ZAIKO-棚卸作業-039 棚卸作業（未処理ピックが多い場合の棚卸範囲照合）
業務: 在庫管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）
最終業務状態: 商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 棚卸範囲の商品コードを含む未処理ピック一覧を用意し、商品管理チームが照合結果を返せるようにする。
シードデータ: 担当者アカウント=st-user-zaiko-010-r03 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 産出値と消費値の照合
- 原典判定: 連鎖あり（HTML設計書由来）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md データ連鎖 DL-02 / 在庫管理 / パターン10 / 経路3"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
連鎖ID=DL-02
照合キー=商品コード=ST-STOCK-ZAIKO-010-R03"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-17; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-039-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-010-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-039-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-010-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-010-R03 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-010-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「未処理ピック件数が多くTC・通販側で照合困難（原典本文 12_在庫管理.md R630–632「手つかずピックの量が多く確認が困難な場合は、商品管理チームにて」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-010-r03 / 商品コード=ST-STOCK-ZAIKO-010-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-010-R03 / 移動元ロケーション=本店バックヤード / 棚卸区分=低額 / 未処理ピック=確認困難と判定した一覧 / 棚卸範囲照合担当=商品管理チーム
3. 代替系#1: 店舗統括チームが「1として、毎月2週目＆4週目の月曜から金曜 実施日に該当するファイルをダウンロード ※毎週日曜日に翌週対応する範囲を決めている」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
4. 代替系#2: 店舗統括チームが在庫管理 — 棚卸計画で「2として、棚卸計画の作成 棚卸計画を作成する TCチームと通販チームに棚卸範囲を共有する この際、TCチームには手つかずの大口ピックや視点移動ピックに」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 代替系#3: トレードチームが在庫管理 — 在庫検索/一覧で「棚卸範囲共有として、TCチームと通販チームで未処理ピックの確認が困難なため、商品管理チームが棚卸対象カードとの重複を照合する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
6. 代替系#4: 店舗統括チームが在庫管理 — 在庫履歴検索/一覧で「4として、棚卸結果の取り込み 棚卸結果の反映を権限のある人が行う 反映すると在庫の増減が行われる」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
7. 代替系#5: トレードチームが在庫管理 — 在庫履歴CSV出力で「5として、棚卸結果の反映」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-010-R03
【操作後確認】
8. 最終業務状態「商品管理チームが未処理ピックと棚卸範囲の重複を照合した後、同じ棚卸計画の実数が反映されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#295 棚卸計画、消費=棚卸確定（dtb_inventory_plan→dtb_product_stock）（HTML設計書由来）。
照合キー=商品コード=ST-STOCK-ZAIKO-010-R03。
【操作】
産出工程の完了直後に#294 棚卸計画をproducer原本として保存する。
棚卸確定（dtb_inventory_plan→dtb_product_stock）（HTML設計書由来）で実際に参照した原本をconsumer原本として保存し、原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）をproducer原本と同じ照合キーで比較する。工程間で変更した列は原典に明記された変換だけを許容し、その計算過程を別記する。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	#295 棚卸計画で産出した#294 棚卸計画の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、棚卸確定（dtb_inventory_plan→dtb_product_stock）（HTML設計書由来）が参照した値と照合キー 商品コード=ST-STOCK-ZAIKO-010-R03 で一致する状態であること。	"確認場所: #294 棚卸計画
照合キー: 商品コード=ST-STOCK-ZAIKO-010-R03
合格条件: #295 棚卸計画で産出した#294 棚卸計画の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、棚卸確定（dtb_inventory_plan→dtb_product_stock）（HTML設計書由来）が参照した値と照合キー 商品コード=ST-STOCK-ZAIKO-010-R03 で一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-039-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-039-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md / 在庫管理 / パターン10 / 経路3
判定根拠: scenario_test/scenario/SCN-ZAIKO-棚卸作業-039_棚卸作業（未処理ピックが多い場合の棚卸範囲照合）.md データ連鎖 DL-02 / 在庫管理 / パターン10 / 経路3
連鎖判定: 連鎖あり（HTML設計書由来）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
