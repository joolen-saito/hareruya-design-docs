<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | テスト項目化 | あり | 代替フロー |
| M05-18 | テスト項目化 | あり | 代替フロー |
| M05-21 | テスト項目化 | あり | 代替業務、代替フロー、在庫整合 |
| M05-22 | テスト項目化 | あり | 代替業務、在庫整合 |
| M05-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-26 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-19 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「出荷指示再作成作業として、シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出す」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
4. 代替系#2: 通販チームが受注管理 — 出荷指示リスト作成で「発送準備作業として、再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
5. 代替系#3: 通販チームが受注管理 — ピッキングリスト印刷で「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
6. 代替系#4: 通販チームが「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
7. 代替系#5: 通販チームが「発売前日の15時締めで対象予約受注を抽出し、同じ受注番号・発送先・個口を記載したチェックシートを作成する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
8. 代替系#6: 通販チームが「インポートデータ作成として、インポートデータを作成しておく」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
9. 代替系#7: 通販チームが受注管理 — ピッキングリスト印刷で「発送業務へとして、発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
【操作後確認】
10. 最終業務状態「受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。	"確認場所: 一覧・詳細に追加された対象データ / 出力されたCSV/帳票の件数と内容 / 照合キー: 受注番号・商品コード / 出典: scenario_test/markdown/16_通販受注管理.md:196 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:4335#sheet-20 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:4477#sheet-21 / 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-002	M05-01	代替フロー	P1	代替系 #1: 通販チームが「出荷指示再作成作業として、シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出す」を行い「シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出すことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 「出荷指示再作成作業として、シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出す」を実施する
【操作後確認】
4. 受注管理 — 受注情報検索・一覧 で対象キーと 検索条件を保存しました を記録する"	シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出すことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 一覧・詳細に追加された対象データ
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出すことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索条件を保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-003	M05-18	代替フロー	P1	代替系 #2: 通販チームが「発送準備作業として、再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管」を行い「再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管が完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 「発送準備作業として、再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 保存しました を記録する"	再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 出力されたCSV/帳票の件数と内容
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-004	M05-21,M05-22	代替業務	P1	代替系 #3: 通販チームが「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を行い「対象受注番号の商品・数量がピッキングリストに表示され、除外したキャンセル受注が含まれない状態である」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）
- この工程で通過する機能: M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）
15. この工程で通過する機能: M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語）
【操作】
1. 管理画面で 受注管理 — ピッキングリスト印刷 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 通過する機能: M05-21 → M05-22。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を実施する
【操作後確認】
5. 受注管理 — ピッキングリスト印刷 で対象キーと 処理後の画面表示 を記録する"	対象受注番号の商品・数量がピッキングリストに表示され、除外したキャンセル受注が含まれない状態であること。	"確認場所: 受注管理 — ピッキングリスト印刷（M05-21,M05-22） / 照合キー: 受注番号・商品コード / 出典: scenario_test/markdown/16_通販受注管理.md:196 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:4335#sheet-20 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:4477#sheet-21
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 対象受注番号の商品・数量がピッキングリストに表示され、除外したキャンセル受注が含まれない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-005	-	代替フロー	P1	代替系 #4: 通販チームが「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を行い「現物の商品・数量・受注番号が指示書と一致し、発売前の保管場所と作業完了を記録できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
2. 「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を実施する
【操作後確認】
3. 照合キー: 受注番号・商品コード・発売日 / 出典: scenario_test/markdown/16_通販受注管理.md:197で、現物の商品・数量・受注番号が指示書と一致し、発売前の保管場所と作業完了を記録できるの実値と対象データ 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件 の対応を記録する"	現物の商品・数量・受注番号が指示書と一致し、発売前の保管場所と作業完了を記録できること。	"確認場所: 照合キー: 受注番号・商品コード・発売日 / 出典: scenario_test/markdown/16_通販受注管理.md:197
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 現物の商品・数量・受注番号が指示書と一致し、発売前の保管場所と作業完了を記録できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-006	-	代替フロー	P1	代替系 #5: 通販チームが「発売前日の15時締めで対象予約受注を抽出し、同じ受注番号・発送先・個口を記載したチェックシートを作成する」を行い「締め時刻以前の対象注文が同じ受注番号でチェックシートに載り、梱包対象と漏れなく照合できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
2. 「発売前日の15時締めで対象予約受注を抽出し、同じ受注番号・発送先・個口を記載したチェックシートを作成する」を実施する
【操作後確認】
3. 照合キー: 受注番号・発売日 / 出典: scenario_test/markdown/16_通販受注管理.md:198で、締め時刻以前の対象注文が同じ受注番号でチェックシートに載り、梱包対象と漏れなく照合できるの実値と対象データ 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件 の対応を記録する"	締め時刻以前の対象注文が同じ受注番号でチェックシートに載り、梱包対象と漏れなく照合できること。	"確認場所: 照合キー: 受注番号・発売日 / 出典: scenario_test/markdown/16_通販受注管理.md:198
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 締め時刻以前の対象注文が同じ受注番号でチェックシートに載り、梱包対象と漏れなく照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-007	-	代替フロー	P1	代替系 #6: 通販チームが「インポートデータ作成として、インポートデータを作成しておく」を行い「インポートデータを作成しておくことを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
2. 「インポートデータ作成として、インポートデータを作成しておく」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、インポートデータを作成しておくことを、取込結果と対象件数・エラー行で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件 の対応を記録する"	インポートデータを作成しておくことを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: インポートデータを作成しておくことを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-008	M05-21	代替フロー	P1	代替系 #7: 通販チームが「発送業務へとして、発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了」を行い「発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）
【操作】
1. 管理画面で 受注管理 — ピッキングリスト印刷 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 「発送業務へとして、発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了」を実施する
【操作後確認】
4. 受注管理 — ピッキングリスト印刷 で対象キーと 処理後の画面表示 を記録する"	発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 受注管理 — ピッキングリスト印刷（M05-21） / 取込結果と対象件数・エラー行
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-009	M05-01	代替フロー	P1	代替系 A1 #1: 通販チームが「シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）」を行い「受注番号=ST-ORDER-TSUHAN-011-R02 を含む出力物を取得できる」を確認する	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
入力=受注番号=ST-ORDER-TSUHAN-011-R02-A1 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 受注番号=ST-ORDER-TSUHAN-011-R02-A1 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 分岐条件「同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。」を成立させる
4. 「シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）」を実施する
【操作後確認】
5. 受注管理 — 受注情報検索・一覧 で対象キーと 処理後の画面表示 を記録する"	受注番号=ST-ORDER-TSUHAN-011-R02 を含む出力物を取得できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しない
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 受注番号=ST-ORDER-TSUHAN-011-R02 を含む出力物を取得できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-010	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #190 出荷指示*2	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md データ連鎖 DL-01 / 通販受注管理 / パターン11 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
連鎖ID=DL-01
照合キー=受注番号=ST-ORDER-TSUHAN-011-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「出荷指示再作成作業として、シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出す」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
4. 代替系#2: 通販チームが受注管理 — 出荷指示リスト作成で「発送準備作業として、再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
5. 代替系#3: 通販チームが受注管理 — ピッキングリスト印刷で「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
6. 代替系#4: 通販チームが「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
7. 代替系#5: 通販チームが「発売前日の15時締めで対象予約受注を抽出し、同じ受注番号・発送先・個口を記載したチェックシートを作成する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
8. 代替系#6: 通販チームが「インポートデータ作成として、インポートデータを作成しておく」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
9. 代替系#7: 通販チームが受注管理 — ピッキングリスト印刷で「発送業務へとして、発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
【操作後確認】
10. 最終業務状態「受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#189 出荷指示、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-011-R02。
【操作】
産出工程の完了直後に#190 出荷指示*2をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #189 出荷指示 の成果物 #190 出荷指示*2 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-011-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #190 出荷指示*2
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 産出工程 #189 出荷指示 の成果物 #190 出荷指示*2 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-011-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md データ連鎖 DL-01 / 通販受注管理 / パターン11 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-011	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #197 出荷データ*3	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md データ連鎖 DL-02 / 通販受注管理 / パターン11 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
連鎖ID=DL-02
照合キー=受注番号=ST-ORDER-TSUHAN-011-R02"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 代替系#1: 通販チームが受注管理 — 受注情報検索・一覧で「出荷指示再作成作業として、シングルカードの出荷指示に不要な予約が多く含まれるため、未開封製品と同じく受注マスター検索から納品書とラベルデータを取り出す」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
4. 代替系#2: 通販チームが受注管理 — 出荷指示リスト作成で「発送準備作業として、再作成した出荷指示ごとに、コメント対応を行いながら 納品書・ラベルを印刷、ペアリングを行い作業日まで保管」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
5. 代替系#3: 通販チームが受注管理 — ピッキングリスト印刷で「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
6. 代替系#4: 通販チームが「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
7. 代替系#5: 通販チームが「発売前日の15時締めで対象予約受注を抽出し、同じ受注番号・発送先・個口を記載したチェックシートを作成する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
8. 代替系#6: 通販チームが「インポートデータ作成として、インポートデータを作成しておく」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
9. 代替系#7: 通販チームが受注管理 — ピッキングリスト印刷で「発送業務へとして、発送チェックを行い発売日に集荷を開始 集荷完了後に出荷インポートを行い出荷処理を完了」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-011-R02
【操作後確認】
10. 最終業務状態「受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#196 インポートデータ作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-011-R02。
【操作】
産出工程の完了直後に#197 出荷データ*3をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #196 インポートデータ作成 の成果物 #197 出荷データ*3 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-011-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #197 出荷データ*3
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 産出工程 #196 インポートデータ作成 の成果物 #197 出荷データ*3 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-011-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md データ連鎖 DL-02 / 通販受注管理 / パターン11 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-012	M05-21,M05-22	在庫整合	P1	代替系 工程#3 判定: ピック表作成の現物と作業元明細の一致	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）
- この工程で通過する機能: M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語）
- 判定用準備: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md 実行手順 / 通販受注管理 / パターン11 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
判定用具体値: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 通販チーム
【準備確認】
判定用準備: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-020-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-011-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-011-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-011-R02 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-020-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-011-R02 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md（受注管理 — ピッキングリスト印刷）
15. この工程で通過する機能: M05-21 受注管理 — ピッキングリスト印刷 → M05-22 受注管理 — 出荷指示：納品書印刷（日本語）
【操作】
1. 管理画面で 受注管理 — ピッキングリスト印刷 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
3. 通過する機能: M05-21 → M05-22。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「作業日時点のキャンセル注文を除外し、対象出荷指示のピッキングリストを印刷する」を実施する
【操作後確認】
5. 受注管理 — ピッキングリスト印刷 で対象キーと 処理後の画面表示 を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「ピック表作成」で扱った商品 ST-CARD-TSUHAN-011-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 受注管理 — ピッキングリスト印刷（M05-21,M05-22） / 業務フローに記載された工程の成果物・商品別数量照合表
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 「ピック表作成」で扱った商品 ST-CARD-TSUHAN-011-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-012、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-21_admin_order_order_shipping_standby_picking_list_print.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md 実行手順 / 通販受注管理 / パターン11 / 経路2
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
通販受注管理 — 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）	STI-TSUHAN-020-013	-	在庫整合	P1	代替系 工程#4 判定: 梱包作業の現物と作業元明細の一致	"元シナリオ: SCN-TSUHAN-予約受注対応シングル-020 予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）
業務: 通販受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」）
最終業務状態: 受注マスターで選んだ予約受注の納品書とラベルデータだけが後続のピック・出荷へ渡り、不要な予約受注が混入しないことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: シングルカードの出荷指示に不要な予約が多数含まれる（原典本文 16_通販受注管理.md R449–453「未開封製品と同じく受注マスター検索から納品書印刷とラベルデータを取り出す場合もある」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ出荷指示に対象2件と対象外1件が含まれる予約データを用意し、受注マスター検索で対象2件だけを絞り込む。
シードデータ: 担当者アカウント=st-user-tsuhan-011-r02 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md 実行手順 / 通販受注管理 / パターン11 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
判定用具体値: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 通販チーム
【準備確認】
判定用準備: ST-CARD-TSUHAN-011-R02 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-011-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件
2. 「予約注文の指示書に従ってピック・振り分け・梱包し、同じ受注番号と発送日を表示して発売前日まで保管する」を実施する
【操作後確認】
3. 照合キー: 受注番号・商品コード・発売日 / 出典: scenario_test/markdown/16_通販受注管理.md:197で、現物の商品・数量・受注番号が指示書と一致し、発売前の保管場所と作業完了を記録できるの実値と対象データ 担当者アカウント=st-user-tsuhan-011-r02 / 受注番号=ST-ORDER-TSUHAN-011-R02 / 商品コード=ST-CARD-TSUHAN-011-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-011-R02 / 予約種別=シングルカード / 出荷対象=発売対象の受注2件 / 対象外=別発売日の予約受注1件 の対応を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「梱包作業」で扱った商品 ST-CARD-TSUHAN-011-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 業務フローに記載された工程の成果物・商品別数量照合表
照合キー: 受注番号=ST-ORDER-TSUHAN-011-R02
合格条件: 「梱包作業」で扱った商品 ST-CARD-TSUHAN-011-R02 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-020-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-020-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md / 通販受注管理 / パターン11 / 経路2
判定根拠: scenario_test/scenario/SCN-TSUHAN-予約受注対応シングル-020_予約受注対応（シングルカード）（不要な予約を含む出荷指示の代替出力）.md 実行手順 / 通販受注管理 / パターン11 / 経路2
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
```
