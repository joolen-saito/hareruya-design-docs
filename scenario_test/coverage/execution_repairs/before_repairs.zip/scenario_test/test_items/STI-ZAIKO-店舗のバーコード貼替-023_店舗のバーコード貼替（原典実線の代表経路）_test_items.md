<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 店舗のバーコード貼替（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-30 | テスト項目化 | あり | CSV/帳票 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 店舗のバーコード貼替（原典実線の代表経路）	STI-ZAIKO-023-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-店舗のバーコード貼替-023 店舗のバーコード貼替（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-014-r01 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-30; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-30; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 顧客戦略チームが在庫管理 — バーコード貼替リストCSV出力で「バーコード貼替リストCSV出力として、バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-014-R01
4. 正常系#2: 顧客戦略チームが「対象商品のバーコード貼替として、バーコード貼替リストCSVからバーコードを発行し 商品に貼り付ける」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-014-R01
【操作後確認】
5. 最終業務状態「バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 出力されたCSV/帳票の件数と内容 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-014-R01
合格条件: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-023-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-023-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md / 在庫管理 / パターン14 / 経路1"
在庫管理 — 店舗のバーコード貼替（原典実線の代表経路）	STI-ZAIKO-023-002	M04-30	CSV/帳票	P1	正常系 #1: 顧客戦略チームが「バーコード貼替リストCSV出力として、バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）」を行い「バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）が完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-店舗のバーコード貼替-023 店舗のバーコード貼替（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-014-r01 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-30_admin_stock_stock_barcode_replacement_list_csv_export.md（在庫管理 — バーコード貼替リストCSV出力）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-30_admin_stock_stock_barcode_replacement_list_csv_export.md（在庫管理 — バーコード貼替リストCSV出力）
【操作】
1. 管理画面で 在庫管理 — バーコード貼替リストCSV出力 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード
3. 「バーコード貼替リストCSV出力として、バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）」を実施する
【操作後確認】
4. 在庫管理 — バーコード貼替リストCSV出力 で対象キーと 処理後の画面表示 を記録する"	バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 在庫管理 — バーコード貼替リストCSV出力（M04-30） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-STOCK-ZAIKO-014-R01
合格条件: バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-023-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-023-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-30_admin_stock_stock_barcode_replacement_list_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md / 在庫管理 / パターン14 / 経路1"
在庫管理 — 店舗のバーコード貼替（原典実線の代表経路）	STI-ZAIKO-023-003	-	CSV/帳票	P1	正常系 #2: 顧客戦略チームが「対象商品のバーコード貼替として、バーコード貼替リストCSVからバーコードを発行し 商品に貼り付ける」を行い「バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-店舗のバーコード貼替-023 店舗のバーコード貼替（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-014-r01 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード
2. 「対象商品のバーコード貼替として、バーコード貼替リストCSVからバーコードを発行し 商品に貼り付ける」を実施する
【操作後確認】
3. バーコード貼替リストCSV・商品・バーコードで、バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-014-R01
合格条件: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-023-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-023-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md / 在庫管理 / パターン14 / 経路1"
在庫管理 — 店舗のバーコード貼替（原典実線の代表経路）	STI-ZAIKO-023-004	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #324 バーコード貼替リストCSV	"元シナリオ: SCN-ZAIKO-店舗のバーコード貼替-023 店舗のバーコード貼替（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-014-r01 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-30; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン14 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-36"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-01
照合キー=スマレジ商品ID（対象商品に紐づく実ID）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-30; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-023-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-014-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-023-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-014-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-014-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-014-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-014-r01 / 商品コード=ST-STOCK-ZAIKO-014-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-014-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 顧客戦略チームが在庫管理 — バーコード貼替リストCSV出力で「バーコード貼替リストCSV出力として、バーコード貼替リストCSV出力画面で、店舗と価格調整期間を選択し CSV出力を行う（右図を参照）」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-014-R01
4. 正常系#2: 顧客戦略チームが「対象商品のバーコード貼替として、バーコード貼替リストCSVからバーコードを発行し 商品に貼り付ける」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-014-R01
【操作後確認】
5. 最終業務状態「バーコード貼替リストCSVからバーコードを発行し 商品に貼り付けることを、出力されたCSV/帳票の件数と内容で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#322 バーコード貼替リストCSV出力、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=スマレジ商品ID（対象商品に紐づく実ID）。対象商品コードとスマレジ商品IDの対応を保存し、CSVに載る実IDで識別する。
【操作】
産出工程の完了直後に#324 バーコード貼替リストCSVをproducer原本として保存する。
産出原本から スマレジ商品ID・スマレジ商品コード・スマレジバーコード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #322 バーコード貼替リストCSV出力 の成果物 #324 バーコード貼替リストCSV のスマレジ商品ID・スマレジ商品コード・スマレジバーコードが、照合キー スマレジ商品ID（対象商品に紐づく実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #324 バーコード貼替リストCSV
照合キー: スマレジ商品ID（対象商品に紐づく実ID）
合格条件: 産出工程 #322 バーコード貼替リストCSV出力 の成果物 #324 バーコード貼替リストCSV のスマレジ商品ID・スマレジ商品コード・スマレジバーコードが、照合キー スマレジ商品ID（対象商品に紐づく実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-023-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-023-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md / 在庫管理 / パターン14 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-店舗のバーコード貼替-023_店舗のバーコード貼替（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン14 / 経路1 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-36
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
