<!-- generated-by: hareruya-scenario-test-items -->
# イベント管理 — イベント受付～実施（会員登録に同意して参加） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| A17-03 | テスト項目化 | あり | 代替フロー |
| M13-06 | テスト項目化 | あり | 代替フロー |
| M13-07 | テスト項目化 | あり | 代替フロー |
| M13-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-16 | テスト項目化 | あり | 代替フロー |
| F06-17 | テスト項目化 | あり | 代替フロー |
| M15-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-01 | テスト項目化 | あり | 代替フロー |
| F06-02 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
13. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
14. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
15. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 代替系#1: 店舗チームがイベント管理 — イベント申込検索で「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント申込一括編集で「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
5. 代替系#3: 店舗チームが「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
6. 代替系#4: 店舗チームが「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
7. 代替系#5: お客様がF06-01（仮会員登録）で「仮会員登録後、受信したメールから本会員登録を完了する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
8. 代替系#6: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
9. 代替系#7: 店舗チームがAPI その他 — PointGranterAPI連携で「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
10. 代替系#8: 店舗チームが「売上登録として、スマレジに当日のイベント金額を登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
【操作後確認】
11. 最終業務状態「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。	"確認場所: 出力されたCSV/帳票の件数と内容 / 画面表示・処理ステータス・処理履歴 / 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:64 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。 / 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-002	M13-06	代替フロー	P1	代替系 #1: 店舗チームが「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を行い「オンライン受付するイベントの場合、申込一覧をCSV出力することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）
【操作】
1. 管理画面で イベント管理 — イベント申込検索 を開く
2. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を実施する
【操作後確認】
4. イベント管理 — イベント申込検索 で対象キーと 処理後の画面表示 を記録する"	オンライン受付するイベントの場合、申込一覧をCSV出力することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: イベント管理 — イベント申込検索（M13-06） / 出力されたCSV/帳票の件数と内容
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: オンライン受付するイベントの場合、申込一覧をCSV出力することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-003	M13-07	代替フロー	P1	代替系 #2: 店舗チームが「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を行い「イベントの受付を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md（イベント管理 — イベント申込一括編集）
- 必須入力欄: 申込ステータス / 対象申込"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md（イベント管理 — イベント申込一括編集）
14. 必須入力欄: 申込ステータス / 対象申込
【操作】
1. 管理画面で イベント管理 — イベント申込一括編集 を開く
2. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を実施する
【操作後確認】
4. イベント管理 — イベント申込一括編集 で対象キーと 処理後の画面表示 を記録する"	イベントの受付を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: イベント管理 — イベント申込一括編集（M13-07） / 画面表示・処理ステータス・処理履歴
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: イベントの受付を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-004	-	代替フロー	P1	代替系 #3: 店舗チームが「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を行い「対象大会が実施され、ルール条件に該当する参加者の登録デッキと使用デッキを照合できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
2. 「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:64 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。で、対象大会が実施され、ルール条件に該当する参加者の登録デッキと使用デッキを照合できること。の実値と対象データ 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意 の対応を記録する"	対象大会が実施され、ルール条件に該当する参加者の登録デッキと使用デッキを照合できること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:64 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 対象大会が実施され、ルール条件に該当する参加者の登録デッキと使用デッキを照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-005	-	代替フロー	P1	代替系 #4: 店舗チームが「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を行い「未登録の顧客に登録を促し、登録に同意したことを確認することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
2. 「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、未登録の顧客に登録を促し、登録に同意したことを確認することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意 の対応を記録する"	未登録の顧客に登録を促し、登録に同意したことを確認することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 未登録の顧客に登録を促し、登録に同意したことを確認することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-006	F06-01,F06-02	代替フロー	P1	代替系 #5: お客様が「仮会員登録後、受信したメールから本会員登録を完了する」を行い「参加者と同じ氏名・メールアドレスの本会員が登録される」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f06-01_front_member_customer_entry.md（F06-01（仮会員登録））
- 必須入力欄: お名前 / お名前（フリガナ） / 電話番号 / メールアドレス / メールアドレス（確認） / 国 / 郵便番号 / 住所 / パスワード / パスワード（確認） / 生年月日
- この工程で通過する機能: F06-01 F06-01（仮会員登録） → F06-02 会員 — 本会員登録（アクティベート）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f06-01_front_member_customer_entry.md（F06-01（仮会員登録））
14. 必須入力欄: お名前 / お名前（フリガナ） / 電話番号 / メールアドレス / メールアドレス（確認） / 国 / 郵便番号 / 住所 / パスワード / パスワード（確認） / 生年月日
15. この工程で通過する機能: F06-01 F06-01（仮会員登録） → F06-02 会員 — 本会員登録（アクティベート）
【操作】
1. フロント画面で F06-01（仮会員登録） を開く
2. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 通過する機能: F06-01 → F06-02。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「仮会員登録後、受信したメールから本会員登録を完了する」を実施する
【操作後確認】
5. F06-01（仮会員登録） で対象キーと 処理後の画面表示 を記録する"	参加者と同じ氏名・メールアドレスの本会員が登録されること。	"確認場所: F06-01（仮会員登録）（F06-01,F06-02） / 照合キー: 会員ID・メールアドレス / 出典: scenario_test/markdown/08_イベント管理.md:68 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:1064#sheet-3 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:1447#sheet-4
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 参加者と同じ氏名・メールアドレスの本会員が登録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f06-01_front_member_customer_entry.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-007	F06-16,F06-17	代替フロー	P1	代替系 #6: お客様が「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を行い「同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致される」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md（F06-16（大会デッキ登録編集））
- 必須入力欄: フォーマット
- この工程で通過する機能: F06-16 F06-16（大会デッキ登録編集） → F06-17 F06-17（大会に登録するデッキの確認・登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md（F06-16（大会デッキ登録編集））
14. 必須入力欄: フォーマット
15. この工程で通過する機能: F06-16 F06-16（大会デッキ登録編集） → F06-17 F06-17（大会に登録するデッキの確認・登録）
【操作】
1. フロント画面で F06-16（大会デッキ登録編集） を開く
2. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 通過する機能: F06-16 → F06-17。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
【操作後確認】
5. F06-16（大会デッキ登録編集） で対象キーと 処理後の画面表示 を記録する"	同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致されること。	"確認場所: F06-16（大会デッキ登録編集）（F06-16,F06-17） / 照合キー: 会員ID・イベント日程ID・デッキID / 出典: scenario_test/markdown/08_イベント管理.md:69 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3081#sheet-13 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3423#sheet-14
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-008	A17-03	代替フロー	P1	代替系 #7: 店舗チームが「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を行い「ポイントグランターを用いてポイント付与を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証: 対象APIの設計書で定義された認証情報をテスト環境の管理者から払い出し、値は証跡へ記載せず保管する
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/a17-03_api_other_point_granter.md（API その他 — PointGranterAPI連携）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証: 対象APIの設計書で定義された認証情報をテスト環境の管理者から払い出し、値は証跡へ記載せず保管する
11. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/a17-03_api_other_point_granter.md（API その他 — PointGranterAPI連携）
【操作】
1. APIクライアントで POST http://localhost:8080/admin_api/point_granter のリクエストを作成する
2. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を実施する
【操作後確認】
4. API その他 — PointGranterAPI連携 で対象キーと 処理後の画面表示 を記録する"	ポイントグランターを用いてポイント付与を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: API その他 — PointGranterAPI連携（A17-03） / 画面表示・処理ステータス・処理履歴
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: ポイントグランターを用いてポイント付与を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/a17-03_api_other_point_granter.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-009	-	代替フロー	P1	代替系 #8: 店舗チームが「売上登録として、スマレジに当日のイベント金額を登録する」を行い「スマレジに当日のイベント金額を登録することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
2. 「売上登録として、スマレジに当日のイベント金額を登録する」を実施する
【操作後確認】
3. スマレジで、スマレジに当日のイベント金額を登録することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意 の対応を記録する"	スマレジに当日のイベント金額を登録することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: スマレジに当日のイベント金額を登録することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-010	-	代替フロー	P1	代替系 A1 #1: 店舗チームが「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を行い「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
入力=商品コード=ST-CARD-EVENT-003-R02-A1 / 会員登録=未登録 / 登録意思=同意"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 商品コード=ST-CARD-EVENT-003-R02-A1 / 会員登録=未登録 / 登録意思=同意
2. 分岐条件「テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。」を成立させる
3. 「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を実施する
【操作後確認】
4. 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したで、会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。の実値と対象データ 商品コード=ST-CARD-EVENT-003-R02-A1 / 会員登録=未登録 / 登録意思=同意 の対応を記録する"	会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。	"確認場所: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了した
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-011	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #41 イベント情報*1	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-01 / イベント管理 / パターン3 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
連鎖ID=DL-01
照合キー=イベントID=ST-EVENT-EVENT-003-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
13. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
14. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
15. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 代替系#1: 店舗チームがイベント管理 — イベント申込検索で「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント申込一括編集で「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
5. 代替系#3: 店舗チームが「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
6. 代替系#4: 店舗チームが「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
7. 代替系#5: お客様がF06-01（仮会員登録）で「仮会員登録後、受信したメールから本会員登録を完了する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
8. 代替系#6: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
9. 代替系#7: 店舗チームがAPI その他 — PointGranterAPI連携で「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
10. 代替系#8: 店舗チームが「売上登録として、スマレジに当日のイベント金額を登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
【操作後確認】
11. 最終業務状態「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#40 イベント申込一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-003-R02。
【操作】
産出工程の完了直後に#41 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #40 イベント申込一覧 の成果物 #41 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-003-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #41 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-003-R02
合格条件: 産出工程 #40 イベント申込一覧 の成果物 #41 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-003-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-01 / イベント管理 / パターン3 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-012	-	データ連鎖	P1	代替系 DL-02: 産出値と消費値の照合 — #43 デッキリスト	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 産出値と消費値の照合
- 原典判定: 起点（産出元の記載なし・消費工程で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-02 / イベント管理 / パターン3 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-02 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
- 解除条件: #43 デッキリストの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#43 デッキリストの取得方法を確定する。 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が対象成果物の実サンプル・一意キー・対応する元データを提示する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
連鎖ID=DL-02
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-02: #43 デッキリストの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#43 デッキリストの取得方法を確定する。 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が対象成果物の実サンプル・一意キー・対応する元データを提示する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #43 デッキリスト
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-02 / イベント管理 / パターン3 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-02 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
連鎖判定: 起点（産出元の記載なし・消費工程で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-013	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #51 会員*1	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-03 / イベント管理 / パターン3 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
連鎖ID=DL-03
照合キー=会員番号=ST-MEMBER-EVENT-003-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
13. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
14. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
15. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 代替系#1: 店舗チームがイベント管理 — イベント申込検索で「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント申込一括編集で「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
5. 代替系#3: 店舗チームが「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
6. 代替系#4: 店舗チームが「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
7. 代替系#5: お客様がF06-01（仮会員登録）で「仮会員登録後、受信したメールから本会員登録を完了する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
8. 代替系#6: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
9. 代替系#7: 店舗チームがAPI その他 — PointGranterAPI連携で「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
10. 代替系#8: 店舗チームが「売上登録として、スマレジに当日のイベント金額を登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
【操作後確認】
11. 最終業務状態「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#50 新規会員登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=会員番号=ST-MEMBER-EVENT-003-R02。
【操作】
産出工程の完了直後に#51 会員*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #50 新規会員登録 の成果物 #51 会員*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-EVENT-003-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #51 会員*1
照合キー: 会員番号=ST-MEMBER-EVENT-003-R02
合格条件: 産出工程 #50 新規会員登録 の成果物 #51 会員*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-EVENT-003-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-03 / イベント管理 / パターン3 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-014	-	データ連鎖	P1	代替系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #53 デッキ	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-04 / イベント管理 / パターン3 / 経路2 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
連鎖ID=DL-04
照合キー=デッキID（登録後の実ID）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
13. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
14. 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
15. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
3. 代替系#1: 店舗チームがイベント管理 — イベント申込検索で「オンライン受付として、オンライン受付するイベントの場合、申込一覧をCSV出力する リスト出力 ※競技イベントの場合は、デッキ登録されたデッキを全員分PDFで出力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント申込一括編集で「イベント受付として、イベントの受付を行う オンライン受付の場合、出力した申込リストに照会する オンライン受付でない場合、参加費も徴収する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
5. 代替系#3: 店舗チームが「イベント実施として、イベント実施する ※ルールが厳しい場合は登録デッキの確認も行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
6. 代替系#4: 店舗チームが「会員登録有無として、未登録の顧客に登録を促し、登録に同意したことを確認する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
7. 代替系#5: お客様がF06-01（仮会員登録）で「仮会員登録後、受信したメールから本会員登録を完了する」を実施する
   対象: 商品コード=ST-CARD-EVENT-003-R02
8. 代替系#6: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
9. 代替系#7: 店舗チームがAPI その他 — PointGranterAPI連携で「ポイント付与として、ポイントグランターを用いてポイント付与を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
10. 代替系#8: 店舗チームが「売上登録として、スマレジに当日のイベント金額を登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-003-R02
【操作後確認】
11. 最終業務状態「会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#52 デッキ登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=デッキID（登録後の実ID）。登録結果のデッキIDを当該プレイヤー・イベントと対応付けて保存し、入力したデッキ内容と登録結果を比較する。
【操作】
産出工程の完了直後に#53 デッキをproducer原本として保存する。
産出原本から デッキID・プレイヤー・イベント・デッキ内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #52 デッキ登録 の成果物 #53 デッキ のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #53 デッキ
照合キー: デッキID（登録後の実ID）
合格条件: 産出工程 #52 デッキ登録 の成果物 #53 デッキ のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-04 / イベント管理 / パターン3 / 経路2 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付～実施（会員登録に同意して参加）	STI-EVENT-007-015	-	データ連鎖	P1	代替系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #57 売上	"元シナリオ: SCN-EVENT-イベント受付実施-007 イベント受付～実施（会員登録に同意して参加）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」）
最終業務状態: 会員番号に紐づく参加者へのポイント付与と当日のイベント売上登録が完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 会員登録=未登録、登録意思=同意（原典本文 08_イベント管理.md R161–186「会員登録されていない場合は、会員登録を促す」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト参加者の会員登録状態を指定し、イベント受付後に会員番号と付与履歴を照合する。
シードデータ: 担当者アカウント=st-user-event-003-r02 / 会員番号=ST-MEMBER-EVENT-003-R02 / 商品コード=ST-CARD-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-003-R02 / イベント名=システムテスト大会 EVENT-003-R02 / 定員=8名 / 受付状態=受付前 / 会員登録=未登録 / 登録意思=同意
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M13-06, M13-07, F06-01, F06-02, F06-16, F06-17; 未実装指摘あり=4; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-003-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-003-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-003-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-003-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-05 / イベント管理 / パターン3 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-05 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
- 解除条件: #57 売上の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典はイベント金額をスマレジへ登録する旨を記載するが、イベント申込とスマレジ取引の対応項目を定義していない。 必要な判断: イベント担当がイベント単位/参加者単位の登録粒度とスマレジの商品・取引記録の対応を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典はイベント金額をスマレジへ登録する旨を記載するが、イベント申込とスマレジ取引の対応項目を定義していない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-003-r02 / 商品コード=ST-CARD-EVENT-003-R02 / イベントID=ST-EVENT-EVENT-003-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / 会員登録=未登録 / 登録意思=同意
連鎖ID=DL-05
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-05: #57 売上の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典はイベント金額をスマレジへ登録する旨を記載するが、イベント申込とスマレジ取引の対応項目を定義していない。 必要な判断: イベント担当がイベント単位/参加者単位の登録粒度とスマレジの商品・取引記録の対応を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #57 売上
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-007-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-007-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md / イベント管理 / パターン3 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-05 / イベント管理 / パターン3 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付実施-007_イベント受付～実施（会員登録に同意して参加）.md データ連鎖 DL-05 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
```
