<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | テスト項目化 | あり | 代替業務 |
| M05-11 | テスト項目化 | あり | 代替業務 |
| M05-15 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-19 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-001	-	業務経路	P1	代替系 経路全体 R03: 主要代替として「同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
3. 代替系#1: 通販チームが「返金依頼として、返金が必要な要項が顧客対応で発生 ※通販チーム内での対応」を実施する
   対象: 返金対象金額=1,000円
4. 代替系#2: 通販チームが「返金方法確認として、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認」を実施する
   対象: 返金対象金額=1,000円
5. 代替系#3: 通販チームが受注管理 — 受注情報検索・一覧で「返金方法による分岐として、振込かポイント付与による返金か」を実施する
   対象: 返金対象金額=1,000円
6. 代替系#4: 通販チームが受注管理 — 受注情報編集で「ポイント返金処理として、アカウントのポイント付与機能から必要数のポイントを付与 ※会員登録からポイント管理・履歴一覧 ※全額ポイント使用の場合での返金はポイント付与以外では行わない」を実施する
   対象: 返金対象金額=1,000円
7. 代替系#5: 通販チームが「お客様案内対応として、付与完了をお客様に返信」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-009-R03
【操作後確認】
8. 最終業務状態「同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 金額・決済状態と処理履歴 / 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-002	-	代替業務	P1	代替系 #1: 通販チームが「返金依頼として、返金が必要な要項が顧客対応で発生 ※通販チーム内での対応」を行い「返金が必要な要項が顧客対応で発生が完了したことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
2. 「返金依頼として、返金が必要な要項が顧客対応で発生 ※通販チーム内での対応」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、返金が必要な要項が顧客対応で発生が完了したことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200 の対応を記録する"	返金が必要な要項が顧客対応で発生が完了したことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: 返金が必要な要項が顧客対応で発生が完了したことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-003	-	代替業務	P1	代替系 #2: 通販チームが「返金方法確認として、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認」を行い「お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
2. 「返金方法確認として、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200 の対応を記録する"	お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-004	M05-01	代替業務	P1	代替系 #3: 通販チームが「返金方法による分岐として、振込かポイント付与による返金か」を行い「振込かポイント付与による返金かが完了したことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
3. 「返金方法による分岐として、振込かポイント付与による返金か」を実施する
【操作後確認】
4. 受注管理 — 受注情報検索・一覧 で対象キーと 処理後の画面表示 を記録する"	振込かポイント付与による返金かが完了したことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 金額・決済状態と処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: 振込かポイント付与による返金かが完了したことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-005	M05-11	代替業務	P1	代替系 #4: 通販チームが「ポイント返金処理として、アカウントのポイント付与機能から必要数のポイントを付与 ※会員登録からポイント管理・履歴一覧 ※全額ポイント使用の場合での返金はポイント付与以外では行わない」を行い「アカウントのポイント付与機能から必要数のポイントを付与することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
【操作】
1. 管理画面で 受注管理 — 受注情報編集 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
3. 「ポイント返金処理として、アカウントのポイント付与機能から必要数のポイントを付与 ※会員登録からポイント管理・履歴一覧 ※全額ポイント使用の場合での返金はポイント付与以外では行わない」を実施する
【操作後確認】
4. 受注管理 — 受注情報編集 で対象キーと 保存しました を記録する"	アカウントのポイント付与機能から必要数のポイントを付与することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 受注管理 — 受注情報編集（M05-11） / 金額・決済状態と処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: アカウントのポイント付与機能から必要数のポイントを付与することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-006	-	代替フロー	P1	代替系 #5: 通販チームが「お客様案内対応として、付与完了をお客様に返信」を行い「付与完了をお客様に返信することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
2. 「お客様案内対応として、付与完了をお客様に返信」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、付与完了をお客様に返信することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200 の対応を記録する"	付与完了をお客様に返信することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: 付与完了をお客様に返信することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-007	-	代替業務	P1	代替系 A1 #1: 通販チームが「元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）」を行い「同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できる」を確認する	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
入力=受注番号=ST-ORDER-TSUHAN-009-R03-A1 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 受注番号=ST-ORDER-TSUHAN-009-R03-A1 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
2. 分岐条件「ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。」を成立させる
3. 「元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）」を実施する
【操作後確認】
4. 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたで、同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。の実値と対象データ 受注番号=ST-ORDER-TSUHAN-009-R03-A1 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200 の対応を記録する"	同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。	"確認場所: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認された
照合キー: 受注番号=ST-ORDER-TSUHAN-009-R03
合格条件: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-008	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #161 会員*1	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md データ連鎖 DL-01 / 通販受注管理 / パターン9 / 経路3"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
連鎖ID=DL-01
照合キー=会員番号=ST-MEMBER-TSUHAN-009-R03"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
3. 代替系#1: 通販チームが「返金依頼として、返金が必要な要項が顧客対応で発生 ※通販チーム内での対応」を実施する
   対象: 返金対象金額=1,000円
4. 代替系#2: 通販チームが「返金方法確認として、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認」を実施する
   対象: 返金対象金額=1,000円
5. 代替系#3: 通販チームが受注管理 — 受注情報検索・一覧で「返金方法による分岐として、振込かポイント付与による返金か」を実施する
   対象: 返金対象金額=1,000円
6. 代替系#4: 通販チームが受注管理 — 受注情報編集で「ポイント返金処理として、アカウントのポイント付与機能から必要数のポイントを付与 ※会員登録からポイント管理・履歴一覧 ※全額ポイント使用の場合での返金はポイント付与以外では行わない」を実施する
   対象: 返金対象金額=1,000円
7. 代替系#5: 通販チームが「お客様案内対応として、付与完了をお客様に返信」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-009-R03
【操作後確認】
8. 最終業務状態「同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#160 会員登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=会員番号=ST-MEMBER-TSUHAN-009-R03。
【操作】
産出工程の完了直後に#161 会員*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #160 会員登録 の成果物 #161 会員*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-TSUHAN-009-R03 に対応する作業元の確定値と一致する状態であること。	"確認場所: #161 会員*1
照合キー: 会員番号=ST-MEMBER-TSUHAN-009-R03
合格条件: 産出工程 #160 会員登録 の成果物 #161 会員*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 会員番号=ST-MEMBER-TSUHAN-009-R03 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3
判定根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md データ連鎖 DL-01 / 通販受注管理 / パターン9 / 経路3
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）	STI-TSUHAN-019-009	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #162 ポイント付与完了メール	"元シナリオ: SCN-TSUHAN-クレジットカード以外-019 クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）
業務: 通販受注管理
経路ID: R03
経路種別: 主要代替
業務経路条件: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）
最終業務状態: 同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 ポイント履歴が追跡できる顧客を用意し、返金ポイント数1,000と付与前残高200を控える。
シードデータ: 担当者アカウント=st-user-tsuhan-009-r03 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md データ連鎖 DL-02 / 通販受注管理 / パターン9 / 経路3 / scenario_test/markdown/16_通販受注管理.md R395-R400"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
連鎖ID=DL-02
照合キー=受注の実番号と対応付けたメール原本のMessage-ID"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-019-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-009-R03 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-009-R03"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-009-R03 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-019-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-009-R03 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-009-r03 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R03（主要代替）の条件「元決済=全額ポイント使用、返金方法=ポイント（原典本文 16_通販受注管理.md R358–359,R395–400「全額ポイント使用の場合での返金はポイント付与以外では行わない」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-009-r03 / 受注番号=ST-ORDER-TSUHAN-009-R03 / 商品コード=ST-CARD-TSUHAN-009-R03 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-009-R03 / 返金方法=ポイント / 元決済=全額ポイント / 返金ポイント数=1,000 / 付与前残高=200 / 付与後残高=1,200
3. 代替系#1: 通販チームが「返金依頼として、返金が必要な要項が顧客対応で発生 ※通販チーム内での対応」を実施する
   対象: 返金対象金額=1,000円
4. 代替系#2: 通販チームが「返金方法確認として、お客様に「振込による返金」または 「ポイント付与による返金」のどちらを希望するか確認」を実施する
   対象: 返金対象金額=1,000円
5. 代替系#3: 通販チームが受注管理 — 受注情報検索・一覧で「返金方法による分岐として、振込かポイント付与による返金か」を実施する
   対象: 返金対象金額=1,000円
6. 代替系#4: 通販チームが受注管理 — 受注情報編集で「ポイント返金処理として、アカウントのポイント付与機能から必要数のポイントを付与 ※会員登録からポイント管理・履歴一覧 ※全額ポイント使用の場合での返金はポイント付与以外では行わない」を実施する
   対象: 返金対象金額=1,000円
7. 代替系#5: 通販チームが「お客様案内対応として、付与完了をお客様に返信」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-009-R03
【操作後確認】
8. 最終業務状態「同じ顧客のポイント付与履歴と付与前後の残高差が返金ポイント数に一致し、お客様への完了案内が確認されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#163 お客様案内、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注の実番号と対応付けたメール原本のMessage-ID。当該顧客のポイント付与結果の実数と付与履歴を保存し、同じ顧客への返信メールに記載された付与完了内容と照合する。金額からポイント数への換算率は推定しない。 受注実番号・元依頼メールのMessage-ID・送信メールのMessage-IDを証跡上で対応付ける。本文に受注番号が記載されることを前提にしない。
【操作】
産出工程の完了直後に#162 ポイント付与完了メールをproducer原本として保存する。
産出原本から 受信宛先・件名・本文の依頼内容または完了内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #163 お客様案内 の成果物 #162 ポイント付与完了メール の受信宛先・件名・本文の依頼内容または完了内容が、照合キー 受注の実番号と対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。	"確認場所: #162 ポイント付与完了メール
照合キー: 受注の実番号と対応付けたメール原本のMessage-ID
合格条件: 産出工程 #163 お客様案内 の成果物 #162 ポイント付与完了メール の受信宛先・件名・本文の依頼内容または完了内容が、照合キー 受注の実番号と対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-019-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-019-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md / 通販受注管理 / パターン9 / 経路3
判定根拠: scenario_test/scenario/SCN-TSUHAN-クレジットカード以外-019_クレジットカード以外の返金対応（全額ポイント使用受注のポイント返金）.md データ連鎖 DL-02 / 通販受注管理 / パターン9 / 経路3 / scenario_test/markdown/16_通販受注管理.md R395-R400
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
