<!-- generated-by: hareruya-scenario-test-items -->
# デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M15-05 | テスト項目化 | あり | データ更新 |
| M15-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-17 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-10 | テスト項目化 | あり | データ更新 |
| A15-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-13 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-14 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-16 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-17 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路）	STI-DECK-002-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できる」を確認する	"元シナリオ: SCN-DECK-オンライン入力された-002 オンライン入力されたデッキリストの公開（原典実線の代表経路）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-deck-002-r01 / 会員番号=ST-MEMBER-DECK-002-R01 / 商品コード=ST-CARD-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-002-R01 / 大会ID=ST-EVENT-DECK-002-R01 / デッキ公開状態=下書き / カード枚数=60枚
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
12. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
3. 正常系#1: お客様がデッキ管理 — 新規登録・編集・削除・複製で「デッキ登録として、入賞者にオンラインでデッキリストを登録してもらう ※ルール適用度が強の大会などの場合は、大会時にデッキ確認を行っている ため、注目度が高いデッキは高精度で登録できているが、カジュアルな 大会の場合は、登録に誤りがある場合がある」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
4. 正常系#2: 顧客戦略チームがAPI デッキビルダー — デッキ情報更新で「デッキ公開として、入賞者のデッキを検索し、必要な情報を入力し、更新する。 ※更新時にエラーがある場合は、可能ならお客様に聞くなどして修正する」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
【操作後確認】
5. 最終業務状態「入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。	"確認場所: 一覧・詳細に追加された対象データ / 公開状態 / 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: デッキID=ST-DECK-DECK-002-R01
合格条件: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-002-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-002-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md / デッキ登録 / パターン2 / 経路1"
デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路）	STI-DECK-002-002	M15-05	データ更新	P1	正常系 #1: お客様が「デッキ登録として、入賞者にオンラインでデッキリストを登録してもらう ※ルール適用度が強の大会などの場合は、大会時にデッキ確認を行っている ため、注目度が高いデッキは高精度で登録できているが、カジュアルな 大会の場合は、登録に誤りがある場合がある」を行い「入賞者にオンラインでデッキリストを登録してもらうことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-DECK-オンライン入力された-002 オンライン入力されたデッキリストの公開（原典実線の代表経路）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-deck-002-r01 / 会員番号=ST-MEMBER-DECK-002-R01 / 商品コード=ST-CARD-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-002-R01 / 大会ID=ST-EVENT-DECK-002-R01 / デッキ公開状態=下書き / カード枚数=60枚
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
- 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01"	"担当者: お客様
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
14. 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時
【操作】
1. 管理画面で デッキ管理 — 新規登録・編集・削除・複製 を開く
2. 対象データ: 担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
3. 「デッキ登録として、入賞者にオンラインでデッキリストを登録してもらう ※ルール適用度が強の大会などの場合は、大会時にデッキ確認を行っている ため、注目度が高いデッキは高精度で登録できているが、カジュアルな 大会の場合は、登録に誤りがある場合がある」を実施する
【操作後確認】
4. デッキ管理 — 新規登録・編集・削除・複製 で対象キーと 保存しました を記録する"	入賞者にオンラインでデッキリストを登録してもらうことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: デッキ管理 — 新規登録・編集・削除・複製（M15-05） / 一覧・詳細に追加された対象データ
照合キー: デッキID=ST-DECK-DECK-002-R01
合格条件: 入賞者にオンラインでデッキリストを登録してもらうことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-DECK-002-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-002-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md / デッキ登録 / パターン2 / 経路1"
デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路）	STI-DECK-002-003	A15-10	データ更新	P1	正常系 #2: 顧客戦略チームが「デッキ公開として、入賞者のデッキを検索し、必要な情報を入力し、更新する。 ※更新時にエラーがある場合は、可能ならお客様に聞くなどして修正する」を行い「入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できる」を確認する	"元シナリオ: SCN-DECK-オンライン入力された-002 オンライン入力されたデッキリストの公開（原典実線の代表経路）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-deck-002-r01 / 会員番号=ST-MEMBER-DECK-002-R01 / 商品コード=ST-CARD-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-002-R01 / 大会ID=ST-EVENT-DECK-002-R01 / デッキ公開状態=下書き / カード枚数=60枚
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
- 認証: 対象APIの設計書で定義された認証情報をテスト環境の管理者から払い出し、値は証跡へ記載せず保管する
- 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-api/a15-10_api_deck_builder_deck_update.md（API デッキビルダー — デッキ情報更新）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
10. 認証: 対象APIの設計書で定義された認証情報をテスト環境の管理者から払い出し、値は証跡へ記載せず保管する
11. 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-api/a15-10_api_deck_builder_deck_update.md（API デッキビルダー — デッキ情報更新）
【操作】
1. APIクライアントで PUT http://localhost:8080/api/deck/{id} のリクエストを作成する
2. リクエスト入力: デッキID（パス・必須）、認証用トークン（ヘッダ・必須）、公開範囲（必須。公開1・非公開2・限定公開3）。即時保存の指定・デッキ名・フォーマットの識別子・アーキタイプの識別子・代表カード画像に用いるカードID・キャンペーンタグの識別子・採用カードは、いずれも指定が無いときは扱わない
3. 対象データ: 担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
4. 「デッキ公開として、入賞者のデッキを検索し、必要な情報を入力し、更新する。 ※更新時にエラーがある場合は、可能ならお客様に聞くなどして修正する」を実施する
【操作後確認】
5. HTTPステータスと応答本文を保存する: HTTP 200。処理結果コードと処理結果メッセージ。公開範囲が限定公開のときだけ閲覧用トークン"	入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。	"確認場所: API デッキビルダー — デッキ情報更新（A15-10） / 公開状態
照合キー: デッキID=ST-DECK-DECK-002-R01
合格条件: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-002-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-002-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-api/a15-10_api_deck_builder_deck_update.md
業務結果根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md / デッキ登録 / パターン2 / 経路1"
デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路）	STI-DECK-002-004	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #8 デッキ管理	"元シナリオ: SCN-DECK-オンライン入力された-002 オンライン入力されたデッキリストの公開（原典実線の代表経路）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-deck-002-r01 / 会員番号=ST-MEMBER-DECK-002-R01 / 商品コード=ST-CARD-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-002-R01 / 大会ID=ST-EVENT-DECK-002-R01 / デッキ公開状態=下書き / カード枚数=60枚
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md データ連鎖 DL-01 / デッキ登録 / パターン2 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
連鎖ID=DL-01
照合キー=デッキID（登録後の実ID）"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
12. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
3. 正常系#1: お客様がデッキ管理 — 新規登録・編集・削除・複製で「デッキ登録として、入賞者にオンラインでデッキリストを登録してもらう ※ルール適用度が強の大会などの場合は、大会時にデッキ確認を行っている ため、注目度が高いデッキは高精度で登録できているが、カジュアルな 大会の場合は、登録に誤りがある場合がある」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
4. 正常系#2: 顧客戦略チームがAPI デッキビルダー — デッキ情報更新で「デッキ公開として、入賞者のデッキを検索し、必要な情報を入力し、更新する。 ※更新時にエラーがある場合は、可能ならお客様に聞くなどして修正する」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
【操作後確認】
5. 最終業務状態「入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#7 イベント・大会デッキ登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=デッキID（登録後の実ID）。登録結果のデッキIDを当該プレイヤー・イベントと対応付けて保存し、入力したデッキ内容と登録結果を比較する。
【操作】
産出工程の完了直後に#8 デッキ管理をproducer原本として保存する。
産出原本から デッキID・プレイヤー・イベント・デッキ内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #7 イベント・大会デッキ登録 の成果物 #8 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #8 デッキ管理
照合キー: デッキID（登録後の実ID）
合格条件: 産出工程 #7 イベント・大会デッキ登録 の成果物 #8 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-002-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-002-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md / デッキ登録 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md データ連鎖 DL-01 / デッキ登録 / パターン2 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
デッキ登録 — オンライン入力されたデッキリストの公開（原典実線の代表経路）	STI-DECK-002-005	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #8 デッキ管理	"元シナリオ: SCN-DECK-オンライン入力された-002 オンライン入力されたデッキリストの公開（原典実線の代表経路）
業務: デッキ登録
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-deck-002-r01 / 会員番号=ST-MEMBER-DECK-002-R01 / 商品コード=ST-CARD-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-002-R01 / 大会ID=ST-EVENT-DECK-002-R01 / デッキ公開状態=下書き / カード枚数=60枚
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md データ連鎖 DL-02 / デッキ登録 / パターン2 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
連鎖ID=DL-02
照合キー=デッキID（登録後の実ID）"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
12. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-deck-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-002-r01 / 商品コード=ST-CARD-DECK-002-R01 / デッキID=ST-DECK-DECK-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-002-R01
3. 正常系#1: お客様がデッキ管理 — 新規登録・編集・削除・複製で「デッキ登録として、入賞者にオンラインでデッキリストを登録してもらう ※ルール適用度が強の大会などの場合は、大会時にデッキ確認を行っている ため、注目度が高いデッキは高精度で登録できているが、カジュアルな 大会の場合は、登録に誤りがある場合がある」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
4. 正常系#2: 顧客戦略チームがAPI デッキビルダー — デッキ情報更新で「デッキ公開として、入賞者のデッキを検索し、必要な情報を入力し、更新する。 ※更新時にエラーがある場合は、可能ならお客様に聞くなどして修正する」を実施する
   対象: デッキID=ST-DECK-DECK-002-R01
【操作後確認】
5. 最終業務状態「入賞者のデッキを検索し、必要な情報を入力し、更新することを、公開状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#10 デッキ一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=デッキID（登録後の実ID）。登録結果のデッキIDを当該プレイヤー・イベントと対応付けて保存し、入力したデッキ内容と登録結果を比較する。
【操作】
産出工程の完了直後に#8 デッキ管理をproducer原本として保存する。
産出原本から デッキID・プレイヤー・イベント・デッキ内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #10 デッキ一覧 の成果物 #8 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。	"確認場所: #8 デッキ管理
照合キー: デッキID（登録後の実ID）
合格条件: 産出工程 #10 デッキ一覧 の成果物 #8 デッキ管理 のデッキID・プレイヤー・イベント・デッキ内容が、照合キー デッキID（登録後の実ID） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-002-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-002-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md / デッキ登録 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-DECK-オンライン入力された-002_オンライン入力されたデッキリストの公開（原典実線の代表経路）.md データ連鎖 DL-02 / デッキ登録 / パターン2 / 経路1 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html#sheet-5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
