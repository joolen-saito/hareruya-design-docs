<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | テスト項目化 | あり | CSV/帳票 |
| M05-18 | テスト項目化 | あり | データ更新 |
| M05-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-22 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-26 | テスト項目化 | あり | CSV/帳票、メール/通知 |
| M05-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-19 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報検索・一覧で「発売一週間前から発売前日の15時締めまで毎日行う 対象範囲の予約受注をEC-CUBEの受注マスターで検索し カスタム受注CSV・カスタム配送CSVそれぞれ全項目をダウンロードを行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
4. 正常系#2: 通販チームが「エクセル作成として、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除する 作成したエクセルファイル2点を委託業者に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
5. 正常系#3: 通販チームが「受託業者ファイル受領として、受託業者がファイルを受領」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
6. 正常系#4: 通販チームが「発送管理台帳更新として、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付け」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
7. 正常系#5: 通販チームが受注管理 — 出荷指示リスト作成で「発売日として、発送の完了と追跡番号の情報を晴れる屋に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
8. 正常系#6: 通販チームが「インポートデータ作成として、もらった追跡番号を使用してインポートデータを作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
9. 正常系#7: 通販チームが「メール文面変更として、インポート時のメール文を委託用に一部変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
10. 正常系#8: 通販チームが受注管理 — 出荷実績登録CSVフォーマットで「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
11. 正常系#9: 通販チームが「メール文面変更として、インポート時のメール文を通常使用に変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
【操作後確認】
12. 最終業務状態「インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 画面表示・処理ステータス・処理履歴 / 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-002	M05-01	CSV/帳票	P1	正常系 #1: 通販チームが「発売一週間前から発売前日の15時締めまで毎日行う 対象範囲の予約受注をEC-CUBEの受注マスターで検索し カスタム受注CSV・カスタム配送CSVそれぞれ全項目をダウンロードを行う」を行い「発売一週間前から発売前日の15時締めまで毎日行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 「発売一週間前から発売前日の15時締めまで毎日行う 対象範囲の予約受注をEC-CUBEの受注マスターで検索し カスタム受注CSV・カスタム配送CSVそれぞれ全項目をダウンロードを行う」を実施する
【操作後確認】
4. 受注管理 — 受注情報検索・一覧 で対象キーと 処理後の画面表示 を記録する"	発売一週間前から発売前日の15時締めまで毎日行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 発売一週間前から発売前日の15時締めまで毎日行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-003	-	CSV/帳票	P1	正常系 #2: 通販チームが「エクセル作成として、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除する 作成したエクセルファイル2点を委託業者に共有する」を行い「ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「エクセル作成として、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除する 作成したエクセルファイル2点を委託業者に共有する」を実施する
【操作後確認】
3. 作成したエクセルファイルで、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除することを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-004	-	データ更新	P1	正常系 #3: 通販チームが「受託業者ファイル受領として、受託業者がファイルを受領」を行い「受託業者がファイルを受領することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「受託業者ファイル受領として、受託業者がファイルを受領」を実施する
【操作後確認】
3. 受託業者ファイル・受託業者がファイルで、受託業者がファイルを受領することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	受託業者がファイルを受領することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 受託業者がファイルを受領することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-005	-	データ更新	P1	正常系 #4: 通販チームが「発送管理台帳更新として、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付け」を行い「発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付けが完了したことを、更新後の値と更新履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「発送管理台帳更新として、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付け」を実施する
【操作後確認】
3. 発送管理台帳・発送管理用EC台帳で、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付けが完了したことを、更新後の値と更新履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付けが完了したことを、更新後の値と更新履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付けが完了したことを、更新後の値と更新履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-006	M05-18	データ更新	P1	正常系 #5: 通販チームが「発売日として、発送の完了と追跡番号の情報を晴れる屋に共有する」を行い「発送の完了と追跡番号の情報を晴れる屋に共有することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 「発売日として、発送の完了と追跡番号の情報を晴れる屋に共有する」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 処理後の画面表示 を記録する"	発送の完了と追跡番号の情報を晴れる屋に共有することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 発送の完了と追跡番号の情報を晴れる屋に共有することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-007	-	業務操作	P1	正常系 #6: 通販チームが「インポートデータ作成として、もらった追跡番号を使用してインポートデータを作成」を行い「もらった追跡番号を使用してインポートデータを作成することを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「インポートデータ作成として、もらった追跡番号を使用してインポートデータを作成」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、もらった追跡番号を使用してインポートデータを作成することを、取込結果と対象件数・エラー行で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	もらった追跡番号を使用してインポートデータを作成することを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: もらった追跡番号を使用してインポートデータを作成することを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-008	-	メール/通知	P1	正常系 #7: 通販チームが「メール文面変更として、インポート時のメール文を委託用に一部変更」を行い「インポート時のメール文を委託用に一部変更することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「メール文面変更として、インポート時のメール文を委託用に一部変更」を実施する
【操作後確認】
3. インポート時のメールで、インポート時のメール文を委託用に一部変更することを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	インポート時のメール文を委託用に一部変更することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: インポート時のメール文を委託用に一部変更することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-009	M05-26	CSV/帳票	P1	正常系 #8: 通販チームが「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を行い「インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）
【操作】
1. 管理画面で 受注管理 — 出荷実績登録CSVフォーマット を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
【操作後確認】
4. 受注管理 — 出荷実績登録CSVフォーマット で対象キーと 処理後の画面表示 を記録する"	インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 受注管理 — 出荷実績登録CSVフォーマット（M05-26） / 取込結果と対象件数・エラー行
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: インポートを行い出荷処理を完了することを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-010	-	メール/通知	P1	正常系 #9: 通販チームが「メール文面変更として、インポート時のメール文を通常使用に変更」を行い「インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
2. 「メール文面変更として、インポート時のメール文を通常使用に変更」を実施する
【操作後確認】
3. インポート時のメールで、インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01 の対応を記録する"	インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-011	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #218 出荷データ*4	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン12 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
連鎖ID=DL-01
照合キー=受注番号=ST-ORDER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報検索・一覧で「発売一週間前から発売前日の15時締めまで毎日行う 対象範囲の予約受注をEC-CUBEの受注マスターで検索し カスタム受注CSV・カスタム配送CSVそれぞれ全項目をダウンロードを行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
4. 正常系#2: 通販チームが「エクセル作成として、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除する 作成したエクセルファイル2点を委託業者に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
5. 正常系#3: 通販チームが「受託業者ファイル受領として、受託業者がファイルを受領」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
6. 正常系#4: 通販チームが「発送管理台帳更新として、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付け」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
7. 正常系#5: 通販チームが受注管理 — 出荷指示リスト作成で「発売日として、発送の完了と追跡番号の情報を晴れる屋に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
8. 正常系#6: 通販チームが「インポートデータ作成として、もらった追跡番号を使用してインポートデータを作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
9. 正常系#7: 通販チームが「メール文面変更として、インポート時のメール文を委託用に一部変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
10. 正常系#8: 通販チームが受注管理 — 出荷実績登録CSVフォーマットで「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
11. 正常系#9: 通販チームが「メール文面変更として、インポート時のメール文を通常使用に変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
【操作後確認】
12. 最終業務状態「インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#217 インポートデータ作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-012-R01。
【操作】
産出工程の完了直後に#218 出荷データ*4をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #217 インポートデータ作成 の成果物 #218 出荷データ*4 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-012-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #218 出荷データ*4
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 産出工程 #217 インポートデータ作成 の成果物 #218 出荷データ*4 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-012-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン12 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-012	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #221 出荷指示*2	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md データ連鎖 DL-02 / 通販受注管理 / パターン12 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
連鎖ID=DL-02
照合キー=受注番号=ST-ORDER-TSUHAN-012-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-26; 未実装指摘あり=2; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報検索・一覧で「発売一週間前から発売前日の15時締めまで毎日行う 対象範囲の予約受注をEC-CUBEの受注マスターで検索し カスタム受注CSV・カスタム配送CSVそれぞれ全項目をダウンロードを行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
4. 正常系#2: 通販チームが「エクセル作成として、ダウンロードしたデータをそれぞれ別のエクセルに文字列として貼り付け 委託対応が不可の受注を抜き出しそれぞれ削除する 作成したエクセルファイル2点を委託業者に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
5. 正常系#3: 通販チームが「受託業者ファイル受領として、受託業者がファイルを受領」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
6. 正常系#4: 通販チームが「発送管理台帳更新として、発送管理用EC台帳の委託注文に委託になったことが分かるようにフラグ付け」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
7. 正常系#5: 通販チームが受注管理 — 出荷指示リスト作成で「発売日として、発送の完了と追跡番号の情報を晴れる屋に共有する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
8. 正常系#6: 通販チームが「インポートデータ作成として、もらった追跡番号を使用してインポートデータを作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
9. 正常系#7: 通販チームが「メール文面変更として、インポート時のメール文を委託用に一部変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
10. 正常系#8: 通販チームが受注管理 — 出荷実績登録CSVフォーマットで「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
11. 正常系#9: 通販チームが「メール文面変更として、インポート時のメール文を通常使用に変更」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-012-R01
【操作後確認】
12. 最終業務状態「インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#220 出荷実績インポート、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-012-R01。
【操作】
産出工程の完了直後に#221 出荷指示*2をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #220 出荷実績インポート の成果物 #221 出荷指示*2 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-012-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #221 出荷指示*2
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 産出工程 #220 出荷実績インポート の成果物 #221 出荷指示*2 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-012-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md データ連鎖 DL-02 / 通販受注管理 / パターン12 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-013	M05-26	CSV/帳票	P1	正常系 工程#8 判定: 出荷実績の同一受注への反映	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）
- 判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
判定用具体値: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。"	"担当者: 通販チーム
【準備確認】
判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）
【操作】
1. 管理画面で 受注管理 — 出荷実績登録CSVフォーマット を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
【操作後確認】
4. 受注管理 — 出荷実績登録CSVフォーマット で対象キーと 処理後の画面表示 を記録する
具体照合: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"	受注 ST-ORDER-TSUHAN-012-R01 の送り状No.が出荷実績CSVのST-SHIP-001、全配送先の発送日がCSVの2026/10/09 16:00と一致する状態であること。	"確認場所: 受注管理 — 出荷実績登録CSVフォーマット（M05-26） / 出荷実績CSV・受注詳細・配送先
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 受注 ST-ORDER-TSUHAN-012-R01 の送り状No.が出荷実績CSVのST-SHIP-001、全配送先の発送日がCSVの2026/10/09 16:00と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-013、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）
比較規則: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"
通販受注管理 — 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）	STI-TSUHAN-BOX-015-014	M05-26	メール/通知	P1	正常系 工程#8 判定: 出荷完了メールの宛先と履歴	"元シナリオ: SCN-TSUHAN-新商品のBOX発送外-015 新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: インポート時のメール文を通常使用に変更することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-012-r01 / 会員番号=ST-MEMBER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）
- 判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
判定用具体値: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。"	"担当者: 通販チーム
【準備確認】
判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-box-015-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-012-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-012-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-012-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-box-015-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-012-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-012-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md（受注管理 — 出荷実績登録CSVフォーマット）
【操作】
1. 管理画面で 受注管理 — 出荷実績登録CSVフォーマット を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-012-r01 / 受注番号=ST-ORDER-TSUHAN-012-R01 / 商品コード=ST-CARD-TSUHAN-012-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-012-R01
3. 「出荷インポート作業として、インポートを行い出荷処理を完了 ※この時顧客に出荷した旨のメールが送付される」を実施する
【操作後確認】
4. 受注管理 — 出荷実績登録CSVフォーマット で対象キーと 処理後の画面表示 を記録する
具体照合: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"	出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。	"確認場所: 受注管理 — 出荷実績登録CSVフォーマット（M05-26） / 受信箱・受注メール送信履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-012-R01
合格条件: 出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-BOX-015-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-BOX-015-014、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-26_admin_order_order_shipping_result_csv_format.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-新商品のBOX発送外-015_新商品のBOX発送(外部依頼の場合)（原典実線の代表経路）.md / 通販受注管理 / パターン12 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）
比較規則: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"
```
