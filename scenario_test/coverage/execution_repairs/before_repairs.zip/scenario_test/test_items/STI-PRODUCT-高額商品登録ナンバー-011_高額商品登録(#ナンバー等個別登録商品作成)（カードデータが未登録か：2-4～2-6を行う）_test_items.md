<!-- generated-by: hareruya-scenario-test-items -->
# 商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M14-01 | テスト項目化 | あり | 代替フロー |
| M14-04 | テスト項目化 | あり | 代替フロー |
| M14-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M14-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M14-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-26 | テスト項目化 | あり | 代替フロー |
| M03-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-35 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-13 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-02 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M14-01, M14-04, M03-26, M04-02; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M14-01, M14-04, M03-26, M04-02; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 代替系#1: トレードチームが「商品画像準備として、スキャンや写真撮影等で商品画像を用意」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
4. 代替系#2: トレードチームがカード管理 — カード検索（一覧・条件抽出）で「カードデータ有無として、カードデータが無い場合カードデータの新規登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
5. 代替系#3: トレードチームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カードデータ登録として、カードデータの登録および商品登録を行う。 ※画像データは用意したデータを使う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
6. 代替系#4: トレードチームが商品管理 — カード商品CSV登録で「商品登録として、商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録する 在庫を入れて販売開始をする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
7. 代替系#5: お客様が在庫管理 — 在庫編集機能で「商品コード・店舗・在庫区分を照合して在庫編集し、承認が必要な理由区分では承認工程へ引き継ぐ」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
8. 代替系#6: トレードチームが「販促として、特集ページやへの記載や告知等を販売開始時に併せて行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
【操作後確認】
9. 最終業務状態「特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 一覧・詳細に追加された対象データ / 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-002	-	代替フロー	P1	代替系 #1: トレードチームが「商品画像準備として、スキャンや写真撮影等で商品画像を用意」を行い「スキャンや写真撮影等で商品画像を用意が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「商品画像準備として、スキャンや写真撮影等で商品画像を用意」を実施する
【操作後確認】
3. 商品で、スキャンや写真撮影等で商品画像を用意が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	スキャンや写真撮影等で商品画像を用意が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: スキャンや写真撮影等で商品画像を用意が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-003	M14-01	代替フロー	P1	代替系 #2: トレードチームが「カードデータ有無として、カードデータが無い場合カードデータの新規登録を行う」を行い「カードデータが無い場合カードデータの新規登録を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））
【操作】
1. 管理画面で カード管理 — カード検索（一覧・条件抽出） を開く
2. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カードデータ有無として、カードデータが無い場合カードデータの新規登録を行う」を実施する
【操作後確認】
4. カード管理 — カード検索（一覧・条件抽出） で対象キーと 保存しました を記録する"	カードデータが無い場合カードデータの新規登録を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: カード管理 — カード検索（一覧・条件抽出）（M14-01） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: カードデータが無い場合カードデータの新規登録を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-004	M14-04	代替フロー	P1	代替系 #3: トレードチームが「カードデータ登録として、カードデータの登録および商品登録を行う。 ※画像データは用意したデータを使う」を行い「カードデータの登録および商品登録を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
- 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
14. 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）
【操作】
1. 管理画面で カード管理 — 新規登録・編集・削除（詳細フォーム） を開く
2. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「カードデータ登録として、カードデータの登録および商品登録を行う。 ※画像データは用意したデータを使う」を実施する
【操作後確認】
4. カード管理 — 新規登録・編集・削除（詳細フォーム） で対象キーと 保存しました を記録する"	カードデータの登録および商品登録を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: カード管理 — 新規登録・編集・削除（詳細フォーム）（M14-04） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: カードデータの登録および商品登録を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-005	M03-26	代替フロー	P1	代替系 #4: トレードチームが「商品登録として、商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録する 在庫を入れて販売開始をする」を行い「商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
- 必須入力欄: CSV ファイル"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
14. 必須入力欄: CSV ファイル
【操作】
1. 管理画面で 商品管理 — カード商品CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「商品登録として、商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録する 在庫を入れて販売開始をする」を実施する
【操作後確認】
4. 商品管理 — カード商品CSV登録 で対象キーと 処理後の画面表示 を記録する"	商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 商品管理 — カード商品CSV登録（M03-26） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: 商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-006	M04-02	代替フロー	P1	代替系 #5: お客様が「商品コード・店舗・在庫区分を照合して在庫編集し、承認が必要な理由区分では承認工程へ引き継ぐ」を行い「対象商品・店舗・在庫区分の変更内容または承認待ち内容が入力した増減数と一致される」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-02_admin_stock_stock_edit.md（在庫管理 — 在庫編集機能）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-02_admin_stock_stock_edit.md（在庫管理 — 在庫編集機能）
【操作】
1. 管理画面で 在庫管理 — 在庫編集機能 を開く
2. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 「商品コード・店舗・在庫区分を照合して在庫編集し、承認が必要な理由区分では承認工程へ引き継ぐ」を実施する
【操作後確認】
4. 在庫管理 — 在庫編集機能 で対象キーと 処理後の画面表示 を記録する"	対象商品・店舗・在庫区分の変更内容または承認待ち内容が入力した増減数と一致されること。	"確認場所: 在庫管理 — 在庫編集機能（M04-02） / 照合キー: 商品コード・店舗・在庫区分 / 出典: scenario_test/markdown/10_商品登録・編集_tobe.md:120 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:1582#sheet-6
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: 対象商品・店舗・在庫区分の変更内容または承認待ち内容が入力した増減数と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-02_admin_stock_stock_edit.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-007	-	代替フロー	P1	代替系 #6: トレードチームが「販促として、特集ページやへの記載や告知等を販売開始時に併せて行う」を行い「特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
2. 「販促として、特集ページやへの記載や告知等を販売開始時に併せて行う」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 の対応を記録する"	特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-008	-	代替フロー	P1	代替系 A1 #1: トレードチームが「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を行い「特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 分岐条件を満たす対象データを、正常代表データとは別IDで用意する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
入力=条件「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を満たす対象データ / 商品コード=ST-PRODUCT-PRODUCT-006-R02-A1 / 基準=商品コード=ST-PRODUCT-PRODUCT-006-R02"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 条件「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を満たす対象データ / 商品コード=ST-PRODUCT-PRODUCT-006-R02-A1 / 基準=商品コード=ST-PRODUCT-PRODUCT-006-R02
2. 分岐条件「分岐条件を満たす対象データを、正常代表データとは別IDで用意する。」を成立させる
3. 「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を実施する
【操作後確認】
4. カードで、特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 条件「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を満たす対象データ / 商品コード=ST-PRODUCT-PRODUCT-006-R02-A1 / 基準=商品コード=ST-PRODUCT-PRODUCT-006-R02 の対応を記録する"	特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-PRODUCT-PRODUCT-006-R02
合格条件: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2"
商品登録・編集 — 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）	STI-PRODUCT-011-009	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #84 商品*5	"元シナリオ: SCN-PRODUCT-高額商品登録ナンバー-011 高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）
業務: 商品登録・編集
経路ID: R02
経路種別: 主要代替
業務経路条件: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合
最終業務状態: 特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-product-006-r02 / 会員番号=ST-MEMBER-PRODUCT-006-R02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M14-01, M14-04, M03-26, M04-02; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md データ連鎖 DL-01 / 商品登録・編集 / パターン6 / 経路2 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
連鎖ID=DL-01
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M14-01, M14-04, M03-26, M04-02; 未実装指摘あり=4（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-006-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-006-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-006-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-006-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「カードデータが未登録かの判断結果として実線で「2-4～2-6を行う」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-006-r02 / 商品コード=ST-PRODUCT-PRODUCT-006-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円
3. 代替系#1: トレードチームが「商品画像準備として、スキャンや写真撮影等で商品画像を用意」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
4. 代替系#2: トレードチームがカード管理 — カード検索（一覧・条件抽出）で「カードデータ有無として、カードデータが無い場合カードデータの新規登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
5. 代替系#3: トレードチームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「カードデータ登録として、カードデータの登録および商品登録を行う。 ※画像データは用意したデータを使う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
6. 代替系#4: トレードチームが商品管理 — カード商品CSV登録で「商品登録として、商品マスターから商品の設定ページ(商品登録)へ 個別登録するカードへ用意した商品画像を追加 規格設定へ行き、新規登録から情報を登録する 在庫を入れて販売開始をする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
7. 代替系#5: お客様が在庫管理 — 在庫編集機能で「商品コード・店舗・在庫区分を照合して在庫編集し、承認が必要な理由区分では承認工程へ引き継ぐ」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
8. 代替系#6: トレードチームが「販促として、特集ページやへの記載や告知等を販売開始時に併せて行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-006-R02
【操作後確認】
9. 最終業務状態「特集ページやへの記載や告知等を販売開始時に併せて行うことを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#83 商品マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#84 商品*5をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #83 商品マスター の成果物 #84 商品*5 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #84 商品*5
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #83 商品マスター の成果物 #84 商品*5 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-011-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-011-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md / 商品登録・編集 / パターン6 / 経路2
判定根拠: scenario_test/scenario/SCN-PRODUCT-高額商品登録ナンバー-011_高額商品登録(#ナンバー等個別登録商品作成)（カードデータが未登録か：2-4～2-6を行う）.md データ連鎖 DL-01 / 商品登録・編集 / パターン6 / 経路2 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
