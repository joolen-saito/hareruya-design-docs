<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 借用（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-01 | テスト項目化 | あり | データ更新 |
| M04-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-09 | テスト項目化 | あり | CSV/帳票、データ更新 |
| M04-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-22 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-25 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-26 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-28 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-32 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-33 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-34 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録される」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 通販チームが在庫管理 — 在庫検索/一覧で「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
6. 正常系#4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
7. 正常系#5: EC-CUBE（本店）が「返却として、返却する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
8. 正常系#6: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
【操作後確認】
10. 最終業務状態「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。	"確認場所: 画面表示・処理ステータス・処理履歴 / 出力されたCSV/帳票の件数と内容 / 照合キー: 在庫移動・振替ID・商品コード・入庫先店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:374 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3203#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3291#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 同一店舗と店舗間を分けて実施。店舗内移動の新HTMLには独立承認工程がない。 / 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-002	M04-01	データ更新	P1	正常系 #1: 通販チームが「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を行い「撮影などでカードを借用する場合があることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 処理後の画面表示 を記録する"	撮影などでカードを借用する場合があることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 画面表示・処理ステータス・処理履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 撮影などでカードを借用する場合があることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-003	M04-09	CSV/帳票	P1	正常系 #2: 通販チームが「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を行い「そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績が完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-004	M04-09	データ更新	P1	正常系 #3: トレードチームが「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を行い「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録される」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 在庫移動・振替ID・商品コード・入庫先店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:374 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3203#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:3291#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14 / 設計差・留意点: 同一店舗と店舗間を分けて実施。店舗内移動の新HTMLには独立承認工程がない。
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-005	-	データ更新	P1	正常系 #4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を行い「持ち出して撮影等を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: EC-CUBE（本店）
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
2. 「持ち出しとして、持ち出して撮影等を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、持ち出して撮影等を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	持ち出して撮影等を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 持ち出して撮影等を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-006	-	データ更新	P1	正常系 #5: EC-CUBE（本店）が「返却として、返却する」を行い「返却することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: EC-CUBE（本店）
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
2. 「返却として、返却する」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、返却することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード の対応を記録する"	返却することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 返却することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-007	M04-09	データ更新	P1	正常系 #6: 通販チームが「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を行い「トレードチームがECCUBE貸出店から元の在庫へ在庫を移動することを、在庫数と在庫変更履歴で確認できる」を確認する	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	トレードチームがECCUBE貸出店から元の在庫へ在庫を移動することを、在庫数と在庫変更履歴で確認できること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 在庫数と在庫変更履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: トレードチームがECCUBE貸出店から元の在庫へ在庫を移動することを、在庫数と在庫変更履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-008	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #358 在庫移動	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン17 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-01
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 通販チームが在庫管理 — 在庫検索/一覧で「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
6. 正常系#4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
7. 正常系#5: EC-CUBE（本店）が「返却として、返却する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
8. 正常系#6: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
【操作後確認】
10. 最終業務状態「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#357 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01。
【操作】
産出工程の完了直後に#358 在庫移動をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #357 在庫移動・振替登録 編集 の成果物 #358 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #358 在庫移動
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 産出工程 #357 在庫移動・振替登録 編集 の成果物 #358 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-01 / 在庫管理 / パターン17 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-009	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #361 在庫履歴	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-02 / 在庫管理 / パターン17 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-02
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 通販チームが在庫管理 — 在庫検索/一覧で「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
6. 正常系#4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
7. 正常系#5: EC-CUBE（本店）が「返却として、返却する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
8. 正常系#6: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
【操作後確認】
10. 最終業務状態「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#360 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01。
【操作】
産出工程の完了直後に#361 在庫履歴をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #360 在庫移動・振替登録 編集 の成果物 #361 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #361 在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 産出工程 #360 在庫移動・振替登録 編集 の成果物 #361 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-02 / 在庫管理 / パターン17 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-010	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #365 在庫移動	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-03 / 在庫管理 / パターン17 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-03
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 通販チームが在庫管理 — 在庫検索/一覧で「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
6. 正常系#4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
7. 正常系#5: EC-CUBE（本店）が「返却として、返却する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
8. 正常系#6: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
【操作後確認】
10. 最終業務状態「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#364 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01。
【操作】
産出工程の完了直後に#365 在庫移動をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #364 在庫移動・振替登録 編集 の成果物 #365 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #365 在庫移動
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 産出工程 #364 在庫移動・振替登録 編集 の成果物 #365 在庫移動 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-03 / 在庫管理 / パターン17 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
在庫管理 — 借用（原典実線の代表経路）	STI-ZAIKO-026-011	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #368 在庫履歴	"元シナリオ: SCN-ZAIKO-借用-026 借用（原典実線の代表経路）
業務: 在庫管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-zaiko-017-r01 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-04 / 在庫管理 / パターン17 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
連鎖ID=DL-04
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-01, M04-09; 未実装指摘あり=5（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-026-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-017-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-026-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-017-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-017-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-017-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-017-r01 / 商品コード=ST-STOCK-ZAIKO-017-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-017-R01 / 移動元ロケーション=本店バックヤード
3. 正常系#1: 通販チームが在庫管理 — 在庫検索/一覧で「借用対象商品検索として、撮影などでカードを借用する場合がある その場合はECCUBE貸出店（仮）の在庫に在庫移動を行い、 商品を購入されないようにする」を実施する
   対象: 移動元ロケーション=本店バックヤード
4. 正常系#2: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「ECCUBE貸出店への移動を登録するとして、そのまま商品を借りていくだけなので、ピック表の出力や在庫移動実績」を実施する
   対象: 移動元ロケーション=本店バックヤード
5. 正常系#3: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
6. 正常系#4: EC-CUBE（本店）が「持ち出しとして、持ち出して撮影等を行う」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
7. 正常系#5: EC-CUBE（本店）が「返却として、返却する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
8. 正常系#6: 通販チームが在庫管理 — 在庫移動・振替登録/編集で「元の在庫への移動を登録するとして、トレードチームがECCUBE貸出店から元の在庫へ在庫を移動する 貸出店への移動と同じ手順となる」を実施する
   対象: 移動元ロケーション=本店バックヤード
9. 正常系#7: トレードチームが在庫管理 — 在庫移動・振替登録/編集で「同じ在庫移動IDについて実移動点数と現物の差分を登録し、入庫先店舗の承認者が入庫を承認する。店舗内移動は店舗内入庫確定を使用する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-017-R01
【操作後確認】
10. 最終業務状態「対象移動が入庫完了となり、入庫先在庫の増分が移動点数－欠品点数－差分点数に一致し、承認者・日時・在庫履歴が記録されること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#367 在庫移動・振替登録 編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-017-R01。
【操作】
産出工程の完了直後に#368 在庫履歴をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #367 在庫移動・振替登録 編集 の成果物 #368 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #368 在庫履歴
照合キー: 商品コード=ST-STOCK-ZAIKO-017-R01
合格条件: 産出工程 #367 在庫移動・振替登録 編集 の成果物 #368 在庫履歴 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-017-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-026-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-026-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md / 在庫管理 / パターン17 / 経路1
判定根拠: scenario_test/scenario/SCN-ZAIKO-借用-026_借用（原典実線の代表経路）.md データ連鎖 DL-04 / 在庫管理 / パターン17 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
