<!-- generated-by: hareruya-scenario-test-items -->
# イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M13-06 | テスト項目化 | あり | 代替フロー |
| M13-07 | テスト項目化 | あり | 代替業務 |
| M13-10 | テスト項目化 | あり | 代替業務 |
| M13-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F07-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B13-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-16 | テスト項目化 | あり | 代替フロー |
| F06-17 | テスト項目化 | あり | 代替フロー |
| M15-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。	"確認場所: 一覧・詳細に追加された対象データ / 照合キー: 会員ID・イベント日程ID・デッキID / 出典: scenario_test/markdown/08_イベント管理.md:39 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3081#sheet-13 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3423#sheet-14 / 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。 / 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-002	M13-06	代替フロー	P1	代替系 #1: お客様が「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を行い「オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md（イベント管理 — イベント申込検索）
【操作】
1. 管理画面で イベント管理 — イベント申込検索 を開く
2. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
【操作後確認】
4. イベント管理 — イベント申込検索 で対象キーと 処理後の画面表示 を記録する"	オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: イベント管理 — イベント申込検索（M13-06） / 一覧・詳細に追加された対象データ
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-06_admin_event_event_entry_management_search.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-003	F06-16,F06-17	代替フロー	P1	代替系 #2: お客様が「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を行い「同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致される」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md（F06-16（大会デッキ登録編集））
- 必須入力欄: フォーマット
- この工程で通過する機能: F06-16 F06-16（大会デッキ登録編集） → F06-17 F06-17（大会に登録するデッキの確認・登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md（F06-16（大会デッキ登録編集））
14. 必須入力欄: フォーマット
15. この工程で通過する機能: F06-16 F06-16（大会デッキ登録編集） → F06-17 F06-17（大会に登録するデッキの確認・登録）
【操作】
1. フロント画面で F06-16（大会デッキ登録編集） を開く
2. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 通過する機能: F06-16 → F06-17。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
【操作後確認】
5. F06-16（大会デッキ登録編集） で対象キーと 処理後の画面表示 を記録する"	同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致されること。	"確認場所: F06-16（大会デッキ登録編集）（F06-16,F06-17） / 照合キー: 会員ID・イベント日程ID・デッキID / 出典: scenario_test/markdown/08_イベント管理.md:39 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3081#sheet-13 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:3423#sheet-14
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 同じ会員・大会日程に使用デッキが登録され、カード名・枚数が確認時の内容と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f06-16_front_member_mypage_event_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-004	-	代替業務	P1	代替系 #3: お客様が「キャンセル有無を行う」を行い「判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態である」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
2. 「キャンセル有無を行う」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。で、判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進めること。の実値と対象データ 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円 の対応を記録する"	判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/08_イベント管理.md:41 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-005	M13-07	代替業務	P1	代替系 #4: お客様が「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を行い「オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md（イベント管理 — イベント申込一括編集）
- 必須入力欄: 申込ステータス / 対象申込"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md（イベント管理 — イベント申込一括編集）
14. 必須入力欄: 申込ステータス / 対象申込
【操作】
1. 管理画面で イベント管理 — イベント申込一括編集 を開く
2. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
【操作後確認】
4. イベント管理 — イベント申込一括編集 で対象キーと 処理後の画面表示 を記録する"	オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: イベント管理 — イベント申込一括編集（M13-07） / 一覧・詳細に追加された対象データ
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-07_admin_event_event_entry_bulk_update.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-006	M13-10	代替業務	P1	代替系 #5: 店舗チームが「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を行い「イベントID=ST-EVENT-EVENT-002-R02 の処理後の値が イベント管理 — イベント申込詳細・編集 に更新される」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-10_admin_event_event_entry_edit.md（イベント管理 — イベント申込詳細・編集）
- 必須入力欄: 申込状況 / 支払方法 / 支払金額 / 参加プレイヤー情報"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-10_admin_event_event_entry_edit.md（イベント管理 — イベント申込詳細・編集）
14. 必須入力欄: 申込状況 / 支払方法 / 支払金額 / 参加プレイヤー情報
【操作】
1. 管理画面で イベント管理 — イベント申込詳細・編集 を開く
2. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
【操作後確認】
4. イベント管理 — イベント申込詳細・編集 で対象キーと 保存しました を記録する"	イベントID=ST-EVENT-EVENT-002-R02 の処理後の値が イベント管理 — イベント申込詳細・編集 に更新されること。	"確認場所: イベント管理 — イベント申込詳細・編集（M13-10） / 照合キー: 申込ID・イベント日程ID / 出典: scenario_test/markdown/08_イベント管理.md:46 / excel_to_html/output/0214_基本設計仕様書(イベント管理).html:2909#sheet-15
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: イベントID=ST-EVENT-EVENT-002-R02 の処理後の値が イベント管理 — イベント申込詳細・編集 に更新されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-10_admin_event_event_entry_edit.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-007	-	代替業務	P1	代替系 #6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を行い「キャンセル内容をフォームに記載することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
2. 「返金依頼として、キャンセル内容をフォームに記載する」を実施する
【操作後確認】
3. キャンセル内容をフォームで、キャンセル内容をフォームに記載することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円 の対応を記録する"	キャンセル内容をフォームに記載することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: キャンセル内容をフォームに記載することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-008	-	代替業務	P1	代替系 #7: トレードチームが「返金処理として、返金処理を行う」を行い「返金処理を行うことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
2. 「返金処理として、返金処理を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、返金処理を行うことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円 の対応を記録する"	返金処理を行うことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 返金処理を行うことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-009	-	代替業務	P1	代替系 #8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を行い「メールにてキャンセル手続きが完了したことを通知することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
2. 「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、メールにてキャンセル手続きが完了したことを通知することを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円 の対応を記録する"	メールにてキャンセル手続きが完了したことを通知することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: メールにてキャンセル手続きが完了したことを通知することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-010	-	代替業務	P1	代替系 A1 #1: 店舗チームが「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を行い「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
入力=商品コード=ST-CARD-EVENT-002-R02-A1 / キャンセル希望=あり / 参加費=1,000円"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 商品コード=ST-CARD-EVENT-002-R02-A1 / キャンセル希望=あり / 参加費=1,000円
2. 分岐条件「参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。」を成立させる
3. 「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を実施する
【操作後確認】
4. 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できるで、同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。の実値と対象データ 商品コード=ST-CARD-EVENT-002-R02-A1 / キャンセル希望=あり / 参加費=1,000円 の対応を記録する"	同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。	"確認場所: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できる
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-011	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #14 イベント情報*1	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-01 / イベント管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-01
照合キー=イベントID=ST-EVENT-EVENT-002-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#13 イベント・大会申込、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-002-R02。
【操作】
産出工程の完了直後に#14 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #13 イベント・大会申込 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #14 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 産出工程 #13 イベント・大会申込 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-01 / イベント管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-012	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #14 イベント情報*1	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-02 / イベント管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-02
照合キー=イベントID=ST-EVENT-EVENT-002-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#15 イベント・大会デッキ登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-002-R02。
【操作】
産出工程の完了直後に#14 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #15 イベント・大会デッキ登録 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #14 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 産出工程 #15 イベント・大会デッキ登録 の成果物 #14 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-02 / イベント管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-013	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #20 メール	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-03 / イベント管理 / パターン2 / 経路2 / scenario_test/markdown/08_イベント管理.md R75-R120"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-03
照合キー=イベント申込IDと対応付けたメール原本のMessage-ID"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#19 キャンセル申込、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベント申込IDと対応付けたメール原本のMessage-ID。対象イベントの申込者が指定したキャンセル/問い合わせ内容を送信前に保存し、店舗が受信した同じメールの差出人・宛先・件名・本文と比較する。申込ID・申込者・送信原本Message-IDを証跡上で対応付ける。本文に申込ID列の存在を仮定しない。
【操作】
産出工程の完了直後に#20 メールをproducer原本として保存する。
産出原本から 差出人・宛先・件名・本文の対象イベントと依頼/完了内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #19 キャンセル申込 の成果物 #20 メール の差出人・宛先・件名・本文の対象イベントと依頼/完了内容が、照合キー イベント申込IDと対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。	"確認場所: #20 メール
照合キー: イベント申込IDと対応付けたメール原本のMessage-ID
合格条件: 産出工程 #19 キャンセル申込 の成果物 #20 メール の差出人・宛先・件名・本文の対象イベントと依頼/完了内容が、照合キー イベント申込IDと対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-03 / イベント管理 / パターン2 / 経路2 / scenario_test/markdown/08_イベント管理.md R75-R120
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-014	-	データ連鎖	P1	代替系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #25 イベント情報*1	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-04 / イベント管理 / パターン2 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-04
照合キー=イベントID=ST-EVENT-EVENT-002-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#24 イベント申込一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-002-R02。
【操作】
産出工程の完了直後に#25 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #24 イベント申込一覧 の成果物 #25 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #25 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-002-R02
合格条件: 産出工程 #24 イベント申込一覧 の成果物 #25 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-002-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-04 / イベント管理 / パターン2 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-015	-	データ連鎖	P1	代替系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #22 返金依頼フォーム	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-05 / イベント管理 / パターン2 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-05 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
- 解除条件: #22 返金依頼フォームの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は返金依頼フォームへの入力を記載するが、外部フォームの項目・受付ID・保存先を定義していない。 必要な判断: 経理/イベント担当が実フォームのURL・必須項目・受付記録を提示し、申込IDと返金先/額の対応を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は返金依頼フォームへの入力を記載するが、外部フォームの項目・受付ID・保存先を定義していない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-05
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-05: #22 返金依頼フォームの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は返金依頼フォームへの入力を記載するが、外部フォームの項目・受付ID・保存先を定義していない。 必要な判断: 経理/イベント担当が実フォームのURL・必須項目・受付記録を提示し、申込IDと返金先/額の対応を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #22 返金依頼フォーム
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-05 / イベント管理 / パターン2 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-05 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
イベント管理 — イベント受付(オンライン受付)（キャンセル申込・返金完了）	STI-EVENT-004-016	-	データ連鎖	P1	代替系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #27 メール	"元シナリオ: SCN-EVENT-イベント受付オンライ-004 イベント受付(オンライン受付)（キャンセル申込・返金完了）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）
最終業務状態: 同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 参加費支払済みのテスト申込を用意し、該当イベントのキャンペーン条件に対する対象/対象外を事前に確定する。
シードデータ: 担当者アカウント=st-user-event-002-r02 / 会員番号=ST-MEMBER-EVENT-002-R02 / 商品コード=ST-CARD-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-002-R02 / イベント名=システムテスト大会 EVENT-002-R02 / 定員=8名 / 受付状態=受付前 / キャンセル希望=あり / 参加費=1,000円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-06 / イベント管理 / パターン2 / 経路2 / scenario_test/markdown/08_イベント管理.md R75-R120"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
連鎖ID=DL-06
照合キー=イベント申込IDと対応付けたメール原本のMessage-ID"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-06, F06-16, F06-17, M13-07; 未実装指摘あり=3; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-002-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-002-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-002-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-event-002-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R02（主要代替）の条件「キャンセル希望=あり、参加費=1,000円（原典本文 08_イベント管理.md R71–131,図形#17/#29「キャンセル申込」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-002-r02 / 商品コード=ST-CARD-EVENT-002-R02 / イベントID=ST-EVENT-EVENT-002-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 / キャンセル希望=あり / 参加費=1,000円
3. 代替系#1: お客様がイベント管理 — イベント申込検索で「イベント・大会として、オンライン受付ありでイベント作成されている場合、ECサイトより 申込 イベント・大会申込を実施する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
4. 代替系#2: お客様がF06-16（大会デッキ登録編集）で「対象イベント日程を選び使用デッキを入力し、確認画面で登録を確定する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
5. 代替系#3: お客様が「キャンセル有無を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
6. 代替系#4: お客様がイベント管理 — イベント申込一括編集で「キャンセル申込として、オンライン受付ありでイベント作成されている場合、ECサイトより キャンセル申込を行う」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
7. 代替系#5: 店舗チームがイベント管理 — イベント申込詳細・編集で「キャンセル申込メールの申込者・対象日程と申込IDを照合し、申込状況をキャンセル済みに変更する」を実施する
   対象: イベントID=ST-EVENT-EVENT-002-R02
8. 代替系#6: 店舗チームが「返金依頼として、キャンセル内容をフォームに記載する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
9. 代替系#7: トレードチームが「返金処理として、返金処理を行う」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
10. 代替系#8: 店舗チームが「キャンセル完了として、メールにてキャンセル手続きが完了したことを通知する」を実施する
   対象: 商品コード=ST-CARD-EVENT-002-R02
【操作後確認】
11. 最終業務状態「同じイベント申込がキャンセルされ、返金依頼から返金完了・顧客連絡まで追跡できることを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-06。以下の#番号は原典ノード番号。産出=#26 キャンセル完了連絡、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベント申込IDと対応付けたメール原本のMessage-ID。対象イベントの申込キャンセル結果を保存し、同じ申込者への完了メールの宛先とキャンセル内容を照合する。申込ID・申込者・送信原本Message-IDを証跡上で対応付ける。本文に申込ID列の存在を仮定しない。
【操作】
産出工程の完了直後に#27 メールをproducer原本として保存する。
産出原本から 差出人・宛先・件名・本文の対象イベントと依頼/完了内容 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #26 キャンセル完了連絡 の成果物 #27 メール の差出人・宛先・件名・本文の対象イベントと依頼/完了内容が、照合キー イベント申込IDと対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。	"確認場所: #27 メール
照合キー: イベント申込IDと対応付けたメール原本のMessage-ID
合格条件: 産出工程 #26 キャンセル完了連絡 の成果物 #27 メール の差出人・宛先・件名・本文の対象イベントと依頼/完了内容が、照合キー イベント申込IDと対応付けたメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-004-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-004-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md / イベント管理 / パターン2 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベント受付オンライ-004_イベント受付(オンライン受付)（キャンセル申込・返金完了）.md データ連鎖 DL-06 / イベント管理 / パターン2 / 経路2 / scenario_test/markdown/08_イベント管理.md R75-R120
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
