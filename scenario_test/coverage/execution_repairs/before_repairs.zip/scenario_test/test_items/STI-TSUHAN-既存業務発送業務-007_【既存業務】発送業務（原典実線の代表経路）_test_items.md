<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — 【既存業務】発送業務（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | テスト項目化 | あり | CSV/帳票 |
| M05-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-18 | テスト項目化 | あり | CSV/帳票、メール/通知 |
| M05-19 | テスト項目化 | あり | 業務操作、CSV/帳票、メール/通知 |
| M05-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-22 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-26 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-06 | テスト項目化 | あり | メール/通知 |
| M05-11 | テスト項目化 | あり | 照合、在庫整合 |
| M05-12 | テスト項目化 | あり | メール/通知 |
| M05-14 | テスト項目化 | あり | メール/通知 |
| M05-15 | テスト項目化 | あり | メール/通知 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 照合キー: 受注番号 / 出典: scenario_test/markdown/17_通販受注管理_tobe.md:23 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2712#sheet-15 / 一覧・詳細に追加された対象データ / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-002	M05-11	照合	P1	正常系 #1: 通販チームが「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を行い「同じ受注番号の対応状況・ショップメモと発送管理台帳の発送予定が処置内容に一致される」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
【操作】
1. 管理画面で 受注管理 — 受注情報編集 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
【操作後確認】
4. 受注管理 — 受注情報編集 で対象キーと 保存しました を記録する"	同じ受注番号の対応状況・ショップメモと発送管理台帳の発送予定が処置内容に一致されること。	"確認場所: 受注管理 — 受注情報編集（M05-11） / 照合キー: 受注番号 / 出典: scenario_test/markdown/17_通販受注管理_tobe.md:23 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2712#sheet-15
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 同じ受注番号の対応状況・ショップメモと発送管理台帳の発送予定が処置内容に一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-003	M05-01	CSV/帳票	P1	正常系 #2: 通販チームが「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を行い「当日の発送数が決定したら発送のチェックリストを作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md（受注管理 — 受注情報検索・一覧）
【操作】
1. 管理画面で 受注管理 — 受注情報検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
【操作後確認】
4. 受注管理 — 受注情報検索・一覧 で対象キーと 検索条件を保存しました を記録する"	当日の発送数が決定したら発送のチェックリストを作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 受注管理 — 受注情報検索・一覧（M05-01） / 一覧・詳細に追加された対象データ
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 当日の発送数が決定したら発送のチェックリストを作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索条件を保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-01_admin_order_order_search_list.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-004	-	業務操作	P1	正常系 #3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を行い「作成したチェックリストを元に、チェック作業を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
【操作後確認】
3. 作成したチェックリストで、作成したチェックリストを元に、チェック作業を行うことを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	作成したチェックリストを元に、チェック作業を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 作成したチェックリストを元に、チェック作業を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-005	-	データ更新	P1	正常系 #4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を行い「集荷が来たタイミングで用意できた発送予定の商品を発送することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
【操作後確認】
3. 商品で、集荷が来たタイミングで用意できた発送予定の商品を発送することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	集荷が来たタイミングで用意できた発送予定の商品を発送することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 集荷が来たタイミングで用意できた発送予定の商品を発送することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-006	-	CSV/帳票	P1	正常系 #5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を行い「海外ラベルデータ取り込み・印刷を行うことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
【操作後確認】
3. 海外は送り状CSVで、海外ラベルデータ取り込み・印刷を行うことを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	海外ラベルデータ取り込み・印刷を行うことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 海外ラベルデータ取り込み・印刷を行うことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-007	-	CSV/帳票	P1	正常系 #6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を行い「発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
【操作後確認】
3. 海外チェックリスト・発送チェックリスト作成マクロで発送チェックリスト・発送管理は専用のExcel管理台帳で、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成することを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-008	-	CSV/帳票	P1	正常系 #7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を行い「国内の出ないものリスト作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
【操作後確認】
3. 未発送品リスト・国内の出ないものリスト・チェックリストの作成ミスの防止で別途未発送品のリスト・発送管理台帳・こちらも管理台帳で、国内の出ないものリスト作成することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	国内の出ないものリスト作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 国内の出ないものリスト作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-009	-	業務操作	P1	正常系 #8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を行い「出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-010	M05-18	CSV/帳票	P1	正常系 #9: 通販チームが「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を行い「集荷完了後、出荷実績インポートに出荷データをインポートが完了したことを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 保存しました を記録する"	集荷完了後、出荷実績インポートに出荷データをインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 取込結果と対象件数・エラー行
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 集荷完了後、出荷実績インポートに出荷データをインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-010、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-011	M05-14,M05-12,M05-15,M05-06	メール/通知	P1	正常系 #10: 通販チームが「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を行い「当日の同梱注文の出荷処理を手動対応することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md（受注管理 — 受注対応状況の変更）
- 必須入力欄: 対応状況
- この工程で通過する機能: M05-14 受注管理 — 受注対応状況の変更 → M05-12 m05-12_admin_order_order_bulk_status_change（管理画面_受注管理_対応状況一括変更） → M05-15 受注管理 — 受注詳細メール通知 → M05-06 受注管理 — メール一括送信"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md（受注管理 — 受注対応状況の変更）
15. 必須入力欄: 対応状況
16. この工程で通過する機能: M05-14 受注管理 — 受注対応状況の変更 → M05-12 m05-12_admin_order_order_bulk_status_change（管理画面_受注管理_対応状況一括変更） → M05-15 受注管理 — 受注詳細メール通知 → M05-06 受注管理 — メール一括送信
【操作】
1. 管理画面で 受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06） を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 通過する機能: M05-14 → M05-12 → M05-15 → M05-06。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
【操作後確認】
5. 受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06） で対象キーと 保存しました を記録する"	当日の同梱注文の出荷処理を手動対応することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 受注管理 — 受注対応状況の変更（M05-14,M05-12,M05-15,M05-06） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 当日の同梱注文の出荷処理を手動対応することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m05-14_admin_order_order_status_change.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-012	-	データ更新	P1	正常系 #11: 通販チームが「早番退勤前を行う」を行い「早番退勤前が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「早番退勤前を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、早番退勤前が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	早番退勤前が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 早番退勤前が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-013	-	業務操作	P1	正常系 #12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を行い「海外の発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
2. 「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、海外の発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01 の対応を記録する"	海外の発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 海外の発送管理アプリで出荷書類を作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-014	M05-19	業務操作	P1	正常系 #13: 通販チームが「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を行い「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト検索 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト検索 で対象キーと 処理後の画面表示 を記録する"	出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 受注管理 — 出荷指示リスト検索（M05-19） / 取込結果と対象件数・エラー行
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-014、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-015	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #4 受注*4	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン4 / 経路1 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
連鎖ID=DL-01
照合キー=受注番号（当該受注の実番号）"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#3 受注マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#4 受注*4をproducer原本として保存する。
産出原本から 受注番号・商品・数量・請求金額 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #3 受注マスター の成果物 #4 受注*4 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。	"確認場所: #4 受注*4
照合キー: 受注番号（当該受注の実番号）
合格条件: 産出工程 #3 受注マスター の成果物 #4 受注*4 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-01 / 通販受注管理 / パターン4 / 経路1 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-016	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #20 未発送品リスト	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-02 / 通販受注管理 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
連鎖ID=DL-02
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#19 未発送品リスト作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01。
【操作】
産出工程の完了直後に#20 未発送品リストをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #19 未発送品リスト作成 の成果物 #20 未発送品リスト の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #20 未発送品リスト
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 産出工程 #19 未発送品リスト作成 の成果物 #20 未発送品リスト の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-02 / 通販受注管理 / パターン4 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-017	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #23 出荷書類	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-03 / 通販受注管理 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
連鎖ID=DL-03
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#22 EMS後納表作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01。
【操作】
産出工程の完了直後に#23 出荷書類をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #22 EMS後納表作成 の成果物 #23 出荷書類 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #23 出荷書類
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 産出工程 #22 EMS後納表作成 の成果物 #23 出荷書類 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-03 / 通販受注管理 / パターン4 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-018	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #34 受注*5	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-04 / 通販受注管理 / パターン4 / 経路1 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
連鎖ID=DL-04
照合キー=受注番号（当該受注の実番号）"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#33 受注マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#34 受注*5をproducer原本として保存する。
産出原本から 受注番号・商品・数量・請求金額 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #33 受注マスター の成果物 #34 受注*5 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。	"確認場所: #34 受注*5
照合キー: 受注番号（当該受注の実番号）
合格条件: 産出工程 #33 受注マスター の成果物 #34 受注*5 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-04 / 通販受注管理 / パターン4 / 経路1 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-019	-	データ連鎖	P1	正常系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #42 出荷書類	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-05 / 通販受注管理 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
連鎖ID=DL-05
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M05-01, M05-14, M05-12, M05-15, M05-06; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 正常系#1: 通販チームが受注管理 — 受注情報編集で「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
4. 正常系#2: 通販チームが受注管理 — 受注情報検索・一覧で「国内チェックリスト作成として、当日の発送数が決定したら発送のチェックリストを作成 追跡情報はラベル印刷アプリからダウンロード 16時ごろに完了めどで作業」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
5. 正常系#3: 通販チームが「16時よりとして、作成したチェックリストを元に、チェック作業を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
6. 正常系#4: 通販チームが「国内発送として、集荷が来たタイミングで用意できた発送予定の商品を発送する ゆうパックは17時ごろ集荷、ゆうパケットは18時ごろ集荷 ※当日発送はここまでがリミット」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
7. 正常系#5: 通販チームが「海外ラベルデータ作業として、海外ラベルデータ取り込み・印刷を行う 必要なデータをそろえてマクロを起動 できたデータを海外発送管理アプリにインポート ※海外は送り状CSVを外部マクロで成型する」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
8. 正常系#6: 通販チームが「海外チェックリスト作成として、発送管理アプリから追跡情報のデータをダウンロード 発送チェックリスト作成マクロで発送チェックリストを作成 発送管理は専用のExcel管理台帳で管理 追跡情報は海外発送の管理アプリで作成保存されている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
9. 正常系#7: 通販チームが「未発送品リスト作成として、国内の出ないものリスト作成 チェックリストの作成ミスの防止で別途未発送品のリストを作成 発送管理台帳上で未発送のものを手動で抜き出し印刷・目視確認 ※こちらも管理台帳で対応」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
10. 正常系#8: 通販チームが「EMS後納表作成として、出荷チェックが問題なければ海外発送管理アプリで出荷書類を作成」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
11. 正常系#9: 通販チームが受注管理 — 出荷指示リスト作成で「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
12. 正常系#10: 通販チームが受注管理 — 受注対応状況の変更 ほか（M05-14・M05-12・M05-15・M05-06）で「同梱出荷処理として、当日の同梱注文の出荷処理を手動対応 ステータス出荷完了への更新と手動メール通知よりメール送信 EMSの当日出荷が確定したら出荷実績インポートへインポート」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
13. 正常系#11: 通販チームが「早番退勤前を行う」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
14. 正常系#12: 通販チームが「翌朝8:30として、海外の発送管理アプリで出荷書類を作成 smallpacket発送処理 前日smallpacketを当日の朝郵便局に持ち込み」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
15. 正常系#13: 通販チームが受注管理 — 出荷指示リスト検索で「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-004-R01
【操作後確認】
16. 最終業務状態「出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#41 smallpacket発送、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号=ST-ORDER-TSUHAN-004-R01。
【操作】
産出工程の完了直後に#42 出荷書類をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #41 smallpacket発送 の成果物 #42 出荷書類 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #42 出荷書類
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 産出工程 #41 smallpacket発送 の成果物 #42 出荷書類 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 受注番号=ST-ORDER-TSUHAN-004-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md データ連鎖 DL-05 / 通販受注管理 / パターン4 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-020	M05-11	在庫整合	P1	正常系 工程#1 判定: 15時追加ピック分終了後の現物と作業元明細の一致	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
- 判定用準備: ST-CARD-TSUHAN-004-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md 実行手順 / 通販受注管理 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
判定用具体値: ST-CARD-TSUHAN-004-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。"	"担当者: 通販チーム
【準備確認】
判定用準備: ST-CARD-TSUHAN-004-R01 の作業元明細（操作に記載されたリスト・依頼書・入力ファイル）を原本保存し、商品識別・言語・状態・数量を記録する。差異を扱う経路では差異修正後の確定明細を比較基準にする。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
【操作】
1. 管理画面で 受注管理 — 受注情報編集 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「停止中の受注を同じ受注番号で確認し、対応状況と出荷日を変更し、ショップメモと発送管理台帳に処置を記録する」を実施する
【操作後確認】
4. 受注管理 — 受注情報編集 で対象キーと 保存しました を記録する
具体照合: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"	「15時追加ピック分終了後」で扱った商品 ST-CARD-TSUHAN-004-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。	"確認場所: 受注管理 — 受注情報編集（M05-11） / 発送管理の台帳・商品別数量照合表
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 「15時追加ピック分終了後」で扱った商品 ST-CARD-TSUHAN-004-R01 の現物の商品識別・言語・状態・数量が、作業元明細の同じ商品の値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-020、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md 実行手順 / 通販受注管理 / パターン4 / 経路1
比較規則: 現物を商品ごとに数え、作業元明細と一行ずつ突合する。取り違え・過不足・状態相違を差分表に記録し、未解消差分が0件であることを確認する。"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-021	M05-18	CSV/帳票	P1	正常系 工程#9 判定: 出荷実績の同一受注への反映	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
- 判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=集荷した荷物の実送り状No.、出荷日=集荷完了を記録した実出荷日時の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
判定用具体値: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=集荷した荷物の実送り状No.、出荷日=集荷完了を記録した実出荷日時の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。"	"担当者: 通販チーム
【準備確認】
判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=集荷した荷物の実送り状No.、出荷日=集荷完了を記録した実出荷日時の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 保存しました を記録する
具体照合: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"	受注 ST-ORDER-TSUHAN-004-R01 の送り状No.が出荷実績CSVの集荷した荷物の実送り状No.、全配送先の発送日がCSVの集荷完了を記録した実出荷日時と一致する状態であること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 出荷実績CSV・受注詳細・配送先
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 受注 ST-ORDER-TSUHAN-004-R01 の送り状No.が出荷実績CSVの集荷した荷物の実送り状No.、全配送先の発送日がCSVの集荷完了を記録した実出荷日時と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-021、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）
比較規則: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-022	M05-18	メール/通知	P1	正常系 工程#9 判定: 出荷完了メールの宛先と履歴	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
- 判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
判定用具体値: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。"	"担当者: 通販チーム
【準備確認】
判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md（受注管理 — 出荷指示リスト作成）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト作成 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「国内発送完了インポート作業として、集荷完了後、出荷実績インポートに出荷データをインポート ※出荷完了メールが一斉送信される 国内発送完了インポート作業 集荷完了後、在庫移動実績インポートに在庫移動実績CSVをインポート （在庫移動時） ※在庫移動ステータスが更新される」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト作成 で対象キーと 保存しました を記録する
具体照合: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"	出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。	"確認場所: 受注管理 — 出荷指示リスト作成（M05-18） / 受信箱・受注メール送信履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-022/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-022、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-18_admin_order_order_shipping_standby_list_create.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）
比較規則: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-023	M05-19	CSV/帳票	P1	正常系 工程#13 判定: 出荷実績の同一受注への反映	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）
- 判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
判定用具体値: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。"	"担当者: 通販チーム
【準備確認】
判定用準備: 試験用具体値: 取込前出荷日=空。注文番号は当該受注の実番号、送り状No.=ST-SHIP-001、出荷日=2026/10/09 16:00の出荷実績CSVを用意する。実出荷の工程がある場合はその記録を再利用し、例示の日時や番号へ差し替えない。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト検索 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト検索 で対象キーと 処理後の画面表示 を記録する
具体照合: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"	受注 ST-ORDER-TSUHAN-004-R01 の送り状No.が出荷実績CSVのST-SHIP-001、全配送先の発送日がCSVの2026/10/09 16:00と一致する状態であること。	"確認場所: 受注管理 — 出荷指示リスト検索（M05-19） / 出荷実績CSV・受注詳細・配送先
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 受注 ST-ORDER-TSUHAN-004-R01 の送り状No.が出荷実績CSVのST-SHIP-001、全配送先の発送日がCSVの2026/10/09 16:00と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-023/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-023、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷実績インポート登録）
比較規則: 取込前CSVと取込後の受注詳細・配送先を実注文番号で照合する。送り状番号を文字列比較し、配送先ごとの発送日を比較する。"
通販受注管理 — 【既存業務】発送業務（原典実線の代表経路）	STI-TSUHAN-007-024	M05-19	メール/通知	P1	正常系 工程#13 判定: 出荷完了メールの宛先と履歴	"元シナリオ: SCN-TSUHAN-既存業務発送業務-007 【既存業務】発送業務（原典実線の代表経路）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: 出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポートが完了したことを、取込結果と対象件数・エラー行で確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-tsuhan-004-r01 / 会員番号=ST-MEMBER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）
- 判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
- 判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
判定用具体値: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。"	"担当者: 通販チーム
【準備確認】
判定用準備: 受注メールアドレスと店舗代表アドレスを試験用受信箱に設定し、両アドレスを記録する。注文者都道府県=国内の受注を用い日本語定型文を対象とする。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘4件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-007-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-004-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-007-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-004-R01 に対応付ける
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-tsuhan-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
14. 設計根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md（受注管理 — 出荷指示リスト検索）
【操作】
1. 管理画面で 受注管理 — 出荷指示リスト検索 を開く
2. 対象データ: 担当者アカウント=st-user-tsuhan-004-r01 / 受注番号=ST-ORDER-TSUHAN-004-R01 / 商品コード=ST-CARD-TSUHAN-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-004-R01
3. 「smallpacket発送インポートとして、出荷書類の控えをもらったら出荷処理を行い 出荷完了後作成したインポートデータを出荷実績インポートからインポート ※件数が増えてきて15時ごろの対応になったりしている」を実施する
【操作後確認】
4. 受注管理 — 出荷指示リスト検索 で対象キーと 処理後の画面表示 を記録する
具体照合: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"	出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。	"確認場所: 受注管理 — 出荷指示リスト検索（M05-19） / 受信箱・受注メール送信履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-004-R01
合格条件: 出荷完了メールの宛先が当該受注のメールアドレス、控えが当該店舗の代表アドレスで、受信原本の件名・本文がメール送信履歴と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-007-024/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-007-024、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-19_admin_order_order_shipping_standby_list_search.md
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-既存業務発送業務-007_【既存業務】発送業務（原典実線の代表経路）.md / 通販受注管理 / パターン4 / 経路1
判定根拠: excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-24（出荷完了メールの宛先・控え・言語）
比較規則: 取込開始後の受信原本の宛先・受信日時・件名・本文と、受注のメール送信履歴を対比する。"
```
