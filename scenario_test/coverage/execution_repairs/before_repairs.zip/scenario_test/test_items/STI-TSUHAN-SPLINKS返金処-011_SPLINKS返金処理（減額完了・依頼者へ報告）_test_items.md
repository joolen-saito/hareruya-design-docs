<!-- generated-by: hareruya-scenario-test-items -->
# 通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-15 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F06-19 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できる」を確認する	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト決済3,000円の取引番号を返金依頼フォームに記載し、減額額1,000円を依頼する。SPLINKS検証環境の応答を指定の成功/不能に設定し、応答と報告を保存する。不能理由の種類は原典に規定がないため実エラーコードを業務条件に追加しない。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
3. 正常系#1: 店舗チームが「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を実施する
   対象: 返金対象金額=1,000円
4. 正常系#2: 通販チームが「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
   対象: 返金対象金額=1,000円
5. 正常系#3: 通販チームが「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を実施する
   対象: 返金対象金額=1,000円
【操作後確認】
6. 最終業務状態「依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-002	-	メール/通知	P1	正常系 #1: 店舗チームが「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を行い「顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム）が完了したことを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト決済3,000円の取引番号を返金依頼フォームに記載し、減額額1,000円を依頼する。SPLINKS検証環境の応答を指定の成功/不能に設定し、応答と報告を保存する。不能理由の種類は原典に規定がないため実エラーコードを業務条件に追加しない。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
2. 「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を実施する
【操作後確認】
3. TC東京はGメール・各店舗の大会は依頼フォーム・TC東京も大会は依頼フォーム・SPLINKS・ラインワークス・Gメールで、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム）が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当 の対応を記録する"	顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム）が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム）が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-003	-	外部連携	P1	正常系 #2: 通販チームが「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を行い「依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行が完了したことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト決済3,000円の取引番号を返金依頼フォームに記載し、減額額1,000円を依頼する。SPLINKS検証環境の応答を指定の成功/不能に設定し、応答と報告を保存する。不能理由の種類は原典に規定がないため実エラーコードを業務条件に追加しない。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
2. 「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
【操作後確認】
3. SPLINKSで、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行が完了したことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当 の対応を記録する"	依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行が完了したことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行が完了したことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-004	-	データ更新	P1	正常系 #3: 通販チームが「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を行い「依頼者へ減額処理の対応完了と金額を報告することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト決済3,000円の取引番号を返金依頼フォームに記載し、減額額1,000円を依頼する。SPLINKS検証環境の応答を指定の成功/不能に設定し、応答と報告を保存する。不能理由の種類は原典に規定がないため実エラーコードを業務条件に追加しない。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
2. 「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、依頼者へ減額処理の対応完了と金額を報告することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当 の対応を記録する"	依頼者へ減額処理の対応完了と金額を報告することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 依頼者へ減額処理の対応完了と金額を報告することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-005	-	金額整合	P1	正常系 工程#2 判定: 減額額と決済残額	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 テスト決済3,000円の取引番号を返金依頼フォームに記載し、減額額1,000円を依頼する。SPLINKS検証環境の応答を指定の成功/不能に設定し、応答と報告を保存する。不能理由の種類は原典に規定がないため実エラーコードを業務条件に追加しない。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: 試験用具体値: 決済済金額=3,000円、返金依頼額=1,000円、依頼種別=一部減額。受注番号とSPLINKS取引IDの対応を記録する。
- 判定根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md 実行手順 / 通販受注管理 / パターン8 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
判定用具体値: 試験用具体値: 決済済金額=3,000円、返金依頼額=1,000円、依頼種別=一部減額。受注番号とSPLINKS取引IDの対応を記録する。"	"担当者: 通販チーム
【準備確認】
判定用準備: 試験用具体値: 決済済金額=3,000円、返金依頼額=1,000円、依頼種別=一部減額。受注番号とSPLINKS取引IDの対応を記録する。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
2. 「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
【操作後確認】
3. SPLINKSで、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行が完了したことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-tsuhan-008-r01 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 決済金額=3,000円 / 返金対象金額=1,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当 の対応を記録する
具体照合: SPLINKSの同一取引IDで処理前決済額3,000円、依頼額1,000円、処理後決済額2,000円を対比する。"	受注 ST-ORDER-TSUHAN-008-R01 に対応するSPLINKS取引の処理後決済額が3,000円－1,000円＝2,000円であること。	"確認場所: SPLINKS取引詳細・決済履歴
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 受注 ST-ORDER-TSUHAN-008-R01 に対応するSPLINKS取引の処理後決済額が3,000円－1,000円＝2,000円であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1
判定根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md 実行手順 / 通販受注管理 / パターン8 / 経路1
比較規則: SPLINKSの同一取引IDで処理前決済額3,000円、依頼額1,000円、処理後決済額2,000円を対比する。"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-006	-	業務データ差分	P1	正常系 DP-N002: 通販チームからラインワークスで返金依頼（	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: 通販チームからラインワークスで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=通販チームからラインワークスで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
入力=受注番号=ST-ORDER-TSUHAN-008-R01-DP-N002 / 依頼元=通販チーム / 依頼チャネル=ラインワークス / 取引番号=同じ検証用決済 / 減額額=1,000円"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N002
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N002 / 依頼元=通販チーム / 依頼チャネル=ラインワークス / 取引番号=同じ検証用決済 / 減額額=1,000円
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 正常系#1: 店舗チームが「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N002 / 依頼元=通販チーム / 依頼チャネル=ラインワークス / 取引番号=同じ検証用決済 / 減額額=1,000円（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 正常系#2: 通販チームが「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
   対象: 返金対象金額=1,000円
5. 正常系#3: 通販チームが「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を実施する
   対象: 返金対象金額=1,000円
【操作後確認】
6. 最終業務状態「依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。	"確認場所: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1
差分判定根拠: 通販チームからラインワークスで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-007	-	業務データ差分	P1	正常系 DP-N003: TC東京の通販受注担当からGメールで返金依頼（	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N003
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: TC東京の通販受注担当からGメールで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）"	"データパターンID=DP-N003
種別=正常系 業務データ差分
目的=TC東京の通販受注担当からGメールで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
入力=受注番号=ST-ORDER-TSUHAN-008-R01-DP-N003 / 依頼元=TC東京の通販受注担当 / 依頼チャネル=Gメール / 取引番号=同じ検証用決済 / 減額額=1,000円"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N003
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N003 / 依頼元=TC東京の通販受注担当 / 依頼チャネル=Gメール / 取引番号=同じ検証用決済 / 減額額=1,000円
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 正常系#1: 店舗チームが「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N003 / 依頼元=TC東京の通販受注担当 / 依頼チャネル=Gメール / 取引番号=同じ検証用決済 / 減額額=1,000円（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 正常系#2: 通販チームが「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
   対象: 返金対象金額=1,000円
5. 正常系#3: 通販チームが「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を実施する
   対象: 返金対象金額=1,000円
【操作後確認】
6. 最終業務状態「依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。	"確認場所: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1
差分判定根拠: TC東京の通販受注担当からGメールで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
通販受注管理 — SPLINKS返金処理（減額完了・依頼者へ報告）	STI-TSUHAN-SPLINKS-011-008	-	業務データ差分	P1	正常系 DP-N004: 店舗大会担当から依頼フォームで返金依頼（	"元シナリオ: SCN-TSUHAN-SPLINKS返金処-011 SPLINKS返金処理（減額完了・依頼者へ報告）
業務: 通販受注管理
経路ID: R01
経路種別: 正常代表
業務経路条件: SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）
最終業務状態: 依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、SPLINKS、メール、海外発送管理アプリ
データパターンID: DP-N004
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-tsuhan-008-r01 / 会員番号=ST-MEMBER-TSUHAN-008-R01 / 商品コード=ST-CARD-TSUHAN-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-ORDER-TSUHAN-008-R01 / 決済状態=売上確定済み / 受注ステータス=対応中 / 返金対象金額=1,000円 / 配送方法=宅配便 / 決済金額=3,000円 / SPLINKS減額結果=成功 / 減額後金額=2,000円 / 依頼元部署=テスト店舗大会担当
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
- 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
- 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: 店舗大会担当から依頼フォームで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）"	"データパターンID=DP-N004
種別=正常系 業務データ差分
目的=店舗大会担当から依頼フォームで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
入力=受注番号=ST-ORDER-TSUHAN-008-R01-DP-N004 / 依頼元=店舗大会担当 / 依頼チャネル=依頼フォーム / 取引番号=同じ検証用決済 / 減額額=1,000円"	"担当者: 通販チーム
【準備確認】
差分実行ID: DP-N004
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/tsuhan-splinks-011-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-TSUHAN-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-TSUHAN-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-TSUHAN-008-R01 に対応付ける
10. 受注準備: curl -sS -b /tmp/tsuhan-splinks-011-fixture.cookie -X POST http://localhost:8080/fixture/order/generate を実行し、応答のorderNoを論理ID ST-ORDER-TSUHAN-008-R01 に対応付ける
11. 業務環境: EC-CUBE、SPLINKS、メール、海外発送管理アプリ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-tsuhan-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「SPLINKS減額結果=成功（原典本文 16_通販受注管理.md R337–349「減額が対応できない場合は報告のみでその後の返金処理は各部署の対応に委譲」）」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N004 / 依頼元=店舗大会担当 / 依頼チャネル=依頼フォーム / 取引番号=同じ検証用決済 / 減額額=1,000円
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 正常系#1: 店舗チームが「SPLINKS返金依頼として、顧客対応で決済の減額か請求のキャンセルが必要な要項が発生したため 通販チームに対応依頼 通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム から対応依頼を行う（TC東京も大会は依頼フォーム） ※対応範囲はwebサイトからの受注（通販・TC東京）、各店舗の大会予約分」を実施する
   対象: 受注番号=ST-ORDER-TSUHAN-008-R01-DP-N004 / 依頼元=店舗大会担当 / 依頼チャネル=依頼フォーム / 取引番号=同じ検証用決済 / 減額額=1,000円（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 正常系#2: 通販チームが「SPLINKS返金対応として、依頼を確認した通販社員が依頼内容に不備がないか確認のうえ SPLINKSで決済処理を実行」を実施する
   対象: 返金対象金額=1,000円
5. 正常系#3: 通販チームが「対応完了報告として、依頼者へ減額処理の対応完了と金額を報告する」を実施する
   対象: 返金対象金額=1,000円
【操作後確認】
6. 最終業務状態「依頼額1,000円の減額結果がSPLINKSの処理記録と一致し、依頼者への完了報告に同じ対象と金額が記載されたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。	"確認場所: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-ORDER-TSUHAN-008-R01
合格条件: 通販担当が指定チャネルの依頼を受領し、同じ取引番号・対象金額の処理結果を依頼者へ返せること。減額不能の場合は元の部署へ返金処理を引き継ぐ状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-TSUHAN-SPLINKS-011-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-TSUHAN-SPLINKS-011-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-TSUHAN-SPLINKS返金処-011_SPLINKS返金処理（減額完了・依頼者へ報告）.md / 通販受注管理 / パターン8 / 経路1
差分判定根拠: 店舗大会担当から依頼フォームで返金依頼（原典本文 16_通販受注管理.md R337「通販チームはラインワークス、TC東京はGメール、各店舗の大会は依頼フォーム」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
