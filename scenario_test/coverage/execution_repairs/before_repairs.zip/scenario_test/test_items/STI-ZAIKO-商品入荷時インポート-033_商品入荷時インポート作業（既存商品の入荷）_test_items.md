<!-- generated-by: hareruya-scenario-test-items -->
# 在庫管理 — 商品入荷時インポート作業（既存商品の入荷） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M04-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-10 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-21 | テスト項目化 | あり | 代替フロー |
| M04-22 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-24 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-25 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-26 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-28 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-29 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-32 | テスト項目化 | あり | 代替フロー |
| M04-33 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-34 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-001	-	業務経路	P1	代替系 経路全体 R08: 主要代替として「既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-21; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-21; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R08（主要代替）の条件「商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
3. 代替系#1: トレードチームが「2として、インポートファイル作成 インポート用CSVに手動で商品の原価と数量を入れてインポートCSVを作成する」を実施する
   対象: 移動数量=3
4. 代替系#2: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R08
5. 代替系#3: トレードチームが在庫管理 — 承認一覧で「登録者と異なる対象店舗の承認者が承認対象の数量・原価を確認して承認する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R08
【操作後確認】
6. 最終業務状態「既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:55 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。 / 照合キー: 商品コード・店舗・在庫区分・承認ID / 出典: scenario_test/markdown/12_在庫管理.md:56 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:5979#sheet-27 / 設計差・留意点: 入庫反映は承認工程で確認する。CSV登録のみを入庫完了とはしない。 / 照合キー: 承認ID・商品コード・店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:57 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:8142#sheet-45 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:8144#sheet-45 / 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-002	-	代替フロー	P1	代替系 #1: トレードチームが「2として、インポートファイル作成 インポート用CSVに手動で商品の原価と数量を入れてインポートCSVを作成する」を行い「商品コード・店舗・在庫区分・原価・数量が入荷の根拠と一致したCSVを取込担当へ渡せる状態である」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
2. 「2として、インポートファイル作成 インポート用CSVに手動で商品の原価と数量を入れてインポートCSVを作成する」を実施する
【操作後確認】
3. インポートファイル・インポート用CSVに手動で商品の原価と数量を入れてインポートCSV・商品で、商品コード・店舗・在庫区分・原価・数量が入荷の根拠と一致したCSVを取込担当へ渡せること。の実値と対象データ 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3 の対応を記録する"	商品コード・店舗・在庫区分・原価・数量が入荷の根拠と一致したCSVを取込担当へ渡せる状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/12_在庫管理.md:55 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: 商品コード・店舗・在庫区分・原価・数量が入荷の根拠と一致したCSVを取込担当へ渡せる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-003	M04-21	代替フロー	P1	代替系 #2: トレードチームが「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を行い「CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致される」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
- 必須入力欄: CSVファイル / 変更理由"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
14. 必須入力欄: CSVファイル / 変更理由
【操作】
1. 管理画面で 在庫管理 — 在庫変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
3. 「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
【操作後確認】
4. 在庫管理 — 在庫変更CSV登録 で対象キーと 処理後の画面表示 を記録する"	CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致されること。	"確認場所: 在庫管理 — 在庫変更CSV登録（M04-21） / 照合キー: 商品コード・店舗・在庫区分・承認ID / 出典: scenario_test/markdown/12_在庫管理.md:56 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:5979#sheet-27 / 設計差・留意点: 入庫反映は承認工程で確認する。CSV登録のみを入庫完了とはしない。
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-004	M04-32	代替フロー	P1	代替系 #3: トレードチームが「登録者と異なる対象店舗の承認者が承認対象の数量・原価を確認して承認する」を行い「入庫の承認対象が承認済みとなり、対象在庫の数量と総原価が承認対象の増減に対応して更新される」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-32_admin_stock_stock_approval_list.md（在庫管理 — 承認一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-32_admin_stock_stock_approval_list.md（在庫管理 — 承認一覧）
【操作】
1. 管理画面で 在庫管理 — 承認一覧 を開く
2. 対象データ: 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
3. 「登録者と異なる対象店舗の承認者が承認対象の数量・原価を確認して承認する」を実施する
【操作後確認】
4. 在庫管理 — 承認一覧 で対象キーと 保存しました を記録する"	入庫の承認対象が承認済みとなり、対象在庫の数量と総原価が承認対象の増減に対応して更新されること。	"確認場所: 在庫管理 — 承認一覧（M04-32） / 照合キー: 承認ID・商品コード・店舗・在庫区分 / 出典: scenario_test/markdown/12_在庫管理.md:57 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:8142#sheet-45 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:8144#sheet-45
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: 入庫の承認対象が承認済みとなり、対象在庫の数量と総原価が承認対象の増減に対応して更新されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-32_admin_stock_stock_approval_list.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-005	M04-21	代替フロー	P1	代替系 A1 #1: トレードチームが「商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）」を行い「既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できる」を確認する	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: システム外（外部）（EC-CUBEの実行可否とは無関係）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
- 必須入力欄: CSVファイル / 変更理由"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
入力=商品コード=ST-STOCK-ZAIKO-001-R08-A1 / 入荷・加工区分=既存商品の入荷 / 処理数量=3"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: システム外（外部）（EC-CUBEの実行可否とは無関係）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
14. 必須入力欄: CSVファイル / 変更理由
【操作】
1. 管理画面で 在庫管理 — 在庫変更CSV登録 を開く
2. 対象データ: 商品コード=ST-STOCK-ZAIKO-001-R08-A1 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
3. 分岐条件「元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。」を成立させる
4. 「商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）」を実施する
【操作後確認】
5. 在庫管理 — 在庫変更CSV登録 で対象キーと 処理後の画面表示 を記録する"	既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。	"確認場所: 在庫管理 — 在庫変更CSV登録（M04-21） / 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映した
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-006	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #9 インポート用CSV	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M04-21; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-01 / 在庫管理 / パターン1 / 経路8 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-8/#sheet-9/#sheet-27
- 解除条件: #9 インポート用CSVの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 在庫検索から作成するCSVの図示はあるが、在庫情報CSV・カスタムCSV・在庫変更CSVのどの形式を使いどの加工を行うか一意に指定されていない。 必要な判断: 在庫担当が使用する出力形式と加工後の取込先を指定し、実ヘッダと店舗/在庫区分/商品コードの対応を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 在庫検索から作成するCSVの図示はあるが、在庫情報CSV・カスタムCSV・在庫変更CSVのどの形式を使いどの加工を行うか一意に指定されていない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
連鎖ID=DL-01
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-01: #9 インポート用CSVの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 在庫検索から作成するCSVの図示はあるが、在庫情報CSV・カスタムCSV・在庫変更CSVのどの形式を使いどの加工を行うか一意に指定されていない。 必要な判断: 在庫担当が使用する出力形式と加工後の取込先を指定し、実ヘッダと店舗/在庫区分/商品コードの対応を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #9 インポート用CSV
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8
判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-01 / 在庫管理 / パターン1 / 経路8 / 調査済出典: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-01 / scenario_test/markdown/12_在庫管理.md 本文・原典ノード/接続表 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html#sheet-8/#sheet-9/#sheet-27
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
在庫管理 — 商品入荷時インポート作業（既存商品の入荷）	STI-ZAIKO-033-007	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #13 在庫	"元シナリオ: SCN-ZAIKO-商品入荷時インポート-033 商品入荷時インポート作業（既存商品の入荷）
業務: 在庫管理
経路ID: R08
経路種別: 主要代替
業務経路条件: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）
最終業務状態: 既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 元商品の在庫と構成商品・数量を準備し、同じ分割/結合番号で登録時の出庫と承認後の入庫を照合する。既存入荷では実在の商品コードの開始在庫を記録する。
シードデータ: 担当者アカウント=st-user-zaiko-001-r08 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 移動元ロケーション=本店バックヤード / 移動先ロケーション=支店テスト棚 / 移動数量=3 / 在庫状態=移動可能 / 入荷・加工区分=既存商品の入荷 / 処理数量=3
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M04-21; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-02 / 在庫管理 / パターン1 / 経路8"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
連鎖ID=DL-02
照合キー=商品コード=ST-STOCK-ZAIKO-001-R08"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M04-21; 未実装指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/zaiko-033-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ZAIKO-001-R08 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/zaiko-033-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-STOCK-ZAIKO-001-R08"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-STOCK-ZAIKO-001-R08 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-zaiko-001-r08 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R08（主要代替）の条件「商品登録=既存（原典本文 12_在庫管理.md R168–189,図形#81–84「既存商品入荷の流れは新商品入荷の1-①-2以降と同様となる」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-zaiko-001-r08 / 商品コード=ST-STOCK-ZAIKO-001-R08 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ZAIKO-001-R08 / 移動元ロケーション=本店バックヤード / 入荷・加工区分=既存商品の入荷 / 処理数量=3
3. 代替系#1: トレードチームが「2として、インポートファイル作成 インポート用CSVに手動で商品の原価と数量を入れてインポートCSVを作成する」を実施する
   対象: 移動数量=3
4. 代替系#2: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R08
5. 代替系#3: トレードチームが在庫管理 — 承認一覧で「登録者と異なる対象店舗の承認者が承認対象の数量・原価を確認して承認する」を実施する
   対象: 商品コード=ST-STOCK-ZAIKO-001-R08
【操作後確認】
6. 最終業務状態「既存商品を新規登録せず、原価と数量を入れた在庫CSVを取り込み、承認後の在庫へ反映したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#12 承認、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-STOCK-ZAIKO-001-R08。
【操作】
産出工程の完了直後に#13 在庫をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #12 承認 の成果物 #13 在庫 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-001-R08 に対応する作業元の確定値と一致する状態であること。	"確認場所: #13 在庫
照合キー: 商品コード=ST-STOCK-ZAIKO-001-R08
合格条件: 産出工程 #12 承認 の成果物 #13 在庫 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-STOCK-ZAIKO-001-R08 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ZAIKO-033-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ZAIKO-033-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md / 在庫管理 / パターン1 / 経路8
判定根拠: scenario_test/scenario/SCN-ZAIKO-商品入荷時インポート-033_商品入荷時インポート作業（既存商品の入荷）.md データ連鎖 DL-02 / 在庫管理 / パターン1 / 経路8
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
