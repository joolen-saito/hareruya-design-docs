<!-- generated-by: hareruya-scenario-test-items -->
# デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-006_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| A15-13 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-16 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-05 | テスト項目化 | あり | 代替フロー |
| M15-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A15-17 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M15-11 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M13-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）	STI-DECK-006-001	-	業務経路	P1	代替系 経路全体 R04: 主要代替として「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-006 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）
業務: デッキ登録
経路ID: R04
経路種別: 主要代替
業務経路条件: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r04 / 会員番号=ST-MEMBER-DECK-001-R04 / 商品コード=ST-CARD-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R04 / 大会ID=ST-EVENT-DECK-001-R04 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=登録済み / アーキタイプ=登録済み
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: ブロッカー=—（feasibility_by_scenario.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み
3. 代替系#1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
   対象: デッキID=ST-DECK-DECK-001-R04
4. 代替系#2: 顧客戦略チームがデッキ管理 — 新規登録・編集・削除・複製で「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
   対象: デッキID=ST-DECK-DECK-001-R04
【操作後確認】
5. 最終業務状態「不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 照合キー: デッキID / 出典: scenario_test/markdown/18_デッキ登録.md:31 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html:1452#sheet-5 / 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: デッキID=ST-DECK-DECK-001-R04
合格条件: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-006-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-006-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-006_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）.md / デッキ登録 / パターン1 / 経路4"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）	STI-DECK-006-002	-	代替フロー	P1	代替系 #1: 顧客戦略チームが「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を行い「イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-006 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）
業務: デッキ登録
経路ID: R04
経路種別: 主要代替
業務経路条件: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r04 / 会員番号=ST-MEMBER-DECK-001-R04 / 商品コード=ST-CARD-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R04 / 大会ID=ST-EVENT-DECK-001-R04 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=登録済み / アーキタイプ=登録済み
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: デッキ管理、デッキシステム、イベント管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: デッキ管理、デッキシステム、イベント管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み
2. 「デッキ内容取得として、イベント情報、デッキ情報を取得 「EVENT COVERAGE」」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、イベント情報、デッキ情報を取得 「EVENT COVERAGE」など？が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み の対応を記録する"	イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: デッキID=ST-DECK-DECK-001-R04
合格条件: イベント情報、デッキ情報を取得 「EVENT COVERAGE」が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-DECK-006-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-006-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-006_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）.md / デッキ登録 / パターン1 / 経路4"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）	STI-DECK-006-003	M15-05	代替フロー	P1	代替系 #2: 顧客戦略チームが「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を行い「登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致される」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-006 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）
業務: デッキ登録
経路ID: R04
経路種別: 主要代替
業務経路条件: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r04 / 会員番号=ST-MEMBER-DECK-001-R04 / 商品コード=ST-CARD-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R04 / 大会ID=ST-EVENT-DECK-001-R04 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=登録済み / アーキタイプ=登録済み
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
- 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
14. 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時
【操作】
1. 管理画面で デッキ管理 — 新規登録・編集・削除・複製 を開く
2. 対象データ: 担当者アカウント=st-user-deck-001-r04 / 商品コード=ST-CARD-DECK-001-R04 / デッキID=ST-DECK-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-DECK-001-R04 / デッキタグ=登録済み / アーキタイプ=登録済み
3. 「デッキ新規登録画面で大会・使用者・カード一覧を入力し新規登録する」を実施する
【操作後確認】
4. デッキ管理 — 新規登録・編集・削除・複製 で対象キーと 保存しました を記録する"	登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致されること。	"確認場所: デッキ管理 — 新規登録・編集・削除・複製（M15-05） / 照合キー: デッキID / 出典: scenario_test/markdown/18_デッキ登録.md:31 / excel_to_html/output/0212_基本設計仕様書(デッキ管理).html:1452#sheet-5
照合キー: デッキID=ST-DECK-DECK-001-R04
合格条件: 登録したデッキが同じデッキIDで再表示され、カード名・枚数・大会・使用者が入力値と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-DECK-006-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-006-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-006_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）.md / デッキ登録 / パターン1 / 経路4"
デッキ登録 — 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）	STI-DECK-006-004	M15-05	代替フロー	P1	代替系 A1 #1: 顧客戦略チームが「デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を行い「デッキID=ST-DECK-DECK-001-R04 の処理結果が デッキ管理 — 新規登録・編集・削除・複製 に登録される」を確認する	"元シナリオ: SCN-DECK-新規デッキ登録時外部-006 新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）
業務: デッキ登録
経路ID: R04
経路種別: 主要代替
業務経路条件: デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
最終業務状態: 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いたことを確認できること。
主アクター: 顧客戦略チーム
関連システム: デッキ管理、デッキシステム、イベント管理
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。
シードデータ: 担当者アカウント=st-user-deck-001-r04 / 会員番号=ST-MEMBER-DECK-001-R04 / 商品コード=ST-CARD-DECK-001-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / デッキID=ST-DECK-DECK-001-R04 / 大会ID=ST-EVENT-DECK-001-R04 / デッキ公開状態=下書き / カード枚数=60枚 / デッキタグ=登録済み / アーキタイプ=登録済み
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: システム外（現場）（EC-CUBEの実行可否とは無関係）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
- 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）
入力=商品コード=ST-CARD-DECK-001-R04-A1 / デッキタグ=登録済み / アーキタイプ=登録済み"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: システム外（現場）（EC-CUBEの実行可否とは無関係）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/deck-006-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/deck-006-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-DECK-001-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/deck-006-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-DECK-001-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-DECK-001-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-deck-001-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md（デッキ管理 — 新規登録・編集・削除・複製）
14. 必須入力欄: デッキ種別（ラベルは翻訳キー経由の名称） / フォーマット / アーキタイプ / 公開状態 / イベント名称（JP）／（EN） / 大会開催日時
【操作】
1. 管理画面で デッキ管理 — 新規登録・編集・削除・複製 を開く
2. 対象データ: 商品コード=ST-CARD-DECK-001-R04-A1 / デッキタグ=登録済み / アーキタイプ=登録済み
3. 分岐条件「デッキ内容と指定のタグ・アーキタイプを用意する。登録済みの場合は実在IDを控え、未登録の場合は既存一覧にないテスト名称を使う。」を成立させる
4. 「デッキタグ=登録済み、アーキタイプ=登録済み（原典本文 18_デッキ登録.md R29–41「登録しようとしているデッキに該当するタグが無い場合、登録する」）」を実施する
【操作後確認】
5. デッキ管理 — 新規登録・編集・削除・複製 で対象キーと 保存しました を記録する"	デッキID=ST-DECK-DECK-001-R04 の処理結果が デッキ管理 — 新規登録・編集・削除・複製 に登録されること。	"確認場所: デッキ管理 — 新規登録・編集・削除・複製（M15-05） / 不足するタグとアーキタイプだけを登録し、同じデッキへ指定したタグ・アーキタイプが紐付いた
照合キー: デッキID=ST-DECK-DECK-001-R04
合格条件: デッキID=ST-DECK-DECK-001-R04 の処理結果が デッキ管理 — 新規登録・編集・削除・複製 に登録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-DECK-006-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-DECK-006-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m15-05_admin_deck_deck_edit.md
業務結果根拠: scenario_test/scenario/SCN-DECK-新規デッキ登録時外部-006_新規デッキ登録時（外部大会などで活躍したデッキを登録）（デッキタグ登録済み・アーキタイプ登録済み）.md / デッキ登録 / パターン1 / 経路4"
```
