<!-- generated-by: hareruya-scenario-test-items -->
# ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| F05-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F05-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F05-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F05-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F05-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F05-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M07-01 | テスト項目化 | あり | データ更新 |
| M07-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M07-03 | テスト項目化 | あり | 業務操作、外部連携、メール/通知、データ更新 |
| M07-04 | テスト項目化 | あり | メール/通知 |
| M07-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M07-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A07-07 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| O01-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 照合キー: ネット買取申込番号 / 出典: scenario_test/markdown/14_ネット買取.md:55 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:2618#sheet-17 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1858#sheet-11 / 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-002	-	データ更新	P1	正常系 #1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を行い「郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「買取カード受領として、郵送されてきたカードを受領」を実施する
【操作後確認】
3. カードで、郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-003	M07-03	業務操作	P1	正常系 #2: 顧客戦略チームが「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を行い「ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新される」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新されること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 照合キー: ネット買取申込番号 / 出典: scenario_test/markdown/14_ネット買取.md:55 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:2618#sheet-17 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1858#sheet-11
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-004	-	データ更新	P1	正常系 #3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を行い「「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
【操作後確認】
3. カード・商品で、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-005	-	外部連携	P1	正常系 #4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を行い「「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
【操作後確認】
3. MTGバイヤー・カード・商品で、「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-006	-	外部連携	P1	正常系 #5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を行い「「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
【操作後確認】
3. MTGバイヤーで、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-007	M07-03	外部連携	P1	正常系 #6: 顧客戦略チームが「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を行い「MTGバイヤーにて査定した査定金額が挿入されることを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	MTGバイヤーにて査定した査定金額が挿入されることを、金額・決済状態と処理履歴で確認できること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 金額・決済状態と処理履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: MTGバイヤーにて査定した査定金額が挿入されることを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-008	M07-04,M07-03	メール/通知	P1	正常系 #7: 顧客戦略チームが「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を行い「手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文
- この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
15. この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 通過する機能: M07-04 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
【操作後確認】
5. ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） で対象キーと 処理後の画面表示 を記録する"	手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: ネット買取管理 — 手動メール通知（M07-04,M07-03） / 送信されたメール/通知の内容と送信状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-009	-	データ更新	P1	正常系 #8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を行い「買取履歴で査定金額を確認し、売却しないを選択することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、買取履歴で査定金額を確認し、売却しないを選択することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	買取履歴で査定金額を確認し、売却しないを選択することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 買取履歴で査定金額を確認し、売却しないを選択することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-010	-	メール/通知	P1	正常系 #9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を行い「同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態である」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。に対する機能Noと操作手段を確定する
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。に対する機能Noと操作手段を確定する
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
【操作後確認】
3. 対象顧客への査定承諾メール・自動承諾メール・処理の存在を原典は記載するが専用メールで、同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態であること。	"確認場所: 照合キー: ネット買取申込番号・顧客メールアドレス / 出典: scenario_test/markdown/14_ネット買取.md:72 / excel_to_html/output/0305_基本設計仕様書(フロント_ネット買取).html:2582#sheet-11 / 設計差・留意点: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-011	-	メール/通知	P1	正常系 #10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を行い「査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
【操作後確認】
3. 査定承諾メールで、査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-012	M07-01,M07-03	データ更新	P1	正常系 #11: 顧客戦略チームが「承認状況確認として、承諾内容を確認する」を行い「承諾内容を確認することを、承認状態と操作履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）
- この工程で通過する機能: M07-01 ネット買取管理 — 買取検索一覧 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）
14. この工程で通過する機能: M07-01 ネット買取管理 — 買取検索一覧 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 通過する機能: M07-01 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「承認状況確認として、承諾内容を確認する」を実施する
【操作後確認】
5. ネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03） で対象キーと 処理後の画面表示 を記録する"	承諾内容を確認することを、承認状態と操作履歴で確認できること。	"確認場所: ネット買取管理 — 買取検索一覧（M07-01,M07-03） / 承認状態と操作履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 承諾内容を確認することを、承認状態と操作履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-012、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-013	-	照合	P1	正常系 #12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を行い「売却しない選択を確認し、着払いによる返送処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、売却しない選択を確認し、着払いによる返送処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	売却しない選択を確認し、着払いによる返送処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 売却しない選択を確認し、着払いによる返送処理を行うことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-014	-	データ更新	P1	正常系 #13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を行い「返送作業を行い、買取しないカードを顧客に戻すことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
【操作後確認】
3. カードで、返送作業を行い、買取しないカードを顧客に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	返送作業を行い、買取しないカードを顧客に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 返送作業を行い、買取しないカードを顧客に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-015	-	データ更新	P1	正常系 #14: お客様が「返送完了後として、買取しないカードを受領」を行い「買取しないカードを受領することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
2. 「返送完了後として、買取しないカードを受領」を実施する
【操作後確認】
3. カードで、買取しないカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い の対応を記録する"	買取しないカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 買取しないカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-016	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #29 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-01 / ネット買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
連鎖ID=DL-01
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#30 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01。
【操作】
産出工程の完了直後に#29 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #30 ネット買取 の成果物 #29 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #29 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 産出工程 #30 ネット買取 の成果物 #29 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-01 / ネット買取 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-017	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #37 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-02 / ネット買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
連鎖ID=DL-02
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#36 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01。
【操作】
産出工程の完了直後に#37 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #36 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #37 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 産出工程 #36 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-02 / ネット買取 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-018	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #37 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-03 / ネット買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
連鎖ID=DL-03
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#39 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01。
【操作】
産出工程の完了直後に#37 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #39 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #37 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 産出工程 #39 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-03 / ネット買取 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-019	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #38 査定確認メール	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-04 / ネット買取 / パターン2 / 経路1 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-12 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-13"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
連鎖ID=DL-04
照合キー=買取番号＋送信したメール原本のMessage-ID"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#39 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取番号＋送信したメール原本のMessage-ID。手動メール通知確認画面の買取番号・件名・本文と、買取詳細の依頼者メールアドレスを送信前に保存する。送信後のメール原本を買取番号と対応付け、To・件名・本文を比較する。メール本文に買取番号の記載を仮定しない。
【操作】
産出工程の完了直後に#38 査定確認メールをproducer原本として保存する。
産出原本から 買取番号・宛先メールアドレス・件名・本文 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #39 ネット買取 の成果物 #38 査定確認メール の買取番号・宛先メールアドレス・件名・本文が、照合キー 買取番号＋送信したメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。	"確認場所: #38 査定確認メール
照合キー: 買取番号＋送信したメール原本のMessage-ID
合格条件: 産出工程 #39 ネット買取 の成果物 #38 査定確認メール の買取番号・宛先メールアドレス・件名・本文が、照合キー 買取番号＋送信したメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-04 / ネット買取 / パターン2 / 経路1 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-12 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-13
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-020	-	データ連鎖	P1	正常系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #42 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-05 / ネット買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
連鎖ID=DL-05
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=3（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 正常系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
4. 正常系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
5. 正常系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
6. 正常系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 正常系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 正常系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーにて査定した査定金額が挿入される まとめて買い取りがある場合は、まとめて買い取りの欄に MTGバイヤーで読み取ったカード買取情報が表示される MTGBuyer査定完了にステータス変更を行う」を実施する
   対象: 査定金額=1,200円
9. 正常系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 正常系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却しないを選択する」を実施する
   対象: 査定金額=1,200円
11. 正常系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 正常系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 正常系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
14. 正常系#12: 顧客戦略チームが「売却するか判定として、売却しない選択を確認し、着払いによる返送処理を行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R01
15. 正常系#13: 顧客戦略チームが「返送作業として、返送作業を行い、買取しないカードを顧客に戻す」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
16. 正常系#14: お客様が「返送完了後として、買取しないカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
【操作後確認】
17. 最終業務状態「同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#41 買取履歴、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01。
【操作】
産出工程の完了直後に#42 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #41 買取履歴 の成果物 #42 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #42 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 産出工程 #41 買取履歴 の成果物 #42 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md データ連鎖 DL-05 / ネット買取 / パターン2 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）	STI-ONLINE-KAITORI-003-021	M07-04,M07-03	メール/通知	P1	正常系 工程#7 判定: 査定内容メール通知の宛先と対象案件	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-003 ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）
業務: ネット買取
経路ID: R01
経路種別: 正常代表
業務経路条件: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」）
最終業務状態: 同じネット買取申込のカードを着払いで返送し、顧客が返送カードを受領したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定回答=売却しない（原典本文 14_ネット買取.md R134–155,R159–189「売却しない場合は着払いによる返送処理を行う」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 同じ申込番号で査定済み・実在庫登録済みのカード3枚と査定結果1,200円を用意し、顧客が指定の回答を選択する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r01 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R01 / 振込先=テスト銀行 普通 1234567 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文
- この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
- 判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md 実行手順 / ネット買取 / パターン2 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
判定用具体値: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-003-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-003-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
15. この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r01 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R01 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R01 / 査定回答=売却しない / 査定金額=1,200円 / 返送方法=着払い
3. 通過する機能: M07-04 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
【操作後確認】
5. ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） で対象キーと 処理後の画面表示 を記録する
具体照合: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"	「査定内容メール通知」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。	"確認場所: ネット買取管理 — 手動メール通知（M07-04,M07-03） / 査定内容メール通知の受信原本・対象案件の通知履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R01
合格条件: 「査定内容メール通知」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-003-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-003-021、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md / ネット買取 / パターン2 / 経路1
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-003_ネット買取処理（カード受け取り後から振込までの業務）（売却拒否・着払い返送完了）.md 実行手順 / ネット買取 / パターン2 / 経路1
比較規則: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"
```
