<!-- generated-by: hareruya-scenario-test-items -->
# 価格管理 — セール管理（原典実線の代表経路） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M03-05 | テスト項目化 | あり | CSV/帳票 |
| M03-31 | テスト項目化 | あり | CSV/帳票 |
| M03-34 | テスト項目化 | あり | CSV/帳票、金額整合 |
| M09-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M16-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M16-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 正常系#1: 顧客戦略チームが「セール品選定依頼対応として、セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応する ※セール担当者がいて、ジャンル担当者に選んでもらい選定品の作成を行う」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
4. 正常系#2: 顧客戦略チームが商品管理 — セール用価格変更CSV出力で「作業用ファイル取得として、セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードする」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
5. 正常系#3: 顧客戦略チームがM03-31（セール用価格変更CSV登録）で「セール品リスト作成として、セール対象とする商品のリストを作成する この際に、セール商品用に変更するためのCSVを作成する ※週刊販売数が2桁いってないものなど 商品によって結構変えている スタンダートは１～２％くらいセールとしている 平均1割くらいの値引き」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
6. 正常系#4: 顧客戦略チームが管理画面_商品管理_割引率変更CSV登録で「セール品情報更新作業として、セール用価格変更CSVアップロード画面よりセール品の更新対応を行う ※セール品の取り下げを先に行い、作業確認後新セール品登録を行う 試験的に取り下げを火曜日を行っている、更新は水曜日」を実施する
   対象: 変更後価格=550円
7. 正常系#5: 顧客戦略チームが「セールバナー差し替え対応として、セールバナー差し替え作業を行う」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
8. 正常系#6: 顧客戦略チームが「各支店へのリスト共有として、メールにて、セール品の各支店にリストを共有」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
9. 正常系#7: 顧客戦略チームが「メール返信対応として、セール品設定依頼完了メールに返信して終了」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
【操作後確認】
10. 最終業務状態「セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 出力されたCSV/帳票の件数と内容 / 一覧・詳細に追加された対象データ / セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-002	-	メール/通知	P1	正常系 #1: 顧客戦略チームが「セール品選定依頼対応として、セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応する ※セール担当者がいて、ジャンル担当者に選んでもらい選定品の作成を行う」を行い「セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
2. 「セール品選定依頼対応として、セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応する ※セール担当者がいて、ジャンル担当者に選んでもらい選定品の作成を行う」を実施する
【操作後確認】
3. セール品選定依頼のメールで、セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応することを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01 の対応を記録する"	セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-003	M03-05	CSV/帳票	P1	正常系 #2: 顧客戦略チームが「作業用ファイル取得として、セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードする」を行い「セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-05_admin_product_product_sale_price_csv_export.md（商品管理 — セール用価格変更CSV出力）
- 必須入力欄: 商品一覧のチェックボックス"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-05_admin_product_product_sale_price_csv_export.md（商品管理 — セール用価格変更CSV出力）
14. 必須入力欄: 商品一覧のチェックボックス
【操作】
1. 管理画面で 商品管理 — セール用価格変更CSV出力 を開く
2. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 「作業用ファイル取得として、セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードする」を実施する
【操作後確認】
4. 商品管理 — セール用価格変更CSV出力 で対象キーと 処理後の画面表示 を記録する"	セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — セール用価格変更CSV出力（M03-05） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードすることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-05_admin_product_product_sale_price_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-004	M03-31	CSV/帳票	P1	正常系 #3: 顧客戦略チームが「セール品リスト作成として、セール対象とする商品のリストを作成する この際に、セール商品用に変更するためのCSVを作成する ※週刊販売数が2桁いってないものなど 商品によって結構変えている スタンダートは１～２％くらいセールとしている 平均1割くらいの値引き」を行い「セール対象とする商品のリストを作成することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-31_admin_product_product_sale_price_csv_import.md（M03-31（セール用価格変更CSV登録））"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘4件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-31_admin_product_product_sale_price_csv_import.md（M03-31（セール用価格変更CSV登録））
【操作】
1. 管理画面で M03-31（セール用価格変更CSV登録） を開く
2. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 「セール品リスト作成として、セール対象とする商品のリストを作成する この際に、セール商品用に変更するためのCSVを作成する ※週刊販売数が2桁いってないものなど 商品によって結構変えている スタンダートは１～２％くらいセールとしている 平均1割くらいの値引き」を実施する
【操作後確認】
4. M03-31（セール用価格変更CSV登録） で対象キーと 商品登録CSVファイルをアップロードしました。 を記録する"	セール対象とする商品のリストを作成することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: M03-31（セール用価格変更CSV登録）（M03-31） / 一覧・詳細に追加された対象データ
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール対象とする商品のリストを作成することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 商品登録CSVファイルをアップロードしました。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-31_admin_product_product_sale_price_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-005	M03-34	CSV/帳票	P1	正常系 #4: 顧客戦略チームが「セール品情報更新作業として、セール用価格変更CSVアップロード画面よりセール品の更新対応を行う ※セール品の取り下げを先に行い、作業確認後新セール品登録を行う 試験的に取り下げを火曜日を行っている、更新は水曜日」を行い「セール用価格変更CSVアップロード画面よりセール品の更新対応を行うことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md（m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録））
- 必須入力欄: CSVファイル選択"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md（m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録））
14. 必須入力欄: CSVファイル選択
【操作】
1. 管理画面で 管理画面_商品管理_割引率変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 「セール品情報更新作業として、セール用価格変更CSVアップロード画面よりセール品の更新対応を行う ※セール品の取り下げを先に行い、作業確認後新セール品登録を行う 試験的に取り下げを火曜日を行っている、更新は水曜日」を実施する
【操作後確認】
4. 管理画面_商品管理_割引率変更CSV登録 で対象キーと 処理後の画面表示 を記録する"	セール用価格変更CSVアップロード画面よりセール品の更新対応を行うことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録）（M03-34） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール用価格変更CSVアップロード画面よりセール品の更新対応を行うことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-006	-	データ更新	P1	正常系 #5: 顧客戦略チームが「セールバナー差し替え対応として、セールバナー差し替え作業を行う」を行い「セールバナー差し替え作業を行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
2. 「セールバナー差し替え対応として、セールバナー差し替え作業を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、セールバナー差し替え作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01 の対応を記録する"	セールバナー差し替え作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セールバナー差し替え作業を行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-007	-	メール/通知	P1	正常系 #6: 顧客戦略チームが「各支店へのリスト共有として、メールにて、セール品の各支店にリストを共有」を行い「メールにて、セール品の各支店にリストを共有が完了したことを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
2. 「各支店へのリスト共有として、メールにて、セール品の各支店にリストを共有」を実施する
【操作後確認】
3. 各支店へのリスト・セール品の各支店にリストで、メールにて、セール品の各支店にリストを共有が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01 の対応を記録する"	メールにて、セール品の各支店にリストを共有が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: メールにて、セール品の各支店にリストを共有が完了したことを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-007、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-008	-	メール/通知	P1	正常系 #7: 顧客戦略チームが「メール返信対応として、セール品設定依頼完了メールに返信して終了」を行い「セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、分析集計 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
2. 「メール返信対応として、セール品設定依頼完了メールに返信して終了」を実施する
【操作後確認】
3. セール品設定依頼完了メールで、セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。の実値と対象データ 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01 の対応を記録する"	セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-009	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #7 セール品対応	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-01 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
- 解除条件: #7 セール品対応の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
連鎖ID=DL-01
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-01: #7 セール品対応の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #7 セール品対応
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-01 / 価格管理 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-01 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-010	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #11 商品*1	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-02 / 価格管理 / パターン1 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
連鎖ID=DL-02
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「原典に記載された全工程を順に実施する。」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 正常系#1: 顧客戦略チームが「セール品選定依頼対応として、セール品選定依頼のメールを送付し、 セール前の土日 受け取った人がセール品担当が対応する ※セール担当者がいて、ジャンル担当者に選んでもらい選定品の作成を行う」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
4. 正常系#2: 顧客戦略チームが商品管理 — セール用価格変更CSV出力で「作業用ファイル取得として、セール品選定作業用のCSVファイルを 商品マスターからCSVファイルをダウンロードする」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
5. 正常系#3: 顧客戦略チームがM03-31（セール用価格変更CSV登録）で「セール品リスト作成として、セール対象とする商品のリストを作成する この際に、セール商品用に変更するためのCSVを作成する ※週刊販売数が2桁いってないものなど 商品によって結構変えている スタンダートは１～２％くらいセールとしている 平均1割くらいの値引き」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
6. 正常系#4: 顧客戦略チームが管理画面_商品管理_割引率変更CSV登録で「セール品情報更新作業として、セール用価格変更CSVアップロード画面よりセール品の更新対応を行う ※セール品の取り下げを先に行い、作業確認後新セール品登録を行う 試験的に取り下げを火曜日を行っている、更新は水曜日」を実施する
   対象: 変更後価格=550円
7. 正常系#5: 顧客戦略チームが「セールバナー差し替え対応として、セールバナー差し替え作業を行う」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
8. 正常系#6: 顧客戦略チームが「各支店へのリスト共有として、メールにて、セール品の各支店にリストを共有」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
9. 正常系#7: 顧客戦略チームが「メール返信対応として、セール品設定依頼完了メールに返信して終了」を実施する
   対象: 価格変更CSV=ST-PRICE-PRICE-001-R01.csv
【操作後確認】
10. 最終業務状態「セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#10 セール用価格変更CSVアップロード、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#11 商品*1をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #10 セール用価格変更CSVアップロード の成果物 #11 商品*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #11 商品*1
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #10 セール用価格変更CSVアップロード の成果物 #11 商品*1 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-02 / 価格管理 / パターン1 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-011	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #15 セール品対応	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M03-31; 未実装指摘あり=1; 実装違い指摘あり=1（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、分析集計 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-03 / 価格管理 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-03 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
- 解除条件: #15 セール品対応の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
連鎖ID=DL-03
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-03: #15 セール品対応の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #15 セール品対応
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1
判定根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-03 / 価格管理 / パターン1 / 経路1 / 調査済出典: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md データ連鎖 DL-03 / scenario_test/markdown/11_価格管理.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
価格管理 — セール管理（原典実線の代表経路）	STI-PRICE-001-012	M03-34	金額整合	P1	正常系 工程#4 判定: セール価格と基準価格の区別	"元シナリオ: SCN-PRICE-セール管理-001 セール管理（原典実線の代表経路）
業務: 価格管理
経路ID: R01
経路種別: 正常代表
業務経路条件: 原典に記載された全工程を順に実施する。
最終業務状態: セール品設定依頼完了メールに返信して終了することを、送信されたメール/通知の内容と送信状態で確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、分析集計
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 原典に記載された全工程を順に実施する。 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-price-001-r01 / 会員番号=ST-MEMBER-PRICE-001-R01 / 商品コード=ST-CARD-PRICE-001-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 対象商品コード=ST-CARD-PRICE-001-R01 / 変更前価格=500円 / 変更後価格=550円
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md（m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録））
- 必須入力欄: CSVファイル選択
- 判定用準備: 試験用具体値: 更新前はセールフラグ=0、基準価格=販売価格=1,000円。セール用価格変更CSVに当該商品ID・言語ID、販売価格800円、買取価格400円、セールフラグ1を設定する。
- 判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-44（セールフラグ0→1）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
判定用具体値: 試験用具体値: 更新前はセールフラグ=0、基準価格=販売価格=1,000円。セール用価格変更CSVに当該商品ID・言語ID、販売価格800円、買取価格400円、セールフラグ1を設定する。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 試験用具体値: 更新前はセールフラグ=0、基準価格=販売価格=1,000円。セール用価格変更CSVに当該商品ID・言語ID、販売価格800円、買取価格400円、セールフラグ1を設定する。
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/price-001-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/price-001-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRICE-001-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/price-001-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-PRICE-001-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-PRICE-001-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-price-001-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md（m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録））
14. 必須入力欄: CSVファイル選択
【操作】
1. 管理画面で 管理画面_商品管理_割引率変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-price-001-r01 / 商品コード=ST-CARD-PRICE-001-R01 / 価格変更CSV=ST-PRICE-PRICE-001-R01.csv / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-PRICE-001-R01
3. 「セール品情報更新作業として、セール用価格変更CSVアップロード画面よりセール品の更新対応を行う ※セール品の取り下げを先に行い、作業確認後新セール品登録を行う 試験的に取り下げを火曜日を行っている、更新は水曜日」を実施する
【操作後確認】
4. 管理画面_商品管理_割引率変更CSV登録 で対象キーと 処理後の画面表示 を記録する
具体照合: セール用価格変更CSVと商品規格詳細を商品ID・言語IDで対比し、販売価格800円への更新と基準価格1,000円の保持を確認する。"	対象の商品ID・言語IDで、セールフラグ=1、販売価格=800円、基準価格=1,000円の状態であること。	"確認場所: m03-34_admin_product_product_discount_csv_import（管理画面_商品管理_割引率変更CSV登録）（M03-34） / セール用価格変更CSV・商品規格詳細
照合キー: 商品コード=ST-CARD-PRICE-001-R01
合格条件: 対象の商品ID・言語IDで、セールフラグ=1、販売価格=800円、基準価格=1,000円の状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRICE-001-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRICE-001-012、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-34_admin_product_product_discount_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRICE-セール管理-001_セール管理（原典実線の代表経路）.md / 価格管理 / パターン1 / 経路1
判定根拠: excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-44（セールフラグ0→1）
比較規則: セール用価格変更CSVと商品規格詳細を商品ID・言語IDで対比し、販売価格800円への更新と基準価格1,000円の保持を確認する。"
```
