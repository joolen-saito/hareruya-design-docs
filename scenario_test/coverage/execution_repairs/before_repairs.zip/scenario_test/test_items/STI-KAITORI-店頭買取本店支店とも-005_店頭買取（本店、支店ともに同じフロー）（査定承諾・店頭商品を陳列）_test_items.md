<!-- generated-by: hareruya-scenario-test-items -->
# 店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| F08-01 | テスト項目化 | あり | 代替フロー |
| F08-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| F08-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B06-01 | テスト項目化 | あり | 代替フロー |
| M04-09 | テスト項目化 | あり | 代替フロー |
| M06-03 | テスト項目化 | あり | 代替フロー |
| M06-12 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-001	-	業務経路	P1	代替系 経路全体 R05: 主要代替として「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。	"確認場所: 画面表示・処理ステータス・処理履歴 / 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-002	F08-01	代替フロー	P1	代替系 #1: お客様が「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を行い「会員の場合はログイン、会員でない場合は会員情報を入力してもらうことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/f08-01_front_store_purchase_otc_buy_entry_login.md（店頭買取 — 査定申込前ログイン）
- 必須入力欄: メールアドレス / パスワード"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: お客様
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
11. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/f08-01_front_store_purchase_otc_buy_entry_login.md（店頭買取 — 査定申込前ログイン）
14. 必須入力欄: メールアドレス / パスワード
【操作】
1. フロント画面で 店頭買取 — 査定申込前ログイン を開く
2. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
【操作後確認】
4. 店頭買取 — 査定申込前ログイン で対象キーと 処理後の画面表示 を記録する"	会員の場合はログイン、会員でない場合は会員情報を入力してもらうことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 店頭買取 — 査定申込前ログイン（F08-01） / 画面表示・処理ステータス・処理履歴
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 会員の場合はログイン、会員でない場合は会員情報を入力してもらうことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f08-01_front_store_purchase_otc_buy_entry_login.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-003	-	代替フロー	P1	代替系 #2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を行い「買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新されることを、更新後の値と更新履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新されることを、更新後の値と更新履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新されることを、更新後の値と更新履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新されることを、更新後の値と更新履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-004	-	代替フロー	P1	代替系 #3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を行い「査定した結果を印刷することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、査定した結果を印刷することを、出力されたCSV/帳票の件数と内容で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	査定した結果を印刷することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 査定した結果を印刷することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-005	-	代替フロー	P1	代替系 #4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を行い「受付時にコピーした身分証で本人確認を実施することを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、受付時にコピーした身分証で本人確認を実施することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	受付時にコピーした身分証で本人確認を実施することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 受付時にコピーした身分証で本人確認を実施することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-006	-	代替フロー	P1	代替系 #5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を行い「査定結果を顧客と確認し、全品の買取承諾を得ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、査定結果を顧客と確認し、全品の買取承諾を得ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	査定結果を顧客と確認し、全品の買取承諾を得ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 査定結果を顧客と確認し、全品の買取承諾を得ることを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-007	M06-03	代替フロー	P1	代替系 #6: 買取担当者→経理担当者が「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を行い「経理権限で払い出しを確定できる。全商品が登録済みなら入庫待ち、未登録の個別入力商品があれば未登録在庫ありになる。払い出しを重複させない状態である」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m06-03_admin_store_purchase_purchase_store_otc_buy_info_edit.md（店頭買取管理 — 買取詳細（買取情報の確認と保存））"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 買取担当者→経理担当者
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m06-03_admin_store_purchase_purchase_store_otc_buy_info_edit.md（店頭買取管理 — 買取詳細（買取情報の確認と保存））
【操作】
1. 管理画面で 店頭買取管理 — 買取詳細（買取情報の確認と保存） を開く
2. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
【操作後確認】
4. 店頭買取管理 — 買取詳細（買取情報の確認と保存） で対象キーと 処理後の画面表示 を記録する"	経理権限で払い出しを確定できる。全商品が登録済みなら入庫待ち、未登録の個別入力商品があれば未登録在庫ありになる。払い出しを重複させない状態であること。	"確認場所: 店頭買取管理 — 買取詳細（買取情報の確認と保存）（M06-03） / 照合キー: 査定ID・顧客ID・振込依頼ID / 出典: scenario_test/markdown/06_店頭買取.md:38 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1668#sheet-10 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1669#sheet-10 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1670#sheet-10 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1723#sheet-10 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:2977#sheet-18
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 経理権限で払い出しを確定できる。全商品が登録済みなら入庫待ち、未登録の個別入力商品があれば未登録在庫ありになる。払い出しを重複させない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m06-03_admin_store_purchase_purchase_store_otc_buy_info_edit.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-008	-	代替フロー	P1	代替系 #7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を行い「買取一覧のステータスを「買取成立」に更新されることを、更新後の値と更新履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、買取一覧のステータスを「買取成立」に更新されることを、更新後の値と更新履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	買取一覧のステータスを「買取成立」に更新されることを、更新後の値と更新履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 買取一覧のステータスを「買取成立」に更新されることを、更新後の値と更新履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-009	B06-01	代替フロー	P1	代替系 #8: 店舗チームが「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を行い「査定IDの商品コード・実在庫数量が同じ店舗のEC在庫へ加算され、買取が入庫済みとなる状態である」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 実行権限: ec-cubeコンテナ内で対象バッチを起動でき、開始・終了ログを取得できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/b06-01_batch_purchase_purchase_auto_stock.md（B06-01（買取自動入庫バッチ））"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 実行権限: ec-cubeコンテナ内で対象バッチを起動でき、開始・終了ログを取得できる
11. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/b06-01_batch_purchase_purchase_auto_stock.md（B06-01（買取自動入庫バッチ））
【操作】
1. 実行開始時刻を記録し、`docker compose exec ec-cube bin/console eccube:buy-order:auto-stock` を実行する
2. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
【操作後確認】
4. B06-01（買取自動入庫バッチ） で対象キーと 処理後の画面表示 を記録する"	査定IDの商品コード・実在庫数量が同じ店舗のEC在庫へ加算され、買取が入庫済みとなる状態であること。	"確認場所: B06-01（買取自動入庫バッチ）（B06-01） / 照合キー: 査定ID・商品コード・店舗 / 出典: scenario_test/markdown/06_店頭買取.md:48 / excel_to_html/output/0406_基本設計仕様書(バッチ_店頭買取管理) .html:1024#sheet-3 / excel_to_html/output/0406_基本設計仕様書(バッチ_店頭買取管理) .html:1029#sheet-3
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 査定IDの商品コード・実在庫数量が同じ店舗のEC在庫へ加算され、買取が入庫済みとなる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/b06-01_batch_purchase_purchase_auto_stock.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-010	M06-12	代替フロー	P1	代替系 #9: 店舗チームが「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を行い「同じ査定の商品明細CSVが出力され、商品コードと数量が一致する。日英NM以外の価格250円は原典の「250円以下」と「250円以上」が重複するためこの境界の仕分けは保留する 実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち状態である」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m06-12_admin_store_purchase_purchase_store_product_list_csv_export.md（M06-12（買取商品一覧CSV））
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m06-12_admin_store_purchase_purchase_store_product_list_csv_export.md（M06-12（買取商品一覧CSV））
【操作】
1. 管理画面で M06-12（買取商品一覧CSV） を開く
2. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
【操作後確認】
4. M06-12（買取商品一覧CSV） で対象キーと 処理後の画面表示 を記録する"	同じ査定の商品明細CSVが出力され、商品コードと数量が一致する。日英NM以外の価格250円は原典の「250円以下」と「250円以上」が重複するためこの境界の仕分けは保留する 実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち状態であること。	"確認場所: M06-12（買取商品一覧CSV）（M06-12） / 照合キー: 査定ID・商品コード・言語・状態 / 出典: scenario_test/markdown/06_店頭買取.md:51 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1249#sheet-4 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1251#sheet-4 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1367#sheet-6 / excel_to_html/output/0205_基本設計仕様書(店頭買取管理).html:1372#sheet-6 / 設計差・留意点: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 同じ査定の商品明細CSVが出力され、商品コードと数量が一致する。日英NM以外の価格250円は原典の「250円以下」と「250円以上」が重複するためこの境界の仕分けは保留する 実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-010、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m06-12_admin_store_purchase_purchase_store_product_list_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-011	M04-09	代替フロー	P1	代替系 #10: 店舗チームが「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を行い「買取受付番号=ST-BUY-KAITORI-001-R05 の処理結果が 在庫管理 — 在庫移動・振替登録/編集 に登録される」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md（在庫管理 — 在庫移動・振替登録/編集）
【操作】
1. 管理画面で 在庫管理 — 在庫移動・振替登録/編集 を開く
2. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
【操作後確認】
4. 在庫管理 — 在庫移動・振替登録/編集 で対象キーと 保存しました を記録する"	買取受付番号=ST-BUY-KAITORI-001-R05 の処理結果が 在庫管理 — 在庫移動・振替登録/編集 に登録されること。	"確認場所: 在庫管理 — 在庫移動・振替登録/編集（M04-09） / 照合キー: 商品コード・店舗・在庫区分・移動ID / 出典: scenario_test/markdown/06_店頭買取.md:59 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2669#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2670#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2750#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2861#sheet-14 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:2906#sheet-14
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 買取受付番号=ST-BUY-KAITORI-001-R05 の処理結果が 在庫管理 — 在庫移動・振替登録/編集 に登録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-011、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-09_admin_stock_stock_move_transfer_register_edit.md
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-012	-	代替フロー	P1	代替系 #11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を行い「商品コードを読み取れるバーコードが該当商品へ付けられ、棚・ショーケースの現物と一致される」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
【操作後確認】
3. 商品・バーコードで、商品コードを読み取れるバーコードが該当商品へ付けられ、棚・ショーケースの現物と一致すること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	商品コードを読み取れるバーコードが該当商品へ付けられ、棚・ショーケースの現物と一致されること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/06_店頭買取.md:60 / 設計差・留意点: 業務フロー本文が現物・帳票・外部ツールでの作業と観測先を明示。EC-CUBE機能Noを付与しない。
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 商品コードを読み取れるバーコードが該当商品へ付けられ、棚・ショーケースの現物と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-013	-	代替フロー	P1	代替系 #12: 店舗チームが「店頭陳列を行う」を行い「店頭陳列が完了したことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 「店頭陳列を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、店頭陳列が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	店頭陳列が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 店頭陳列が完了したことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-014	-	代替フロー	P1	代替系 A1 #1: お客様が「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を行い「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できる」を確認する	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
入力=商品コード=ST-CARD-KAITORI-001-R05-A1 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 商品コード=ST-CARD-KAITORI-001-R05-A1 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
2. 分岐条件「査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。」を成立させる
3. 「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を実施する
【操作後確認】
4. 商品で、同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。の実値と対象データ 商品コード=ST-CARD-KAITORI-001-R05-A1 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込 の対応を記録する"	同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。	"確認場所: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了した
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-015	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #2 買取*1	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-01 / 店頭買取 / パターン1 / 経路5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-01
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#1 査定申込み開始、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05。
【操作】
産出工程の完了直後に#2 買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #1 査定申込み開始 の成果物 #2 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。	"確認場所: #2 買取*1
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 産出工程 #1 査定申込み開始 の成果物 #2 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-01 / 店頭買取 / パターン1 / 経路5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-016	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #2 買取*1	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-02 / 店頭買取 / パターン1 / 経路5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-02
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#3 MTGバイヤー査定、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05。
【操作】
産出工程の完了直後に#2 買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #3 MTGバイヤー査定 の成果物 #2 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。	"確認場所: #2 買取*1
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 産出工程 #3 MTGバイヤー査定 の成果物 #2 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-02 / 店頭買取 / パターン1 / 経路5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-017	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #6 査定表	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-03 / 店頭買取 / パターン1 / 経路5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-03
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#5 MTGバイヤー査定表印刷、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05。
【操作】
産出工程の完了直後に#6 査定表をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #5 MTGバイヤー査定表印刷 の成果物 #6 査定表 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。	"確認場所: #6 査定表
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 産出工程 #5 MTGバイヤー査定表印刷 の成果物 #6 査定表 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-017、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-03 / 店頭買取 / パターン1 / 経路5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-018	-	データ連鎖	P1	代替系 DL-04: 産出値と消費値の照合 — #18 出金	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 産出値と消費値の照合
- 原典判定: 連鎖あり（HTML設計書由来）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-04 / 店頭買取 / パターン1 / 経路5 / excel_to_html/output/0506_基本設計仕様書(API_店頭買取管理).html#sheet-5 / excel_to_html/output/0601_基本設計仕様書(その他_MTGBuyer).html#sheet-3"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-04
照合キー=買取ID＋端末取引ID（smaregi_transaction_id）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#17 【経理】振込実行、消費=店頭買取情報更新API→EC-CUBE連携（HTML設計書由来）。
照合キー=買取ID＋端末取引ID（smaregi_transaction_id）。スマレジの取引区分=出金の実取引IDを記録する。MTGBuyerへの端末取引ID入力と、PUT /api/admin/otcBuyOrder/{_otcBuyOrderId}.json のsmaregi_transaction_id、EC-CUBE買取詳細の出金コードを同一買取IDで対比する。
【操作】
産出工程の完了直後に#18 出金をproducer原本として保存する。
店頭買取情報更新API→EC-CUBE連携（HTML設計書由来）で実際に参照した原本をconsumer原本として保存し、買取ID・端末取引ID・出金コードをproducer原本と同じ照合キーで比較する。工程間で変更した列は原典に明記された変換だけを許容し、その計算過程を別記する。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	#17 【経理】振込実行で産出した#18 出金の買取ID・端末取引ID・出金コードが、店頭買取情報更新API→EC-CUBE連携（HTML設計書由来）が参照した値と照合キー 買取ID＋端末取引ID（smaregi_transaction_id） で一致する状態であること。	"確認場所: #18 出金
照合キー: 買取ID＋端末取引ID（smaregi_transaction_id）
合格条件: #17 【経理】振込実行で産出した#18 出金の買取ID・端末取引ID・出金コードが、店頭買取情報更新API→EC-CUBE連携（HTML設計書由来）が参照した値と照合キー 買取ID＋端末取引ID（smaregi_transaction_id） で一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-018、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-04 / 店頭買取 / パターン1 / 経路5 / excel_to_html/output/0506_基本設計仕様書(API_店頭買取管理).html#sheet-5 / excel_to_html/output/0601_基本設計仕様書(その他_MTGBuyer).html#sheet-3
連鎖判定: 連鎖あり（HTML設計書由来）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-019	-	データ連鎖	P1	代替系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #24 買取*1	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-05 / 店頭買取 / パターン1 / 経路5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-05
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#23 MTGバイヤー買取成立、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取受付番号=ST-BUY-KAITORI-001-R05。
【操作】
産出工程の完了直後に#24 買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #23 MTGバイヤー買取成立 の成果物 #24 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。	"確認場所: #24 買取*1
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 産出工程 #23 MTGバイヤー買取成立 の成果物 #24 買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 買取受付番号=ST-BUY-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-019、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-05 / 店頭買取 / パターン1 / 経路5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-020	-	データ連鎖	P1	代替系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #36 在庫	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-06 / 店頭買取 / パターン1 / 経路5"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-06
照合キー=商品コード=ST-CARD-KAITORI-001-R05"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-06。以下の#番号は原典ノード番号。産出=#35 在庫移動・振替、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-CARD-KAITORI-001-R05。
【操作】
産出工程の完了直後に#36 在庫をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #35 在庫移動・振替 の成果物 #36 在庫 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-CARD-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。	"確認場所: #36 在庫
照合キー: 商品コード=ST-CARD-KAITORI-001-R05
合格条件: 産出工程 #35 在庫移動・振替 の成果物 #36 在庫 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-CARD-KAITORI-001-R05 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-06 / 店頭買取 / パターン1 / 経路5
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-021	-	データ連鎖	P1	代替系 DL-07: 終端の成果物確認（後続工程への受け渡しは未判定） — #39 バーコード作成マクロ	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 査定前の買取受付と身分証の控え、指定の査定回答・商品登録状態・支払条件を用意する。自動入庫は業務時計を15時に進めて実施結果を確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-07
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-07 / 店頭買取 / パターン1 / 経路5 / 調査済出典: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-07 / scenario_test/markdown/06_店頭買取.md 本文・原典ノード/接続表
- 解除条件: #39 バーコード作成マクロの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-kaitori-001-r05 / 商品コード=ST-CARD-KAITORI-001-R05 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
連鎖ID=DL-07
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-07: #39 バーコード作成マクロの照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 未確定理由: 原典は外部作業ファイルの作成・利用を記載するが、実ファイルの列定義・一意キー・変換規則を含まない。リポジトリ内に同名の実テンプレートはない。 必要な判断: 業務担当が実テンプレートと入出力サンプルを提示し、商品/店舗等の照合列、集計・ソート・価格/数量変換規則、ファイル版を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #39 バーコード作成マクロ
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-021、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
判定根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-07 / 店頭買取 / パターン1 / 経路5 / 調査済出典: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md データ連鎖 DL-07 / scenario_test/markdown/06_店頭買取.md 本文・原典ノード/接続表
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-022	-	業務データ差分	P1	代替系 DP-N002: 会員受付（	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: 会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）
入力=商品コード=ST-CARD-KAITORI-001-R05-DP-N002 / 会員状態=登録済み / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚"	"担当者: 店舗チーム
【準備確認】
差分実行ID: DP-N002
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-KAITORI-001-R05-DP-N002 / 会員状態=登録済み / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05-DP-N002 / 会員状態=登録済み / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれる状態であること。	"確認場所: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-022/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-022、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
差分判定根拠: 会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-023	-	業務データ差分	P1	代替系 DP-N003: 非会員受付（	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N003
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: 非会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）"	"データパターンID=DP-N003
種別=正常系 業務データ差分
目的=非会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）
入力=商品コード=ST-CARD-KAITORI-001-R05-DP-N003 / 会員状態=未登録 / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚"	"担当者: 店舗チーム
【準備確認】
差分実行ID: DP-N003
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-KAITORI-001-R05-DP-N003 / 会員状態=未登録 / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05-DP-N003 / 会員状態=未登録 / 身分証=同じ氏名のテスト身分証 / 買取カード=3枚（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれる状態であること。	"確認場所: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 登録済み顧客はログイン、未登録顧客は会員情報入力により買取受付が作成され、同じ顧客情報・カード3枚が査定前の受付へ引き継がれる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-023/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-023、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
差分判定根拠: 非会員受付（原典本文 06_店頭買取.md R22「会員の場合はログイン、会員でない場合は会員情報を入力してもらう」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-024	-	業務データ差分	P1	代替系 DP-N004: プレイド200円の陳列先（	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N004
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: プレイド200円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）"	"データパターンID=DP-N004
種別=正常系 業務データ差分
目的=プレイド200円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）
入力=商品コード=ST-CARD-KAITORI-001-R05-DP-N004 / 状態=SP / 買取価格=200円 / 数量=3 / 陳列先=ストレージ"	"担当者: 店舗チーム
【準備確認】
差分実行ID: DP-N004
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-KAITORI-001-R05-DP-N004 / 状態=SP / 買取価格=200円 / 数量=3 / 陳列先=ストレージ
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05-DP-N004 / 状態=SP / 買取価格=200円 / 数量=3 / 陳列先=ストレージ（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#9
差分固有判定: 同じ商品コード3枚の陳列先がストレージになり、元の買取記録と現物を照合できること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ商品コード3枚の陳列先がストレージになり、元の買取記録と現物を照合できること。	"確認場所: 同じ商品コード3枚の陳列先がストレージになり、元の買取記録と現物を照合できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 同じ商品コード3枚の陳列先がストレージになり、元の買取記録と現物を照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-024/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-024、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
差分判定根拠: プレイド200円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
店頭買取 — 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）	STI-KAITORI-005-025	-	業務データ差分	P1	代替系 DP-N005: プレイド500円の陳列先（	"元シナリオ: SCN-KAITORI-店頭買取本店支店とも-005 店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）
業務: 店頭買取
経路ID: R05
経路種別: 主要代替
業務経路条件: 査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）
最終業務状態: 同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、MTGバイヤー、スマレジ
データパターンID: DP-N005
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-kaitori-001-r05 / 会員番号=ST-MEMBER-KAITORI-001-R05 / 商品コード=ST-CARD-KAITORI-001-R05 / 数量=3 / 店舗=晴れる屋テスト店舗 / 買取受付番号=ST-BUY-KAITORI-001-R05 / 査定対象商品=ST-CARD-KAITORI-001-R05 / 査定金額=1,200円 / 買取ステータス=査定中 / 査定回答=全品承諾 / 商品状態=日本語SP / 買取価格=500円 / 支払方法=経理振込
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: プレイド500円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）"	"データパターンID=DP-N005
種別=正常系 業務データ差分
目的=プレイド500円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）
入力=商品コード=ST-CARD-KAITORI-001-R05-DP-N005 / 状態=SP / 買取価格=500円 / 数量=3 / 陳列先=ショーケース"	"担当者: 店舗チーム
【準備確認】
差分実行ID: DP-N005
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=B06-01, M06-12, M04-09; 判定不能=1; 未実装指摘あり=2（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/kaitori-005-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-KAITORI-001-R05 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/kaitori-005-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-KAITORI-001-R05"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-KAITORI-001-R05 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 業務環境: EC-CUBE、MTGバイヤー、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
13. 担当者識別子: st-user-kaitori-001-r05 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
14. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R05（主要代替）の条件「査定承諾、店頭商品に該当（原典本文 06_店頭買取.md R46–115,図形#8/#9/#11「査定結果をお客様と確認する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-CARD-KAITORI-001-R05-DP-N005 / 状態=SP / 買取価格=500円 / 数量=3 / 陳列先=ショーケース
3. 代替系#1: お客様が店頭買取 — 査定申込前ログインで「受付として、会員の場合はログイン、会員でない場合は会員情報を入力してもらう 買取一覧にステータス「査定前」のデータが作成される 査定後の当人チェックのために、身分証をコピーする 買取品を預かる https://www.hareruyamtg.com/ja/otcbuy/tc/entry」を実施する
   対象: 査定金額=1,200円
4. 代替系#2: 店舗チームが「査定として、買取アプリを使って査定を開始 買取一覧のステータスが「査定中」に更新される」を実施する
   対象: 査定金額=1,200円
5. 代替系#3: 店舗チームが「査定表印刷として、査定した結果を印刷する ダブルチェックの実施」を実施する
   対象: 査定金額=1,200円
6. 代替系#4: 店舗チームが「本人確認として、受付時にコピーした身分証で本人確認を実施する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
7. 代替系#5: 店舗チームが「査定結果確認として、査定結果を顧客と確認し、全品の買取承諾を得る」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 買取担当者→経理担当者が店頭買取管理 — 買取詳細（買取情報の確認と保存）で「同じ査定IDでMTGBuyerを経理払い出し待ちにし、経理へ振込を依頼する。経理担当が査定金額を振込後、店頭買取詳細で経理払い出し済を実行する」を実施する
   対象: 査定金額=1,200円
9. 代替系#7: 店舗チームが「買取成立として、買取一覧のステータスを「買取成立」に更新される」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
10. 代替系#8: 店舗チームがB06-01（買取自動入庫バッチ）で「業務フローの15時処理に合わせて入庫待ちの店頭買取を処理する」を実施する
   対象: 買取受付番号=ST-BUY-KAITORI-001-R05
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
11. 代替系#9: 店舗チームがM06-12（買取商品一覧CSV）で「同じ査定の買取商品一覧CSVを出力し、商品コード・言語・状態・数量で現物と照合する。日英NMは通販商品、その他は原典の金額区分で仕分ける（実施保留条件: 原典06 R91/R92の価格250円の条件が重複。249円/251円の代表確認は可能だが250円の行先は確定待ち。）」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05-DP-N005 / 状態=SP / 買取価格=500円 / 数量=3 / 陳列先=ショーケース（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
12. 代替系#10: 店舗チームが在庫管理 — 在庫移動・振替登録/編集で「対象店舗の同じ商品コードについて、出庫元をEC-CUBE、入庫先をスマレジとする店舗内移動を登録し、店舗内入庫確定を実行する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
13. 代替系#11: 店舗チームが「店舗商品準備として、バーコード印刷し、商品を店頭に陳列する」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
14. 代替系#12: 店舗チームが「店頭陳列を行う」を実施する
   対象: 商品コード=ST-CARD-KAITORI-001-R05
【操作後確認】
15. 最終業務状態「同じ買取受付の承諾明細・支払金額・入庫数量を照合し、店頭陳列まで完了したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#9
差分固有判定: 同じ商品コード3枚の陳列先がショーケースになり、元の買取記録と現物を照合できること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ商品コード3枚の陳列先がショーケースになり、元の買取記録と現物を照合できること。	"確認場所: 同じ商品コード3枚の陳列先がショーケースになり、元の買取記録と現物を照合できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 買取受付番号=ST-BUY-KAITORI-001-R05
合格条件: 同じ商品コード3枚の陳列先がショーケースになり、元の買取記録と現物を照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-KAITORI-005-025/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-KAITORI-005-025、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-KAITORI-店頭買取本店支店とも-005_店頭買取（本店、支店ともに同じフロー）（査定承諾・店頭商品を陳列）.md / 店頭買取 / パターン1 / 経路5
差分判定根拠: プレイド500円の陳列先（原典本文 06_店頭買取.md R86「買取価格が1円～250円以下のプレイドは、ストレージ等に入庫」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
