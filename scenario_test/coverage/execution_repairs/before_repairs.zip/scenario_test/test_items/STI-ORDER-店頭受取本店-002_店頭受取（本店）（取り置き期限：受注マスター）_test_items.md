<!-- generated-by: hareruya-scenario-test-items -->
# 店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M05-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M05-11 | テスト項目化 | あり | 代替フロー、代替業務 |
| M05-14 | テスト項目化 | あり | 代替フロー |
| M05-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A05-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| A05-04 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| B05-05 | テスト項目化 | あり | 代替業務 |
| A05-02 | テスト項目化 | あり | 代替フロー |
| F04-04 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 照合キー: 受注番号・店舗・商品コード / 出典: scenario_test/markdown/05_店頭受取受注管理.md:26 / excel_to_html/output/0304_基本設計仕様書(フロント_注文).html:2030#sheet-7 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2318#sheet-12 / 設計差・留意点: 自動印字不可の支店はフローの例外を保持。注文受領直後と印字後ピック中を分けて観測。 / 照合/査定結果（一致・可否）と後続処理の可否 / 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-002	F04-04,A05-02	代替フロー	P1	代替系 #1: お客様が「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を行い「注文の店舗・受注番号・商品・数量がスタック用紙と一致し、対応状況が印字後のピック中として記録される」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）
- この工程で通過する機能: F04-04 カート — 決済〜購入完了 → A05-02 API 受注管理 — 注文印刷（印刷済み更新）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
12. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md（カート — 決済〜購入完了）
15. この工程で通過する機能: F04-04 カート — 決済〜購入完了 → A05-02 API 受注管理 — 注文印刷（印刷済み更新）
【操作】
1. フロント画面で カート — 決済〜購入完了 を開く
2. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 通過する機能: F04-04 → A05-02。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
【操作後確認】
5. カート — 決済〜購入完了 で対象キーと 処理後の画面表示 を記録する"	注文の店舗・受注番号・商品・数量がスタック用紙と一致し、対応状況が印字後のピック中として記録されること。	"確認場所: カート — 決済〜購入完了（F04-04,A05-02） / 照合キー: 受注番号・店舗・商品コード / 出典: scenario_test/markdown/05_店頭受取受注管理.md:26 / excel_to_html/output/0304_基本設計仕様書(フロント_注文).html:2030#sheet-7 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2318#sheet-12 / 設計差・留意点: 自動印字不可の支店はフローの例外を保持。注文受領直後と印字後ピック中を分けて観測。
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 注文の店舗・受注番号・商品・数量がスタック用紙と一致し、対応状況が印字後のピック中として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/f04-04_front_cart_shopping_complete.md
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-003	M05-11,M05-14	代替フロー	P1	代替系 #2: 店舗チームが「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を行い「スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
- この工程で通過する機能: M05-11 受注管理 — 受注情報編集 → M05-14 受注管理 — 受注対応状況の変更"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
15. この工程で通過する機能: M05-11 受注管理 — 受注情報編集 → M05-14 受注管理 — 受注対応状況の変更
【操作】
1. 管理画面で 受注管理 — 受注情報編集 ほか（M05-11・M05-14） を開く
2. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 通過する機能: M05-11 → M05-14。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
【操作後確認】
5. 受注管理 — 受注情報編集 ほか（M05-11・M05-14） で対象キーと 保存しました を記録する"	スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 受注管理 — 受注情報編集（M05-11,M05-14） / 照合/査定結果（一致・可否）と後続処理の可否
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認することを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-004	-	代替フロー	P1	代替系 #3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を行い「注文商品をピッキングすることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
2. 「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
【操作後確認】
3. 商品で、注文商品をピッキングすることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo の対応を記録する"	注文商品をピッキングすることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 注文商品をピッキングすることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-005	M05-11	代替フロー	P1	代替系 #4: 店舗チームが「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を行い「受注の対応状況がピック完了となり、店頭表示の対象条件に該当する注文を確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
【操作】
1. 管理画面で スタック用紙と同じ受注番号 を開く
2. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
【操作後確認】
4. スタック用紙と同じ受注番号 で対象キーと 保存しました を記録する"	受注の対応状況がピック完了となり、店頭表示の対象条件に該当する注文を確認できること。	"確認場所: 受注管理 — 受注情報編集（M05-11） / 照合キー: 受注番号・店頭注文番号 / 出典: scenario_test/markdown/05_店頭受取受注管理.md:35 / scenario_test/markdown/05_店頭受取受注管理.md:63 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2712#sheet-15 / excel_to_html/output/0306_基本設計仕様書(フロント_会員).html:4863#sheet-21
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 受注の対応状況がピック完了となり、店頭表示の対象条件に該当する注文を確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-006	-	代替業務	P1	代替系 #5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を行い「判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態である」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
2. 「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
【操作後確認】
3. 照合キー: / 出典: scenario_test/markdown/05_店頭受取受注管理.md:37 / scenario_test/markdown/05_店頭受取受注管理.md:94 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。で、判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進めること。の実値と対象データ 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo の対応を記録する"	判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。	"確認場所: 照合キー: / 出典: scenario_test/markdown/05_店頭受取受注管理.md:37 / scenario_test/markdown/05_店頭受取受注管理.md:94 / 設計差・留意点: 原典の判断または期限照合であり、専用のシステム更新機能を必要としない。
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 判断に使用した条件と選択した後続業務が記録され、その条件に対応する工程へ進める状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-007	M05-11	代替業務	P1	代替系 #6: 店舗チームが「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を行い「同じ受注番号の対応状況がキャンセルとなり、キャンセル日時・商品数量を後続の取り置き解除作業へ引き継げる状態である」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘13件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証: http://localhost:8080/admin/login に admin / password でログインする
12. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md（受注管理 — 受注情報編集）
【操作】
1. 管理画面で 取り置き期限を超過した同じ受注番号 を開く
2. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
【操作後確認】
4. 取り置き期限を超過した同じ受注番号 で対象キーと 保存しました を記録する"	同じ受注番号の対応状況がキャンセルとなり、キャンセル日時・商品数量を後続の取り置き解除作業へ引き継げる状態であること。	"確認場所: 受注管理 — 受注情報編集（M05-11） / 照合キー: 受注番号・店頭注文番号 / 出典: scenario_test/markdown/05_店頭受取受注管理.md:39 / scenario_test/markdown/05_店頭受取受注管理.md:70 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html:2712#sheet-15 / 設計差・留意点: モニター自動非表示の有無は店舗別の業務フロー条件を併記して確認する。
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 同じ受注番号の対応状況がキャンセルとなり、キャンセル日時・商品数量を後続の取り置き解除作業へ引き継げる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m05-11_admin_order_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-008	-	代替フロー	P1	代替系 #7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を行い「ピッキングした商品を元に戻すことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
2. 「商品戻しとして、ピッキングした商品を元に戻す」を実施する
【操作後確認】
3. 商品で、ピッキングした商品を元に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo の対応を記録する"	ピッキングした商品を元に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: ピッキングした商品を元に戻すことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-009	B05-05	代替業務	P1	代替系 #8: 店舗チームが「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を行い「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 実行権限: ec-cubeコンテナ内で対象バッチを起動でき、開始・終了ログを取得できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 設計根拠: functions/pf-eccube3/b05-05_batch_order_order_delete_smaregi_product.md（バッチ 受注管理 — スマレジ商品削除）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 実行権限: ec-cubeコンテナ内で対象バッチを起動でき、開始・終了ログを取得できる
12. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 先行工程#1で取得した受注番号の実値を使う。対応が無い場合はその先行工程から実行し、別レコードを作り直さない。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
14. 設計根拠: functions/pf-eccube3/b05-05_batch_order_order_delete_smaregi_product.md（バッチ 受注管理 — スマレジ商品削除）
【操作】
1. 実行開始時刻を記録し、`docker compose exec ec-cube bin/console eccube:smaregi:otc:delete` を実行する
2. 対象データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
【操作後確認】
4. バッチ 受注管理 — スマレジ商品削除 で対象キーと 処理後の画面表示 を記録する"	スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: バッチ 受注管理 — スマレジ商品削除（B05-05） / 画面表示・処理ステータス・処理履歴
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/b05-05_batch_order_order_delete_smaregi_product.md
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-010	-	代替フロー	P1	代替系 A1 #1: お客様が「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を行い「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=取り置き期限の判断結果として実線で「受注マスター」へ進む場合
入力=受注番号=ST-PICKUP-ORDER-001-R02-A1 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo"	"担当者: お客様
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 対象データ: 受注番号=ST-PICKUP-ORDER-001-R02-A1 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
2. 分岐条件「注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。」を成立させる
3. 「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を実施する
【操作後確認】
4. 更新後の値と更新履歴で、スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 受注番号=ST-PICKUP-ORDER-001-R02-A1 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo の対応を記録する"	スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 更新後の値と更新履歴
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-011	-	データ連鎖	P1	代替系 DL-01: 産出値と消費値の照合 — #2 受注*1	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 連鎖ID: DL-01
- 対象範囲: 産出値と消費値の照合
- 原典判定: 連鎖あり
- 判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-01 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
連鎖ID=DL-01
照合キー=受注番号（当該受注の実番号）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#1 店頭受取注文、消費=#4 受注マスター。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#2 受注*1をproducer原本として保存する。
#4 受注マスターで実際に参照した原本をconsumer原本として保存し、受注番号・商品・数量・請求金額をproducer原本と同じ照合キーで比較する。工程間で変更した列は原典に明記された変換だけを許容し、その計算過程を別記する。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	#1 店頭受取注文で産出した#2 受注*1の受注番号・商品・数量・請求金額が、#4 受注マスターが参照した値と照合キー 受注番号（当該受注の実番号） で一致する状態であること。	"確認場所: #2 受注*1
照合キー: 受注番号（当該受注の実番号）
合格条件: #1 店頭受取注文で産出した#2 受注*1の受注番号・商品・数量・請求金額が、#4 受注マスターが参照した値と照合キー 受注番号（当該受注の実番号） で一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-01 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 連鎖あり
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-012	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #8 受注*1	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-02 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
連鎖ID=DL-02
照合キー=受注番号（当該受注の実番号）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#7 受注マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#8 受注*1をproducer原本として保存する。
産出原本から 受注番号・商品・数量・請求金額 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #7 受注マスター の成果物 #8 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。	"確認場所: #8 受注*1
照合キー: 受注番号（当該受注の実番号）
合格条件: 産出工程 #7 受注マスター の成果物 #8 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-02 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-013	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #8 受注*1	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-03 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
連鎖ID=DL-03
照合キー=受注番号（当該受注の実番号）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#12 受注マスター、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#8 受注*1をproducer原本として保存する。
産出原本から 受注番号・商品・数量・請求金額 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #12 受注マスター の成果物 #8 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。	"確認場所: #8 受注*1
照合キー: 受注番号（当該受注の実番号）
合格条件: 産出工程 #12 受注マスター の成果物 #8 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-03 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-014	-	データ連鎖	P1	代替系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #16 受注*1	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 注文日を含めて7日間の受取期限になるテスト注文を用意する。担当者の業務時計を指定日時に設定し、期限内/期限超過を判定して同じ受注の引渡しまたはキャンセル結果を確認する。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-04 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
連鎖ID=DL-04
照合キー=受注番号（当該受注の実番号）"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-order-001-r02 / 受注番号=ST-PICKUP-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ORDER-001-R02 / 注文日=2026-10-01 / 受取期限=2026-10-07（注文日を含む7日間） / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#18 バッチ処理、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=受注番号（当該受注の実番号）。注文または取込で得た実受注番号をシード受注番号へ対応付け、出力対象の条件も保存する。
【操作】
産出工程の完了直後に#16 受注*1をproducer原本として保存する。
産出原本から 受注番号・商品・数量・請求金額 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #18 バッチ処理 の成果物 #16 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。	"確認場所: #16 受注*1
照合キー: 受注番号（当該受注の実番号）
合格条件: 産出工程 #18 バッチ処理 の成果物 #16 受注*1 の受注番号・商品・数量・請求金額が、照合キー 受注番号（当該受注の実番号） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md データ連鎖 DL-04 / 店頭受取受注管理 / パターン1 / 経路2 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15 / excel_to_html/output/0203_基本設計仕様書(受注管理機能).html#sheet-15
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
店頭受取受注管理 — 店頭受取（本店）（取り置き期限：受注マスター）	STI-ORDER-002-015	-	業務データ差分	P1	代替系 DP-N002: キャンセル後に来店した顧客へ説明（	"元シナリオ: SCN-ORDER-店頭受取本店-002 店頭受取（本店）（取り置き期限：受注マスター）
業務: 店頭受取受注管理
経路ID: R02
経路種別: 主要代替
業務経路条件: 取り置き期限の判断結果として実線で「受注マスター」へ進む場合
最終業務状態: スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE（本店/支店）、スマレジ
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: 期限超過でキャンセルした注文を用意し、キャンセル後の来店を担当者間で再現する。事前の取消通知は原典上行わない。
シードデータ: 担当者アカウント=st-user-order-001-r02 / 会員番号=ST-MEMBER-ORDER-001-R02 / 商品コード=ST-CARD-ORDER-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 受注番号=ST-PICKUP-ORDER-001-R02 / 受取店舗=晴れる屋テスト店舗 / 受取期限=2026-10-07（注文日を含む7日間） / 決済状態=未引渡し / 注文日=2026-10-01 / 業務確認日時=2026-10-09 10:00 Asia/Tokyo
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
- 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
- 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
- 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
- 差分設定: 期限超過でキャンセルした注文を用意し、キャンセル後の来店を担当者間で再現する。事前の取消通知は原典上行わない。
- 判定根拠: キャンセル後に来店した顧客へ説明（原典本文 05_店頭受取受注管理.md R51「受取に来られた場合にキャンセルになった旨を伝える」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=キャンセル後に来店した顧客へ説明（原典本文 05_店頭受取受注管理.md R51「受取に来られた場合にキャンセルになった旨を伝える」）
入力=受注番号=ST-PICKUP-ORDER-001-R02-DP-N002 / 注文日=2026-10-01 / キャンセル日=2026-10-09 / 来店日=2026-10-10 / 来店者=同じ注文の顧客"	"担当者: 店舗チーム
【準備確認】
差分実行ID: DP-N002
条件設定: 期限超過でキャンセルした注文を用意し、キャンセル後の来店を担当者間で再現する。事前の取消通知は原典上行わない。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=F04-04, A05-02, B05-05; 未実装指摘あり=2; 実装違い指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/order-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/order-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ORDER-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/order-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ORDER-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ORDER-001-R02 に対応付ける
10. 初回採番データ: 受注番号=工程#1の実行結果。これらをfixtureで先に作成せず、経路内の初回登録後に同じ実IDを引き継ぎ、工程ごとに作り直さない
11. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
12. 認証（フロント）: http://localhost:8080/ja を開き、会員fixture応答のemail / password でログインする
13. 認証（API）: 各API設計書で定義された認証情報をテスト環境の管理者から払い出す
14. 業務環境: EC-CUBE（本店/支店）、スマレジ のうち経路で使用する外部サービス、帳票または現物を利用できる
15. 担当者識別子: st-user-order-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
16. 対象状態: 受注番号は未採番/未作成として開始し、工程#1の初回採番・登録結果を論理IDへ対応付ける。開始前の検索・存在確認は入力側の会員・既存商品・店舗マスタに限定し、今回作成する対象を除く
【操作】
1. 経路ID R02（主要代替）の条件「取り置き期限の判断結果として実線で「受注マスター」へ進む場合」を満たすことを確認する
2. 経路代表データ: 受注番号=ST-PICKUP-ORDER-001-R02-DP-N002 / 注文日=2026-10-01 / キャンセル日=2026-10-09 / 来店日=2026-10-10 / 来店者=同じ注文の顧客
3. 代替系#1: お客様がカート — 決済〜購入完了で「指定した店舗・配送方法で注文を完了し、採番された受注番号に対応するスタック用紙の印字を確認する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
4. 代替系#2: 店舗チームが受注管理 — 受注情報編集 ほか（M05-11・M05-14）で「スタック用紙読込として、スタック用紙のQRコードをタブレットで読み込み、対象の受注情報を確認する 受注マスターの対応状況が「ピック中」に更新する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
5. 代替系#3: 店舗チームが「ピッキングとして、注文商品をピッキングする ※ピック中であることが分かるように対象のスタック用紙をボードに張り付ける ※ピックした商品とスタック用紙はレジ裏に配置する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
6. 代替系#4: 店舗チームがスタック用紙と同じ受注番号で「スタック用紙と同じ受注番号を開き、対応状況をピック完了として登録する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
7. 代替系#5: 店舗チームが「期限超過チェックとして、お取り置き期間は、注文日を含めて7日間 ※キャンセル発生率は１％程度」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
   差分条件を適用: 期限超過でキャンセルした注文を用意し、キャンセル後の来店を担当者間で再現する。事前の取消通知は原典上行わない。
8. 代替系#6: 店舗チームが取り置き期限を超過した同じ受注番号で「取り置き期限を超過した同じ受注番号を開き、対応状況をキャンセルへ変更する」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02-DP-N002 / 注文日=2026-10-01 / キャンセル日=2026-10-09 / 来店日=2026-10-10 / 来店者=同じ注文の顧客（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
9. 代替系#7: 店舗チームが「商品戻しとして、ピッキングした商品を元に戻す」を実施する
   対象: 商品コード=ST-CARD-ORDER-001-R02
10. 代替系#8: 店舗チームがバッチ 受注管理 — スマレジ商品削除で「スマレジ受注として、スマレジの受注情報を削除する 情報削除 ※受注マスターの対応状況が「出荷完了」「キャンセル」となっているデータ が対象 ※夜間自動実行」を実施する
   対象: 受注番号=ST-PICKUP-ORDER-001-R02
【操作後確認】
11. 最終業務状態「スマレジの受注情報を削除することを、画面表示・処理ステータス・処理履歴で確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#6
差分固有判定: 同じ注文番号のキャンセル状態を確認し、来店した顧客へキャンセル済みと伝え、商品を引き渡さないこと。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ注文番号のキャンセル状態を確認でき、来店した顧客へキャンセル済みと伝え、商品を引き渡さない状態であること。	"確認場所: 同じ注文番号のキャンセル状態を確認し、来店した顧客へキャンセル済みと伝え、商品を引き渡さないこと。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 受注番号=ST-PICKUP-ORDER-001-R02
合格条件: 同じ注文番号のキャンセル状態を確認でき、来店した顧客へキャンセル済みと伝え、商品を引き渡さない状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ORDER-002-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ORDER-002-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ORDER-店頭受取本店-002_店頭受取（本店）（取り置き期限：受注マスター）.md / 店頭受取受注管理 / パターン1 / 経路2
差分判定根拠: キャンセル後に来店した顧客へ説明（原典本文 05_店頭受取受注管理.md R51「受取に来られた場合にキャンセルになった旨を伝える」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
