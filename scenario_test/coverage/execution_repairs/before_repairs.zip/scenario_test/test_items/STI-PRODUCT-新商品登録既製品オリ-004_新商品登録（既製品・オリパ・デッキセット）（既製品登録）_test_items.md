<!-- generated-by: hareruya-scenario-test-items -->
# 商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M03-01 | テスト項目化 | あり | CSV/帳票 |
| M03-02 | テスト項目化 | あり | 業務操作 |
| M03-26 | テスト項目化 | あり | CSV/帳票 |
| M03-27 | テスト項目化 | あり | CSV/帳票 |
| M03-35 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-38 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-01 | テスト項目化 | あり | CSV/帳票 |
| M04-21 | テスト項目化 | あり | CSV/帳票 |
| M04-12 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-13 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-23 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認） / 出力されたCSV/帳票の件数と内容 / 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-002	-	業務操作	P1	正常系 #1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を行い「サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
2. 「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
【操作後確認】
3. 商品で、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼することを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開 の対応を記録する"	サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-003	-	業務操作	P1	正常系 #2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を行い「デッキセット作成の場合デッキリスト作成を行うことを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
2. 「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
【操作後確認】
3. デッキセット作成の場合デッキリストで、デッキセット作成の場合デッキリスト作成を行うことを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開 の対応を記録する"	デッキセット作成の場合デッキリスト作成を行うことを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: デッキセット作成の場合デッキリスト作成を行うことを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-003、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-004	M03-26	CSV/帳票	P1	正常系 #3: トレードチームが「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を行い「EC-CUBEに登録するためのインポート用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
- 必須入力欄: CSV ファイル"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
14. 必須入力欄: CSV ファイル
【操作】
1. 管理画面で 商品管理 — カード商品CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
【操作後確認】
4. 商品管理 — カード商品CSV登録 で対象キーと 処理後の画面表示 を記録する"	EC-CUBEに登録するためのインポート用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — カード商品CSV登録（M03-26） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: EC-CUBEに登録するためのインポート用CSVを作成することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-005	M03-01	CSV/帳票	P1	正常系 #4: トレードチームが「商品登録として、CSVをアップロードし商品登録を行う」を行い「CSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md（商品管理 — 商品検索・一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md（商品管理 — 商品検索・一覧）
【操作】
1. 管理画面で 商品管理 — 商品検索・一覧 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「商品登録として、CSVをアップロードし商品登録を行う」を実施する
【操作後確認】
4. 商品管理 — 商品検索・一覧 で対象キーと 処理後の画面表示 を記録する"	CSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — 商品検索・一覧（M03-01） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: CSVをアップロードし商品登録を行うことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-01_admin_product_product_search_list.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-006	M04-01	CSV/帳票	P1	正常系 #5: トレードチームが「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を行い「在庫CSV出力することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md（在庫管理 — 在庫検索/一覧）
【操作】
1. 管理画面で 在庫管理 — 在庫検索/一覧 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
【操作後確認】
4. 在庫管理 — 在庫検索/一覧 で対象キーと 検索パターン名を登録しました。 を記録する"	在庫CSV出力することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 在庫管理 — 在庫検索/一覧（M04-01） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 在庫CSV出力することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 検索パターン名を登録しました。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/ec-cube-enterprise/m04-01_admin_stock_stock_search_list.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-007	M03-27	CSV/帳票	P1	正常系 #6: トレードチームが「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を行い「CSVに在庫数を手作業で打ち込むことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-27_admin_product_product_goods_csv_import.md（商品管理 — グッズ商品CSV登録）
- 必須入力欄: CSVファイル選択"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-27_admin_product_product_goods_csv_import.md（商品管理 — グッズ商品CSV登録）
14. 必須入力欄: CSVファイル選択
【操作】
1. 管理画面で 商品管理 — グッズ商品CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
【操作後確認】
4. 商品管理 — グッズ商品CSV登録 で対象キーと 処理後の画面表示 を記録する"	CSVに在庫数を手作業で打ち込むことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — グッズ商品CSV登録（M03-27） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: CSVに在庫数を手作業で打ち込むことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-27_admin_product_product_goods_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-008	M04-21	CSV/帳票	P1	正常系 #7: トレードチームが「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を行い「CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致される」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
- 必須入力欄: CSVファイル / 変更理由"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md（在庫管理 — 在庫変更CSV登録）
14. 必須入力欄: CSVファイル / 変更理由
【操作】
1. 管理画面で 在庫管理 — 在庫変更CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
【操作後確認】
4. 在庫管理 — 在庫変更CSV登録 で対象キーと 処理後の画面表示 を記録する"	CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致されること。	"確認場所: 在庫管理 — 在庫変更CSV登録（M04-21） / 照合キー: 商品コード・店舗・在庫区分・承認ID / 出典: scenario_test/markdown/10_商品登録・編集_tobe.md:106 / excel_to_html/output/0202_基本設計仕様書(在庫管理機能).html:5979#sheet-27 / 設計差・留意点: 入庫反映は承認工程で確認する。CSV登録のみを入庫完了とはしない。
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: CSVの各商品コードに対応する承認対象が登録され、数量・原価・店舗・区分がCSVと一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m04-21_admin_stock_stock_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-009	M03-02	業務操作	P1	正常系 #8: トレードチームが「公開設定として、非公開商品だった場合公開設定に変更する」を行い「非公開商品だった場合公開設定に変更することを、公開状態で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-02_admin_product_product_edit.md（商品管理 — 商品編集機能）
- 必須入力欄: 商品名 / 商品名(英) / 商品カテゴリ / 購入グループ / サイズ / 重量 / 割引率 / 販売制限 / 商品ステータス"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-02_admin_product_product_edit.md（商品管理 — 商品編集機能）
14. 必須入力欄: 商品名 / 商品名(英) / 商品カテゴリ / 購入グループ / サイズ / 重量 / 割引率 / 販売制限 / 商品ステータス
【操作】
1. 管理画面で 商品管理 — 商品編集機能 を開く
2. 対象データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
【操作後確認】
4. 商品管理 — 商品編集機能 で対象キーと 保存しました を記録する"	非公開商品だった場合公開設定に変更することを、公開状態で確認できること。	"確認場所: 商品管理 — 商品編集機能（M03-02） / 公開状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 非公開商品だった場合公開設定に変更することを、公開状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-009、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-02_admin_product_product_edit.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-010	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #51 グッズ・サプライ情報商材登録CSV	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-01 / 商品登録・編集 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-13"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
連鎖ID=DL-01
照合キー=商品コード（実行用テストデータに対応する値）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#50 インポート用CSV作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード（実行用テストデータに対応する値）。新規登録CSVに対象の商品コードを設定し、取込後に採番された商品IDとの対応を記録する。
【操作】
産出工程の完了直後に#51 グッズ・サプライ情報商材登録CSVをproducer原本として保存する。
産出原本から 商品コード・言語(ID)・商品名 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #50 インポート用CSV作成 の成果物 #51 グッズ・サプライ情報商材登録CSV の商品コード・言語(ID)・商品名が、照合キー 商品コード（実行用テストデータに対応する値） に対応する作業元の確定値と一致する状態であること。	"確認場所: #51 グッズ・サプライ情報商材登録CSV
照合キー: 商品コード（実行用テストデータに対応する値）
合格条件: 産出工程 #50 インポート用CSV作成 の成果物 #51 グッズ・サプライ情報商材登録CSV の商品コード・言語(ID)・商品名が、照合キー 商品コード（実行用テストデータに対応する値） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-01 / 商品登録・編集 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-13
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-011	-	データ連鎖	P1	正常系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #55 商品*3	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-02 / 商品登録・編集 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
連鎖ID=DL-02
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#54 グッズ・サプライ情報商材登録CSV、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#55 商品*3をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #54 グッズ・サプライ情報商材登録CSV の成果物 #55 商品*3 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #55 商品*3
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #54 グッズ・サプライ情報商材登録CSV の成果物 #55 商品*3 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-02 / 商品登録・編集 / パターン4 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-012	-	データ連鎖	P1	正常系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #71 在庫CSV	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-03 / 商品登録・編集 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
連鎖ID=DL-03
照合キー=商品コード=ST-PRODUCT-PRODUCT-004-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#70 在庫検索一覧、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-PRODUCT-PRODUCT-004-R01。
【操作】
産出工程の完了直後に#71 在庫CSVをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #70 在庫検索一覧 の成果物 #71 在庫CSV の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-PRODUCT-PRODUCT-004-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #71 在庫CSV
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 産出工程 #70 在庫検索一覧 の成果物 #71 在庫CSV の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-PRODUCT-PRODUCT-004-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-03 / 商品登録・編集 / パターン4 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-013	-	データ連鎖	P1	正常系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #73 在庫変更CSV	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 未登録の商品と画像を用意する。デッキセットの場合は構成商品の在庫とデッキリストを準備し、既製品の場合は入庫数量を在庫CSVへ記載する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-04 / 商品登録・編集 / パターン4 / 経路1"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
連鎖ID=DL-04
照合キー=商品コード=ST-PRODUCT-PRODUCT-004-R01"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-004-r01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=既製品 / 公開状態=非公開
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#72 在庫インポート用CSV作成、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品コード=ST-PRODUCT-PRODUCT-004-R01。
【操作】
産出工程の完了直後に#73 在庫変更CSVをproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #72 在庫インポート用CSV作成 の成果物 #73 在庫変更CSV の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-PRODUCT-PRODUCT-004-R01 に対応する作業元の確定値と一致する状態であること。	"確認場所: #73 在庫変更CSV
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 産出工程 #72 在庫インポート用CSV作成 の成果物 #73 在庫変更CSV の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー 商品コード=ST-PRODUCT-PRODUCT-004-R01 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md データ連鎖 DL-04 / 商品登録・編集 / パターン4 / 経路1
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-014	-	業務データ差分	P1	正常系 DP-N002: オリパの商品画像をデザインチームへ依頼（	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N002
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: オリパの商品画像をデザインチームへ依頼（原典本文 10_商品登録・編集_tobe.md R145「オリパ作成時のみデザインチームに画像作成を依頼する」）"	"データパターンID=DP-N002
種別=正常系 業務データ差分
目的=オリパの商品画像をデザインチームへ依頼（原典本文 10_商品登録・編集_tobe.md R145「オリパ作成時のみデザインチームに画像作成を依頼する」）
入力=商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N002 / 商品種別=オリパ / 商品コード=今回作成対象 / 画像担当=デザインチーム"	"担当者: トレードチーム
【準備確認】
差分実行ID: DP-N002
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N002 / 商品種別=オリパ / 商品コード=今回作成対象 / 画像担当=デザインチーム
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N002 / 商品種別=オリパ / 商品コード=今回作成対象 / 画像担当=デザインチーム（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#1
差分固有判定: デザインチームが同じ商品用の画像を作成し、商品コードと対応する画像を後続のCSV商品登録へ渡せること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	デザインチームが同じ商品用の画像が作成され、商品コードと対応する画像を後続のCSV商品登録へ渡せる状態であること。	"確認場所: デザインチームが同じ商品用の画像を作成し、商品コードと対応する画像を後続のCSV商品登録へ渡せること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: デザインチームが同じ商品用の画像が作成され、商品コードと対応する画像を後続のCSV商品登録へ渡せる状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
差分判定根拠: オリパの商品画像をデザインチームへ依頼（原典本文 10_商品登録・編集_tobe.md R145「オリパ作成時のみデザインチームに画像作成を依頼する」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
商品登録・編集 — 新商品登録（既製品・オリパ・デッキセット）（既製品登録）	STI-PRODUCT-004-015	-	業務データ差分	P1	正常系 DP-N003: 既に公開されている商品を確認（	"元シナリオ: SCN-PRODUCT-新商品登録既製品オリ-004 新商品登録（既製品・オリパ・デッキセット）（既製品登録）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）
最終業務状態: 登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N003
データパターン種別: 正常系 業務データ差分
前提差分: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
シードデータ: 担当者アカウント=st-user-product-004-r01 / 会員番号=ST-MEMBER-PRODUCT-004-R01 / 商品コード=ST-PRODUCT-PRODUCT-004-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=既製品
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 差分設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
- 判定根拠: 既に公開されている商品を確認（原典本文 10_商品登録・編集_tobe.md R211「非公開商品だった場合公開設定に変更する」）"	"データパターンID=DP-N003
種別=正常系 業務データ差分
目的=既に公開されている商品を確認（原典本文 10_商品登録・編集_tobe.md R211「非公開商品だった場合公開設定に変更する」）
入力=商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N003 / 変更前公開状態=公開 / 商品コード=今回処理対象"	"担当者: トレードチーム
【準備確認】
差分実行ID: DP-N003
条件設定: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
試験ごとに独立した案件を準備する。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M03-26, M03-01, M04-01, M03-27, M04-21, M03-02; 未実装指摘あり=6（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-004-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-004-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-004-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-004-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-004-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-004-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-004-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=既製品（原典本文 10_商品登録・編集_tobe.md R145–211,図形#66「デッキセットの在庫については結合で作成する」）」を満たすことを確認する
2. 経路代表データ: 商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N003 / 変更前公開状態=公開 / 商品コード=今回処理対象
3. 正常系#1: トレードチームが「商品画像準備として、サプライ品、構築済みデッキなど既製品の場合や デッキセット作成の場合はトレードにて画像を用意 オリパ作成時のみデザインチームに画像作成を依頼する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
4. 正常系#2: トレードチームが「デッキセット判定として、デッキセット作成の場合デッキリスト作成を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
5. 正常系#3: トレードチームが商品管理 — カード商品CSV登録で「インポート用CSV作成として、EC-CUBEに登録するためのインポート用CSVを作成する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
6. 正常系#4: トレードチームが商品管理 — 商品検索・一覧で「商品登録として、CSVをアップロードし商品登録を行う」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
7. 正常系#5: トレードチームが在庫管理 — 在庫検索/一覧で「デッキセット以外の在庫登録として、在庫CSV出力 グッズ・サプライ情報商材登録CSVで登録した商品を絞り込み 在庫インポート用CSVのもとになるCSVを出力する（カスタムCSV出力で出力）」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
8. 正常系#6: トレードチームが商品管理 — グッズ商品CSV登録で「在庫インポート用CSV作成として、CSVに在庫数を手作業で打ち込む」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
9. 正常系#7: トレードチームが在庫管理 — 在庫変更CSV登録で「商品コード・店舗・在庫区分・原価・数量を設定した在庫変更CSVを登録し、作成された承認情報を控える」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01
   差分条件を適用: この経路と同じ開始状態の対象を別IDで用意し、入力欄の業務条件を設定する。対象の工程を経路内の前後工程と通して確認する。
10. 正常系#8: トレードチームが商品管理 — 商品編集機能で「公開設定として、非公開商品だった場合公開設定に変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-004-R01-DP-N003 / 変更前公開状態=公開 / 商品コード=今回処理対象（代表シードの同名項目をこの値に差し替え、後続工程も同じ実データを使う）
【操作後確認】
11. 最終業務状態「登録商品の在庫CSVを作成・取り込みし、在庫数を反映して商品を公開したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【操作後確認】
差分対象工程: 正常系#8
差分固有判定: 同じ商品コードが公開のまま維持され、不要な公開状態変更を行わず在庫登録結果と公開状態を照合できること。
条件・入力値・対象工程の実測値をvariation-comparison.tsvへ記録する。"	同じ商品コードが公開のまま維持され、不要な公開状態変更を行わず在庫登録結果と公開状態を照合できること。	"確認場所: 同じ商品コードが公開のまま維持され、不要な公開状態変更を行わず在庫登録結果と公開状態を照合できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-004-R01
合格条件: 同じ商品コードが公開のまま維持され、不要な公開状態変更を行わず在庫登録結果と公開状態を照合できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-004-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-004-015、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-新商品登録既製品オリ-004_新商品登録（既製品・オリパ・デッキセット）（既製品登録）.md / 商品登録・編集 / パターン4 / 経路1
差分判定根拠: 既に公開されている商品を確認（原典本文 10_商品登録・編集_tobe.md R211「非公開商品だった場合公開設定に変更する」）
必須照合証跡: variation-comparison.tsv（条件・入力値・期待値・実測値・差分）"
```
