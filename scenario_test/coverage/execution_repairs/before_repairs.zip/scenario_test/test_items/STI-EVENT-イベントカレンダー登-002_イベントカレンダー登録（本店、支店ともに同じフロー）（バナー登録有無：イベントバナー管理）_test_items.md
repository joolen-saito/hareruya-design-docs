<!-- generated-by: hareruya-scenario-test-items -->
# イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M13-14 | テスト項目化 | あり | 代替フロー |
| M13-15 | テスト項目化 | あり | 代替フロー |
| M13-02 | テスト項目化 | あり | 代替フロー |
| M13-03 | テスト項目化 | あり | 代替フロー |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-001	-	業務経路	P1	代替系 経路全体 R02: 主要代替として「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 代替系#1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント編集/削除で「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
5. 代替系#3: 店舗チームがイベント管理 — 日程追加で「日程登録として、イベントの開催日時等を入力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
6. 代替系#4: 店舗チームがイベント管理 — バナー設定で「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
7. 代替系#5: 店舗チームがイベント管理 — 画像設定で「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
8. 代替系#6: 店舗チームがイベント管理 — バナー設定で「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
【操作後確認】
9. 最終業務状態「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない） / 照合キー: イベントID・店舗・日程 / 出典: scenario_test/markdown/08_イベント管理.md:27 / excel_to_html/output/0214_基本設計仕様書(イベント管理).html:1250#sheet-5 / 一覧・詳細に追加された対象データ / 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-002	-	代替フロー	P1	代替系 #1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を行い「スプレッドシートを用いてイベントの計画を立てることを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
2. 「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
【操作後確認】
3. 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）で、スプレッドシートを用いてイベントの計画を立てることを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名 の対応を記録する"	スプレッドシートを用いてイベントの計画を立てることを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: スプレッドシートを用いてイベントの計画を立てることを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-003	M13-02	代替フロー	P1	代替系 #2: 店舗チームが「イベント登録画面で対象イベントを1件ずつ登録する」を行い「イベントIDが採番され、イベント名・店舗・日程が登録値と一致される」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m13-02_admin_event_event_edit_delete.md（イベント管理 — イベント編集/削除）
- 必須入力欄: イベント名（日） / 略称（日） / 店舗 / 会場 / フォーマット / ルール適用度 / 公開状態 / 定員 / チーム人数 / 参加費"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m13-02_admin_event_event_edit_delete.md（イベント管理 — イベント編集/削除）
14. 必須入力欄: イベント名（日） / 略称（日） / 店舗 / 会場 / フォーマット / ルール適用度 / 公開状態 / 定員 / チーム人数 / 参加費
【操作】
1. 管理画面で イベント管理 — イベント編集/削除 を開く
2. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
【操作後確認】
4. イベント管理 — イベント編集/削除 で対象キーと イベント情報を登録しました。 / 保存しました を記録する"	イベントIDが採番され、イベント名・店舗・日程が登録値と一致されること。	"確認場所: イベント管理 — イベント編集/削除（M13-02） / 照合キー: イベントID・店舗・日程 / 出典: scenario_test/markdown/08_イベント管理.md:27 / excel_to_html/output/0214_基本設計仕様書(イベント管理).html:1250#sheet-5
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: イベントIDが採番され、イベント名・店舗・日程が登録値と一致されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: イベント情報を登録しました。 / 保存しました
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-02_admin_event_event_edit_delete.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-004	M13-03	代替フロー	P1	代替系 #3: 店舗チームが「日程登録として、イベントの開催日時等を入力する」を行い「イベントの開催日時等を入力することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-03_admin_event_event_schedule_add.md（イベント管理 — 日程追加）
- 必須入力欄: 日程（開催日時等）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-03_admin_event_event_schedule_add.md（イベント管理 — 日程追加）
14. 必須入力欄: 日程（開催日時等）
【操作】
1. 管理画面で イベント管理 — 日程追加 を開く
2. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 「日程登録として、イベントの開催日時等を入力する」を実施する
【操作後確認】
4. イベント管理 — 日程追加 で対象キーと 保存しました を記録する"	イベントの開催日時等を入力することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: イベント管理 — 日程追加（M13-03） / 一覧・詳細に追加された対象データ
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: イベントの開催日時等を入力することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-03_admin_event_event_schedule_add.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-005	M13-14	代替フロー	P1	代替系 #4: 店舗チームが「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を行い「新規でイベントバナーを登録するか分岐することを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
- 設計根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md（イベント管理 — バナー設定）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
13. 設計根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md（イベント管理 — バナー設定）
【操作】
1. 管理画面で イベント管理 — バナー設定 を開く
2. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
【操作後確認】
4. イベント管理 — バナー設定 で対象キーと 保存しました を記録する"	新規でイベントバナーを登録するか分岐することを、一覧・詳細に追加された対象データで確認できること。	"確認場所: イベント管理 — バナー設定（M13-14） / 一覧・詳細に追加された対象データ
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 新規でイベントバナーを登録するか分岐することを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-005、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-006	M13-15	代替フロー	P1	代替系 #5: 店舗チームが「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を行い「バナー画像をアップロードすることを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-15_admin_event_event_image_setting.md（イベント管理 — 画像設定）
- 必須入力欄: 画像のアップロード"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-15_admin_event_event_image_setting.md（イベント管理 — 画像設定）
14. 必須入力欄: 画像のアップロード
【操作】
1. 管理画面で イベント管理 — 画像設定 を開く
2. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
【操作後確認】
4. イベント管理 — 画像設定 で対象キーと 処理後の画面表示 を記録する"	バナー画像をアップロードすることを、取込結果と対象件数・エラー行で確認できること。	"確認場所: イベント管理 — 画像設定（M13-15） / 取込結果と対象件数・エラー行
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: バナー画像をアップロードすることを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-006、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-15_admin_event_event_image_setting.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-007	M13-14	代替フロー	P1	代替系 #6: 店舗チームが「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を行い「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md（イベント管理 — バナー設定）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘2件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md（イベント管理 — バナー設定）
【操作】
1. 管理画面で イベント管理 — バナー設定 を開く
2. 対象データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
【操作後確認】
4. イベント管理 — バナー設定 で対象キーと 保存しました を記録する"	保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。	"確認場所: イベント管理 — バナー設定（M13-14） / 照合キー: 画像URL・リンク先 / 出典: scenario_test/markdown/08_イベント管理.md:35 / excel_to_html/output/0214_基本設計仕様書(イベント管理).html:3553#sheet-21
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m13-14_admin_event_event_banner.md
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-008	-	代替フロー	P1	代替系 A1 #1: 店舗チームが「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を行い「イベントバナー管理でアップロードした画像のリンクを設定することを、取込結果と対象件数・エラー行で確認できる」を確認する	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: 分岐条件を満たす対象データを、正常代表データとは別IDで用意する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
入力=条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たす対象データ / 商品コード=ST-CARD-EVENT-001-R02-A1 / 基準=商品コード=ST-CARD-EVENT-001-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たす対象データ / 商品コード=ST-CARD-EVENT-001-R02-A1 / 基準=商品コード=ST-CARD-EVENT-001-R02
2. 分岐条件「分岐条件を満たす対象データを、正常代表データとは別IDで用意する。」を成立させる
3. 「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を実施する
【操作後確認】
4. 取込結果と対象件数・エラー行で、イベントバナー管理でアップロードした画像のリンクを設定することを、取込結果と対象件数・エラー行で確認できること。の実値と対象データ 条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たす対象データ / 商品コード=ST-CARD-EVENT-001-R02-A1 / 基準=商品コード=ST-CARD-EVENT-001-R02 の対応を記録する"	イベントバナー管理でアップロードした画像のリンクを設定することを、取込結果と対象件数・エラー行で確認できること。	"確認場所: 取込結果と対象件数・エラー行
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: イベントバナー管理でアップロードした画像のリンクを設定することを、取込結果と対象件数・エラー行で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-008、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-009	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #2 イベント計画資料	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-01 / イベント管理 / パターン1 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
連鎖ID=DL-01
照合キー=イベントID=ST-EVENT-EVENT-001-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 代替系#1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント編集/削除で「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
5. 代替系#3: 店舗チームがイベント管理 — 日程追加で「日程登録として、イベントの開催日時等を入力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
6. 代替系#4: 店舗チームがイベント管理 — バナー設定で「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
7. 代替系#5: 店舗チームがイベント管理 — 画像設定で「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
8. 代替系#6: 店舗チームがイベント管理 — バナー設定で「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
【操作後確認】
9. 最終業務状態「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#1 イベント計画、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-001-R02。
【操作】
産出工程の完了直後に#2 イベント計画資料をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #1 イベント計画 の成果物 #2 イベント計画資料 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #2 イベント計画資料
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 産出工程 #1 イベント計画 の成果物 #2 イベント計画資料 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-01 / イベント管理 / パターン1 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-010	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #4 イベント情報*1	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-02 / イベント管理 / パターン1 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
連鎖ID=DL-02
照合キー=イベントID=ST-EVENT-EVENT-001-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 代替系#1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント編集/削除で「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
5. 代替系#3: 店舗チームがイベント管理 — 日程追加で「日程登録として、イベントの開催日時等を入力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
6. 代替系#4: 店舗チームがイベント管理 — バナー設定で「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
7. 代替系#5: 店舗チームがイベント管理 — 画像設定で「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
8. 代替系#6: 店舗チームがイベント管理 — バナー設定で「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
【操作後確認】
9. 最終業務状態「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#3 イベント管理イベント登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-001-R02。
【操作】
産出工程の完了直後に#4 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #3 イベント管理イベント登録 の成果物 #4 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #4 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 産出工程 #3 イベント管理イベント登録 の成果物 #4 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-02 / イベント管理 / パターン1 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-011	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #4 イベント情報*1	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-03 / イベント管理 / パターン1 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
連鎖ID=DL-03
照合キー=イベントID=ST-EVENT-EVENT-001-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 代替系#1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント編集/削除で「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
5. 代替系#3: 店舗チームがイベント管理 — 日程追加で「日程登録として、イベントの開催日時等を入力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
6. 代替系#4: 店舗チームがイベント管理 — バナー設定で「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
7. 代替系#5: 店舗チームがイベント管理 — 画像設定で「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
8. 代替系#6: 店舗チームがイベント管理 — バナー設定で「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
【操作後確認】
9. 最終業務状態「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#5 イベント管理日程登録、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-001-R02。
【操作】
産出工程の完了直後に#4 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #5 イベント管理日程登録 の成果物 #4 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #4 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 産出工程 #5 イベント管理日程登録 の成果物 #4 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-03 / イベント管理 / パターン1 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-012	-	データ連鎖	P1	代替系 DL-04: 産出値と消費値の照合 — #10 バナー画像	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-04
- 対象範囲: 産出値と消費値の照合
- 原典判定: 起点（産出元の記載なし・消費工程で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-04 / イベント管理 / パターン1 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-04 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
- 解除条件: #10 バナー画像の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#10 バナー画像の取得方法を確定する。 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が対象成果物の実サンプル・一意キー・対応する元データを提示する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
連鎖ID=DL-04
照合キー=照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）"	"【準備確認】
DL-04: #10 バナー画像の照合キーを原典またはHTML設計書の項目に対応付け、産出値を消費値と識別できる根拠を記録する。単一シードであることだけでは代用しない。 原典上で未記載の産出元と#10 バナー画像の取得方法を確定する。 未確定理由: 参照した原典と関連HTMLから、この成果物を業務対象へ一意に対応付ける項目が確定できない。原典グラフで産出元の接続がなく、この経路だけでは生成から受渡しまでを立証できない。 必要な判断: 業務担当が対象成果物の実サンプル・一意キー・対応する元データを提示する。上流の作成工程または既存入力を取得する手順と版/取得時点を特定し、消費時点の入力原本を保存する。連鎖完了とは別に入力受領の判定範囲を確定する。
【操作】
根拠未確定の間は経路を実行せず、未定義箇所と参照した原典を記録する。
【操作後確認】
結果台帳に保留を記録する。解除条件の確定後に産出原本と消費原本の比較手順を確定して実施する。"	照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。	"確認場所: #10 バナー画像
照合キー: 照合キーは原典未定義（実施保留。単一シードで同一性を代用しない）
合格条件: 照合キーまたは取得元の根拠が未確定のため、データ連鎖の合否が保留として記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-012、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-04 / イベント管理 / パターン1 / 経路2 / 調査済出典: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-04 / scenario_test/markdown/08_イベント管理.md 本文・原典ノード/接続表
連鎖判定: 起点（産出元の記載なし・消費工程で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv
判定制約: 保留は合格件数・網羅済み件数に算入しない。"
イベント管理 — イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）	STI-EVENT-002-013	-	データ連鎖	P1	代替系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #12 イベント情報*1	"元シナリオ: SCN-EVENT-イベントカレンダー登-002 イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）
業務: イベント管理
経路ID: R02
経路種別: 主要代替
業務経路条件: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合
最終業務状態: 保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。
主アクター: 店舗チーム
関連システム: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。
シードデータ: 担当者アカウント=st-user-event-001-r02 / 会員番号=ST-MEMBER-EVENT-001-R02 / 商品コード=ST-CARD-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / イベントID=ST-EVENT-EVENT-001-R02 / イベント名=システムテスト大会 EVENT-001-R02 / 定員=8名 / 受付状態=受付前
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-05 / イベント管理 / パターン1 / 経路2"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
連鎖ID=DL-05
照合キー=イベントID=ST-EVENT-EVENT-001-R02"	"担当者: 店舗チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M13-02, M13-03, M13-15; 未実装指摘あり=3; 実装違い指摘あり=2（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/event-002-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/event-002-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-EVENT-001-R02 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/event-002-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-EVENT-001-R02"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-EVENT-001-R02 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、SPLINKS、デッキシステム、スマレジ、ポイントグランター のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-event-001-r02 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 登録前の重複確認で対象キーが存在しないことを確認する
【操作】
1. 経路ID R02（主要代替）の条件「バナー登録有無の判断結果として実線で「イベントバナー管理」へ進む場合」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-event-001-r02 / 商品コード=ST-CARD-EVENT-001-R02 / イベントID=ST-EVENT-EVENT-001-R02 / 数量=3 / 店舗=晴れる屋テスト店舗 / 定員=8名
3. 代替系#1: 店舗チームが「イベント計画として、スプレッドシートを用いてイベントの計画を立てる」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
4. 代替系#2: 店舗チームがイベント管理 — イベント編集/削除で「イベント登録画面で対象イベントを1件ずつ登録する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
5. 代替系#3: 店舗チームがイベント管理 — 日程追加で「日程登録として、イベントの開催日時等を入力する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
6. 代替系#4: 店舗チームがイベント管理 — バナー設定で「バナー登録有無として、新規でイベントバナーを登録するか分岐する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
7. 代替系#5: 店舗チームがイベント管理 — 画像設定で「イベントバナー登録として、バナー画像をアップロードする ※バナー画像はデザイン室に作成依頼する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
8. 代替系#6: 店舗チームがイベント管理 — バナー設定で「アップロード済み画像URLとリンク先を入力しバナー設定を保存する」を実施する
   対象: イベントID=ST-EVENT-EVENT-001-R02
【操作後確認】
9. 最終業務状態「保存後の画像URLとリンク先が入力値と一致し、対象イベントのバナーを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#11 イベント管理イベント編集、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=イベントID=ST-EVENT-EVENT-001-R02。
【操作】
産出工程の完了直後に#12 イベント情報*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #11 イベント管理イベント編集 の成果物 #12 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。	"確認場所: #12 イベント情報*1
照合キー: イベントID=ST-EVENT-EVENT-001-R02
合格条件: 産出工程 #11 イベント管理イベント編集 の成果物 #12 イベント情報*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー イベントID=ST-EVENT-EVENT-001-R02 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-EVENT-002-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-EVENT-002-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md / イベント管理 / パターン1 / 経路2
判定根拠: scenario_test/scenario/SCN-EVENT-イベントカレンダー登-002_イベントカレンダー登録（本店、支店ともに同じフロー）（バナー登録有無：イベントバナー管理）.md データ連鎖 DL-05 / イベント管理 / パターン1 / 経路2
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
