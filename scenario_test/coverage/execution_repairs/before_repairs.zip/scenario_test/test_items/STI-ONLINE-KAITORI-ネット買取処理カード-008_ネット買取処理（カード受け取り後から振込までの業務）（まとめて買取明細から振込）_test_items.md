<!-- generated-by: hareruya-scenario-test-items -->
# ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M07-06 | テスト項目化 | あり | 代替フロー |
| M04-21 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M04-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M07-01 | テスト項目化 | あり | 代替フロー |
| M07-03 | テスト項目化 | あり | 代替フロー、メール/通知、金額整合、状態遷移 |
| M07-04 | テスト項目化 | あり | 代替フロー、メール/通知 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-001	-	業務経路	P1	代替系 経路全体 R04: 主要代替として「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない） / 照合キー: ネット買取申込番号 / 出典: scenario_test/markdown/14_ネット買取.md:55 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:2618#sheet-17 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1858#sheet-11 / まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-002	-	代替フロー	P1	代替系 #1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を行い「郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「買取カード受領として、郵送されてきたカードを受領」を実施する
【操作後確認】
3. カードで、郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 郵送されてきたカードを受領することを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-002、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-003	M07-03	代替フロー	P1	代替系 #2: 顧客戦略チームが「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を行い「ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新される」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新されること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 照合キー: ネット買取申込番号 / 出典: scenario_test/markdown/14_ネット買取.md:55 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:2618#sheet-17 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1858#sheet-11
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 の処理後の値が ネット買取管理 — 買取情報編集（買取詳細） に更新されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-004	-	代替フロー	P1	代替系 #3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を行い「「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
【操作後確認】
3. カード・商品で、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行うことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-004、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-005	-	代替フロー	P1	代替系 #4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を行い「「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
【操作後確認】
3. MTGバイヤー・カード・商品で、「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 「価格が付く」、「価格が付くかもしれない」、商品を査定に通すことを、照合/査定結果（一致・可否）と後続処理の可否で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-006	-	代替フロー	P1	代替系 #5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を行い「「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
【操作後確認】
3. MTGバイヤーで、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進めることを、一覧・詳細に追加された対象データで確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-006/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-006、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-007	M07-03	代替フロー	P1	代替系 #6: 顧客戦略チームが「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を行い「MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とすることを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とすることを、金額・決済状態と処理履歴で確認できること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 金額・決済状態と処理履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とすることを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-007/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-007、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-008	M07-04,M07-03	代替フロー	P1	代替系 #7: 顧客戦略チームが「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を行い「手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文
- この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
15. この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 通過する機能: M07-04 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
【操作後確認】
5. ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） で対象キーと 処理後の画面表示 を記録する"	手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できること。	"確認場所: ネット買取管理 — 手動メール通知（M07-04,M07-03） / 送信されたメール/通知の内容と送信状態
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 手動メール通知にて査定内容について顧客にお知らせすることを、送信されたメール/通知の内容と送信状態で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-008/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-008、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-009	-	代替フロー	P1	代替系 #8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を行い「買取履歴で査定金額を確認し、売却するを選択することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、買取履歴で査定金額を確認し、売却するを選択することを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	買取履歴で査定金額を確認し、売却するを選択することを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 買取履歴で査定金額を確認し、売却するを選択することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-009/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-009、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-010	-	代替フロー	P1	代替系 #9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を行い「同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態である」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。に対する機能Noと操作手段を確定する
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 支店担当者
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。に対する機能Noと操作手段を確定する
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
【操作後確認】
3. 対象顧客への査定承諾メール・自動承諾メール・処理の存在を原典は記載するが専用メールで、同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態であること。	"確認場所: 照合キー: ネット買取申込番号・顧客メールアドレス / 出典: scenario_test/markdown/14_ネット買取.md:72 / excel_to_html/output/0305_基本設計仕様書(フロント_ネット買取).html:2582#sheet-11 / 設計差・留意点: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 同じ買取申込の承諾内容を顧客宛の受信メールで確認できること。 実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-010/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-010、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-011	-	代替フロー	P1	代替系 #10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を行い「査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: お客様
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
【操作後確認】
3. 査定承諾メールで、査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。	"確認場所: 外部システム/ツール側の登録・記録内容（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 査定承諾メールを受け取ることを、受信したメール/通知の内容と受信日時で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-011/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-011、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-012	M07-01,M07-03	代替フロー	P1	代替系 #11: 顧客戦略チームが「承認状況確認として、承諾内容を確認する」を行い「承諾内容を確認することを、承認状態と操作履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）
- この工程で通過する機能: M07-01 ネット買取管理 — 買取検索一覧 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘7件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md（ネット買取管理 — 買取検索一覧）
14. この工程で通過する機能: M07-01 ネット買取管理 — 買取検索一覧 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 通過する機能: M07-01 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「承認状況確認として、承諾内容を確認する」を実施する
【操作後確認】
5. ネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03） で対象キーと 処理後の画面表示 を記録する"	承諾内容を確認することを、承認状態と操作履歴で確認できること。	"確認場所: ネット買取管理 — 買取検索一覧（M07-01,M07-03） / 承認状態と操作履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 承諾内容を確認することを、承認状態と操作履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-012/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-012、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-01_admin_online_purchase_purchase_online_search_list.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-013	-	代替フロー	P1	代替系 #12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を行い「売却する選択を確認し、振込手続きを進めることを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
【操作後確認】
3. 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）で、売却する選択を確認し、振込手続きを進めることを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	売却する選択を確認し、振込手続きを進めることを、金額・決済状態と処理履歴で確認できること。	"確認場所: 分岐条件の判定結果と、進んだ経路（各分岐は代替/異常経路のシナリオで確認）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 売却する選択を確認し、振込手続きを進めることを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-013/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-013、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-014	-	代替フロー	P1	代替系 #13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を行い「振込依頼を行うことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「振込依頼として、振込依頼を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、振込依頼を行うことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	振込依頼を行うことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 振込依頼を行うことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-014/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-014、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-015	M07-03	代替フロー	P1	代替系 #14: 顧客戦略チームが「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を行い「買取状況が振込依頼済みになり、変更日時・変更者が履歴へ記録される」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で 同じ査定ID を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
【操作後確認】
4. 同じ査定ID で対象キーと 処理後の画面表示 を記録する"	買取状況が振込依頼済みになり、変更日時・変更者が履歴へ記録されること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 照合キー: 査定ID・顧客ID・振込依頼ID / 出典: scenario_test/markdown/14_ネット買取.md:78 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1797#sheet-11 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1798#sheet-11 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1799#sheet-11 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1827#sheet-11 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:1828#sheet-11 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html:2626#sheet-17
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 買取状況が振込依頼済みになり、変更日時・変更者が履歴へ記録されること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-015/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-015、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-016	-	代替フロー	P1	代替系 #15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を行い「経理チームが振込作業を行うことを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 店舗統括チーム
【準備確認】
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、経理チームが振込作業を行うことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する"	経理チームが振込作業を行うことを、金額・決済状態と処理履歴で確認できること。	"確認場所: 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 経理チームが振込作業を行うことを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-016/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-016、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-017	M07-03	代替フロー	P1	代替系 #16: 顧客戦略チームが「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を行い「完了報告を受けたら、振込完了に変更することを、金額・決済状態と処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	完了報告を受けたら、振込完了に変更することを、金額・決済状態と処理履歴で確認できること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / 金額・決済状態と処理履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 完了報告を受けたら、振込完了に変更することを、金額・決済状態と処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-017/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-017、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-018	M07-06	代替フロー	P1	代替系 #17: 顧客戦略チームが「カード仕入れ業務へとして、カード仕入れ業務へ」を行い「カード仕入れ業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-06_admin_online_purchase_purchase_online_product_list_csv_export.md（m07-06_admin_online_purchase_purchase_online_product_list_csv_export（管理画面_ネット買取管理_買取商品一覧CSV出力））"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: 使用機能に未解決の乖離指摘なし（drift_findings_list_open.tsv）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-06_admin_online_purchase_purchase_online_product_list_csv_export.md（m07-06_admin_online_purchase_purchase_online_product_list_csv_export（管理画面_ネット買取管理_買取商品一覧CSV出力））
【操作】
1. 管理画面で 管理画面_ネット買取管理_買取商品一覧CSV出力 を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
【操作後確認】
4. 管理画面_ネット買取管理_買取商品一覧CSV出力 で対象キーと 処理後の画面表示 を記録する"	カード仕入れ業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。	"確認場所: m07-06_admin_online_purchase_purchase_online_product_list_csv_export（管理画面_ネット買取管理_買取商品一覧CSV出力）（M07-06） / 画面表示・処理ステータス・処理履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: カード仕入れ業務へ進むことを、画面表示・処理ステータス・処理履歴で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-018/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-018、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-06_admin_online_purchase_purchase_online_product_list_csv_export.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-019	M07-03	代替フロー	P1	代替系 A1 #1: 通販チームが「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を行い「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できる」を確認する	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-A001
データパターン種別: 代替系
前提差分: MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施可能（ローカル環境）
- 判定根拠: システム外（現場）（EC-CUBEの実行可否とは無関係）
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号"	"データパターンID=DP-A001
種別=代替系
分岐ID=A1
目的=査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
入力=商品コード=ST-CARD-ONLINE-KAITORI-002-R04-A1 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施可能（ローカル環境）
2. 判定根拠: システム外（現場）（EC-CUBEの実行可否とは無関係）
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04-A1 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 分岐条件「MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。」を成立させる
4. 「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を実施する
【操作後確認】
5. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する"	まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移した
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-019/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-019、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-020	-	データ連鎖	P1	代替系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #29 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-01 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-01
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#30 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04。
【操作】
産出工程の完了直後に#29 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #30 ネット買取 の成果物 #29 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #29 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 産出工程 #30 ネット買取 の成果物 #29 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-020/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-020、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-01 / ネット買取 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-021	-	データ連鎖	P1	代替系 DL-02: 終端の成果物確認（後続工程への受け渡しは未判定） — #37 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-02
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-02 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-02
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-02。以下の#番号は原典ノード番号。産出=#36 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04。
【操作】
産出工程の完了直後に#37 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #36 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #37 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 産出工程 #36 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-021/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-021、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-02 / ネット買取 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-022	-	データ連鎖	P1	代替系 DL-03: 終端の成果物確認（後続工程への受け渡しは未判定） — #37 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-03
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-03 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-03
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-03。以下の#番号は原典ノード番号。産出=#39 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04。
【操作】
産出工程の完了直後に#37 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #39 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #37 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 産出工程 #39 ネット買取 の成果物 #37 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-022/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-022、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-03 / ネット買取 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-023	-	データ連鎖	P1	代替系 DL-04: 終端の成果物確認（後続工程への受け渡しは未判定） — #38 査定確認メール	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-04
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-04 / ネット買取 / パターン2 / 経路4 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-12 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-13"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-04
照合キー=買取番号＋送信したメール原本のMessage-ID"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-04。以下の#番号は原典ノード番号。産出=#39 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=買取番号＋送信したメール原本のMessage-ID。手動メール通知確認画面の買取番号・件名・本文と、買取詳細の依頼者メールアドレスを送信前に保存する。送信後のメール原本を買取番号と対応付け、To・件名・本文を比較する。メール本文に買取番号の記載を仮定しない。
【操作】
産出工程の完了直後に#38 査定確認メールをproducer原本として保存する。
産出原本から 買取番号・宛先メールアドレス・件名・本文 を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #39 ネット買取 の成果物 #38 査定確認メール の買取番号・宛先メールアドレス・件名・本文が、照合キー 買取番号＋送信したメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。	"確認場所: #38 査定確認メール
照合キー: 買取番号＋送信したメール原本のMessage-ID
合格条件: 産出工程 #39 ネット買取 の成果物 #38 査定確認メール の買取番号・宛先メールアドレス・件名・本文が、照合キー 買取番号＋送信したメール原本のMessage-ID に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-023/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-023、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-04 / ネット買取 / パターン2 / 経路4 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-12 / excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-13
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-024	-	データ連鎖	P1	代替系 DL-05: 終端の成果物確認（後続工程への受け渡しは未判定） — #42 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-05
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-05 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-05
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-05。以下の#番号は原典ノード番号。産出=#41 買取履歴、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04。
【操作】
産出工程の完了直後に#42 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #41 買取履歴 の成果物 #42 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #42 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 産出工程 #41 買取履歴 の成果物 #42 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-024/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-024、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-05 / ネット買取 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-025	-	データ連鎖	P1	代替系 DL-06: 終端の成果物確認（後続工程への受け渡しは未判定） — #52 ネット買取*1	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 実施保留（判定根拠確定待ち）
- 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 解除条件:  承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。
- 判定制約: 解除条件が満たされるまで未実施・保留と記録し、合格にしない。
- 連鎖ID: DL-06
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-06 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
連鎖ID=DL-06
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04"	"担当者: 通販チーム
【準備確認】
1. 実施区分: 実施保留（実行手段未特定）
2. 解除条件: ブロッカー=M07-04, M07-03, （機能未特定）査定承諾メール処理として、査定承諾メール送付処理が行; 判定不能=1; 未実装指摘あり=1; 実装違い指摘あり=5（feasibility_by_scenario.tsv）に対する機能Noと操作手段を確定する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、MTGバイヤー、メール のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R04（主要代替）の条件「査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 代替系#1: 顧客戦略チームが「買取カード受領として、郵送されてきたカードを受領」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
4. 代替系#2: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「到着した荷物の申込番号を確認し、ネット買取情報の状態を商品到着へ変更する」を実施する
   対象: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
5. 代替系#3: 顧客戦略チームが「カード仕分け作業として、「価格が付く」、「価格が付くかもしれない」、「価格が絶対につかない」 商品を表（スプレットシート）を使って仕分けを行う」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
6. 代替系#4: 顧客戦略チームが「カード査定作業開始として、「価格が付く」、「価格が付くかもしれない」、商品を査定に通す MTGバイヤーを使いカードの査定作業をおこなう ここで、カードをスタンダード範囲か範囲外か仕分けをおこなっている」を実施する
   対象: 査定金額=1,200円
7. 代替系#5: 支店担当者が「MTGバイヤー査定作業として、「査定前」のステータスの情報として登録されているので、 MTGバイヤーにて買取処理を進める」を実施する
   対象: 査定金額=1,200円
8. 代替系#6: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「MTGバイヤー査定結果確認として、MTGバイヤーからまとめて買い取りのカード情報を取り込み、まとめて買い取り欄の商品・数量・金額を照合して査定完了とする」を実施する
   対象: 数量=3
9. 代替系#7: 顧客戦略チームがネット買取管理 — 手動メール通知 ほか（M07-04・M07-03）で「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
   対象: 査定金額=1,200円
10. 代替系#8: お客様が「査定結果確認として、買取履歴で査定金額を確認し、売却するを選択する」を実施する
   対象: 査定金額=1,200円
11. 代替系#9: 支店担当者が「買取履歴の承諾を完了し、対象顧客への査定承諾メールを受信確認する（実施保留条件: 承諾確定はF06-15に設計あり。自動承諾メールの送信契機・テンプレート・宛先仕様は0305/0206/0507に特定できない。処理の存在を原典は記載するが専用メール契約は未確定。）」を実施する
   対象: 査定金額=1,200円
12. 代替系#10: お客様が「査定承諾メール受領として、査定承諾メールを受け取る」を実施する
   対象: 査定金額=1,200円
13. 代替系#11: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細） ほか（M07-01・M07-03）で「承認状況確認として、承諾内容を確認する」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
14. 代替系#12: 顧客戦略チームが「売却するか判定として、売却する選択を確認し、振込手続きを進める」を実施する
   対象: 査定金額=1,200円
15. 代替系#13: 顧客戦略チームが「振込依頼として、振込依頼を行う」を実施する
   対象: 査定金額=1,200円
16. 代替系#14: 顧客戦略チームが同じ査定IDで「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
   対象: 査定金額=1,200円
17. 代替系#15: 店舗統括チームが「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
   対象: 査定金額=1,200円
18. 代替系#16: 顧客戦略チームがネット買取管理 — 買取情報編集（買取詳細）で「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
   対象: 査定金額=1,200円
19. 代替系#17: 顧客戦略チームが管理画面_ネット買取管理_買取商品一覧CSV出力で「カード仕入れ業務へとして、カード仕入れ業務へ」を実施する
   対象: 商品コード=ST-CARD-ONLINE-KAITORI-002-R04
【操作後確認】
20. 最終業務状態「まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-06。以下の#番号は原典ノード番号。産出=#51 ネット買取、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04。
【操作】
産出工程の完了直後に#52 ネット買取*1をproducer原本として保存する。
産出原本から 原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録） を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #51 ネット買取 の成果物 #52 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。	"確認場所: #52 ネット買取*1
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 産出工程 #51 ネット買取 の成果物 #52 ネット買取*1 の原本にある全項目の項目名・値（更新対象列は更新前後を別々に記録）が、照合キー ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-025/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-025、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md データ連鎖 DL-06 / ネット買取 / パターン2 / 経路4
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-026	M07-04,M07-03	メール/通知	P1	代替系 工程#7 判定: 査定内容メール通知の宛先と対象案件	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
- 必須入力欄: 件名 / 本文
- この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
- 判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
- 判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md 実行手順 / ネット買取 / パターン2 / 経路4"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
判定用具体値: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 会員fixtureまたはゲスト注文時に登録した顧客emailを試験用受信箱へ対応付け、通知操作前の受信件数と時刻を記録する。本文に識別番号を含まない定型文は送信履歴の対象案件とMessage-IDを対応付ける。
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘2件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md（ネット買取管理 — 手動メール通知）
14. 必須入力欄: 件名 / 本文
15. この工程で通過する機能: M07-04 ネット買取管理 — 手動メール通知 → M07-03 ネット買取管理 — 買取情報編集（買取詳細）
【操作】
1. 管理画面で ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 通過する機能: M07-04 → M07-03。最初の機能から操作して後続画面へ進み、同じ対象データを使う
4. 「査定内容メール通知として、手動メール通知にて査定内容について顧客にお知らせする 査定内容連絡済みに、ステータス変更を行う ※査定が未完了の場合、査定内容連絡済みにステータス変更できない」を実施する
【操作後確認】
5. ネット買取管理 — 手動メール通知 ほか（M07-04・M07-03） で対象キーと 処理後の画面表示 を記録する
具体照合: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"	「査定内容メール通知」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。	"確認場所: ネット買取管理 — 手動メール通知（M07-04,M07-03） / 査定内容メール通知の受信原本・対象案件の通知履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 「査定内容メール通知」のメール原本の宛先が当該顧客のメールアドレスと一致し、当該案件の内容を受信箱で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-026/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-026、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-04_admin_online_purchase_purchase_manual_mail.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md 実行手順 / ネット買取 / パターン2 / 経路4
比較規則: 通知の契機となる操作の後、受信原本のTo・受信日時・件名・本文を保存する。宛先を顧客メールアドレスと比較し、本文または送信履歴から対象案件への対応を確認する。"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-027	-	金額整合	P1	代替系 工程#13 判定: 査定額と送料から振込額を照合	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
- 判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
判定用具体値: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「振込依頼として、振込依頼を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、振込依頼を行うことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する
具体照合: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"	申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。	"確認場所: ネット買取詳細・入金CSV・振込依頼・銀行受付結果
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-027/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-027、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）
比較規則: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-028	M07-03	金額整合	P1	代替系 工程#14 判定: 査定額と送料から振込額を照合	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
- 判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
- 判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
判定用具体値: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で 同じ査定ID を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「同じ査定IDを開き、本人確認条件を満たした顧客について経理へ振込を依頼し、買取状況を振込依頼済みに保存する」を実施する
【操作後確認】
4. 同じ査定ID で対象キーと 処理後の画面表示 を記録する
具体照合: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"	申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / ネット買取詳細・入金CSV・振込依頼・銀行受付結果
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-028/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-028、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）
比較規則: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-029	-	金額整合	P1	代替系 工程#15 判定: 査定額と送料から振込額を照合	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 業務担当環境で実施
- 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
- 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
- 判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
- 判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
判定用具体値: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。"	"担当者: 店舗統括チーム
【準備確認】
判定用準備: 試験用具体値: 査定単価1,000円×3枚=査定承諾額3,000円、送料500円。査定承諾済みの同一申込に設定する。受取人口座は試験用口座を用い、口座番号は原本と照合できる形で安全に保持する。
1. 実施区分: 業務担当環境で実施
2. 開始条件: 記載された外部サービス、帳票、現物および担当者権限を利用できる
3. 業務環境: EC-CUBE、MTGバイヤー、メール のうち操作文で名指しされたサービス、帳票または現物を利用できる
4. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
5. 対象状態: 操作文に記載されたサービス、帳票または現物を用意し、対象キーと入力値を記録する
【操作】
1. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
2. 「振込作業として、経理チームが振込作業を行う 完了したらトレードチームに完了報告を行う」を実施する
【操作後確認】
3. 現物・現品、チェック票/帳票の記入、数量、サイン（EC-CUBE の更新は発生しない）で、経理チームが振込作業を行うことを、金額・決済状態と処理履歴で確認できること。の実値と対象データ 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する の対応を記録する
具体照合: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"	申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。	"確認場所: ネット買取詳細・入金CSV・振込依頼・銀行受付結果
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 申込 ST-OBUY-ONLINE-KAITORI-002-R04 の振込依頼額が査定承諾額3,000円＋送料500円＝3,500円であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-029/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-029、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-6（振込金額=送料+査定額）
比較規則: 買取詳細の査定承諾額と送料、入金CSVの受注番号・振込金額、振込依頼の金額を同一申込で照合する。振込作業では同じ依頼額と銀行の受付結果を照合する。"
ネット買取 — ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）	STI-ONLINE-KAITORI-008-030	M07-03	状態遷移	P1	代替系 工程#16 判定: 振込完了を起点とした在庫待ち判定	"元シナリオ: SCN-ONLINE-KAITORI-ネット買取処理カード-008 ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）
業務: ネット買取
経路ID: R04
経路種別: 主要代替
業務経路条件: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」）
最終業務状態: まとめて買取欄の明細数量・査定金額が同じ申込の顧客回答と振込金額へ引き継がれ、全商品の実在庫登録済みを確認して入庫待ちへ遷移したことを確認できること。
主アクター: 通販チーム
関連システム: EC-CUBE、MTGバイヤー、メール
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 査定方式=まとめて買取、売却回答=承諾（原典本文 14_ネット買取.md R123–126「まとめて買い取りがある場合は、まとめて買い取りの欄に」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 MTGバイヤーでまとめて買取3枚・1,200円を査定し、全商品の実在庫登録を済ませ、同じ申込のまとめて買取欄と顧客回答を照合する。
シードデータ: 担当者アカウント=st-user-online-kaitori-002-r04 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 本人確認状態=確認済み / 査定対象商品=ST-CARD-ONLINE-KAITORI-002-R04 / 振込先=テスト銀行 普通 1234567 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
準備手順:
- 実施区分: 条件付き実施（既知の実装差あり）
- 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
- 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
- 判定用準備: 個別入力商品の実在庫登録を全件完了し、銀行の振込完了連絡を受領した同一申込を準備する。振込完了日・変更前状態を保存する。
- 判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-17（振込完了時の未登録在庫判定）"	"データパターンID=DP-N001
種別=正常系 代表
目的=主要代替の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
判定用具体値: 個別入力商品の実在庫登録を全件完了し、銀行の振込完了連絡を受領した同一申込を準備する。振込完了日・変更前状態を保存する。"	"担当者: 顧客戦略チーム
【準備確認】
判定用準備: 個別入力商品の実在庫登録を全件完了し、銀行の振込完了連絡を受領した同一申込を準備する。振込完了日・変更前状態を保存する。
1. 実施区分: 条件付き実施（既知の実装差あり）
2. 開始条件: 使用機能に実装違い指摘1件（drift_findings_list_open.tsv）を既知差分として期待値に採用するか、修正後に実施する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/online-kaitori-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-ONLINE-KAITORI-002-R04 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/online-kaitori-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-CARD-ONLINE-KAITORI-002-R04"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-CARD-ONLINE-KAITORI-002-R04 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-online-kaitori-002-r04 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md（ネット買取管理 — 買取情報編集（買取詳細））
14. 必須入力欄: 買取状況 / 選んで買取 › 数量（各行） / 氏名（姓） / 氏名（名） / 氏名カナ（姓） / 氏名カナ（名） / 郵便番号 / 住所1 / 住所2 / 電話番号 / E-mail / 職業 / 生年月日 / 口座情報 › 銀行名コード / 口座情報 › 支店名コード / 口座情報 › 口座種別 / 口座情報 › 口座番号 / 口座情報 › 口座名義 / 適格請求書 › 登録番号
【操作】
1. 管理画面で ネット買取管理 — 買取情報編集（買取詳細） を開く
2. 対象データ: 担当者アカウント=st-user-online-kaitori-002-r04 / 商品コード=ST-CARD-ONLINE-KAITORI-002-R04 / ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04 / 数量=3 / 店舗=晴れる屋テスト店舗 / 会員番号=ST-MEMBER-ONLINE-KAITORI-002-R04 / 査定方式=まとめて買取 / 対象枚数=3 / 査定金額=1,200円 / 査定回答=売却する
3. 「振込完了ステータス変更として、完了報告を受けたら、振込完了に変更」を実施する
【操作後確認】
4. ネット買取管理 — 買取情報編集（買取詳細） で対象キーと 処理後の画面表示 を記録する
具体照合: 振込完了への変更直後に買取詳細を再表示し、最終状態=入庫待ち、振込完了日と状態変更履歴を記録する。"	申込 ST-OBUY-ONLINE-KAITORI-002-R04 の個別入力商品に未登録在庫が無い場合、振込完了処理後の状態が「入庫待ち」であること。	"確認場所: ネット買取管理 — 買取情報編集（買取詳細）（M07-03） / ネット買取詳細・ステータス変更履歴
照合キー: ネット買取申込番号=ST-OBUY-ONLINE-KAITORI-002-R04
合格条件: 申込 ST-OBUY-ONLINE-KAITORI-002-R04 の個別入力商品に未登録在庫が無い場合、振込完了処理後の状態が「入庫待ち」であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-ONLINE-KAITORI-008-030/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-ONLINE-KAITORI-008-030、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m07-03_admin_online_purchase_purchase_online_buy_order_edit.md
業務結果根拠: scenario_test/scenario/SCN-ONLINE-KAITORI-ネット買取処理カード-008_ネット買取処理（カード受け取り後から振込までの業務）（まとめて買取明細から振込）.md / ネット買取 / パターン2 / 経路4
判定根拠: excel_to_html/output/0206_基本設計仕様書(ネット買取管理機能).html#sheet-17（振込完了時の未登録在庫判定）
比較規則: 振込完了への変更直後に買取詳細を再表示し、最終状態=入庫待ち、振込完了日と状態変更履歴を記録する。"
```
