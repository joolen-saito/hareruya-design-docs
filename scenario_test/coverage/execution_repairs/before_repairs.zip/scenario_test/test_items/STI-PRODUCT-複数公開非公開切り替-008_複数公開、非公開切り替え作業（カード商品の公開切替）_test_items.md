<!-- generated-by: hareruya-scenario-test-items -->
# 商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替） シナリオ試験テストケース

元シナリオ: `scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md`

テスト観点: 業務フロー準拠のシステムテスト観点（正常系／代替系／異常系、データ更新・外部連携・CSV/帳票・メール/通知・権限・バリデーション等）

期待結果は画面表示、遷移、ステータス、履歴、件数、金額、CSV/帳票、メール/通知、外部連携結果、操作履歴など、試験で観測できる結果で判定する。TSV は 11 列固定で、`テストレベル` 列は含めない。`期待結果／レスポンス` は受け身・状態・可能表現で記載する。

## 実施方式

- 各行は `前提条件` の `準備手順`、`操作手順/実行方法` の `【準備確認】→【操作】→【操作後確認】`、`確認対象` の `合格条件/不合格条件` の順に実施する。
- `st-user-*`、`ST-*` はシナリオ上の論理IDである。fixture応答の実ID・受注番号・emailとの対応を `scenario_test/exec/test_result_template.tsv` に記録する。
- `実施不可（設計確定待ち）` と `実施保留（実行手段未特定）` は、記載された解除条件が満たされるまで実行開始しない。`条件付き実施` は既知指摘の影響判定を記録してから開始する。
- 実行証跡は `scenario_test/exec/evidence/<テストID>/` に保存する。

## 関連機能No対応概要

| 機能No | 状態 | I/FID出力 | 本シナリオでの主な確認範囲 / 理由 |
|--------|------|------------|------------------------------------|
| M14-01 | テスト項目化 | あり | CSV/帳票 |
| M14-04 | テスト項目化 | あり | CSV/帳票 |
| M14-05 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M14-06 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M14-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-26 | テスト項目化 | あり | CSV/帳票 |
| M03-03 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-01 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-02 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-08 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-09 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-20 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-27 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-35 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |
| M03-38 | 参照のみ | なし | 期待機能Noとして関連するが、このシナリオのI/FIDには割り当てない。期待機能不足はシナリオカバレッジ表で可視化する。 |

## テストケースTSV

以下はタブ区切りで、実質はExcelのCSVと同様に、改行や`"`を含むセルはダブルクォートで囲む。

**1行目**が列見出し。**2行目以降**がケース（各11列）。`機能名` 列に業務名とシナリオ名を入れ、`I/FID` 列に当該ステップが行使する機能No（メインフローの利用画面・機能）を入れる。`期待結果／レスポンス` はシステム結果として読める受け身・状態・可能表現にし、「〜されること。」「〜されないこと。」「〜できること。」「〜であること。」のいずれかで終える。`確認対象` は観測点を別列で持つ。`テストID`で一意に識別する。優先度は **P1／P2／P3**。

Excel／Googleスプレッドシートへはコードフェンス内を A1 に貼り付ける。

前提条件・入力データ・操作手順など、**期待結果以外**の列で複数項目がある場合は、同一セル内でLF改行する。

**期待結果／レスポンスは1行1判定**とする。複数の期待がある場合は行を分割し、**テスト項目名は当該行の判定内容が分かるよう具体化**する。

`前提条件`、`入力データ/リクエスト内容`、`操作手順/実行方法`、`期待結果／レスポンス` が同一になる行は重複テストとして出力しない。

```tsv
機能名	テストID	I/FID	テスト観点	優先度	テスト項目名	前提条件	入力データ/リクエスト内容	操作手順/実行方法	期待結果／レスポンス	確認対象
商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替）	STI-PRODUCT-008-001	-	業務経路	P1	正常系 経路全体 R01: 正常代表として「同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できる」を確認する	"元シナリオ: SCN-PRODUCT-複数公開非公開切り替-008 複数公開、非公開切り替え作業（カード商品の公開切替）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）
最終業務状態: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コード2件と対象外商品1件を用意し、対象2件だけをCSVに記載する。商品種別に対応した登録画面を使う。
シードデータ: 担当者アカウント=st-user-product-008-r01 / 会員番号=ST-MEMBER-PRODUCT-008-R01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=カード / 切替前=非公開 / 切替後=公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M14-01, M03-26, M14-04; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M14-01, M03-26, M14-04; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
3. 正常系#1: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「対象商品データダウンロードとして、商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」 からcsvファイルをダウンロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
4. 正常系#2: 顧客戦略チームが商品管理 — カード商品CSV登録で「CSV調整対応として、CSVファイル内の公開ステータスを変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
5. 正常系#3: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「公開ステータス変更として、カード商品CSV登録へ公開ステータス変更CSVをアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
【操作後確認】
6. 最終業務状態「同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する"	同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。	"確認場所: 出力されたCSV/帳票の件数と内容 / 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。 / 経路内の各画面・API応答・外部サービス・帳票・現物と最終業務状態
照合キー: 商品コード=ST-PRODUCT-PRODUCT-008-R01
合格条件: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-008-001/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-008-001、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md / 商品登録・編集 / パターン8 / 経路1"
商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替）	STI-PRODUCT-008-002	M14-01	CSV/帳票	P1	正常系 #1: 顧客戦略チームが「対象商品データダウンロードとして、商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」 からcsvファイルをダウンロードする」を行い「商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」が完了したことを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-複数公開非公開切り替-008 複数公開、非公開切り替え作業（カード商品の公開切替）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）
最終業務状態: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コード2件と対象外商品1件を用意し、対象2件だけをCSVに記載する。商品種別に対応した登録画面を使う。
シードデータ: 担当者アカウント=st-user-product-008-r01 / 会員番号=ST-MEMBER-PRODUCT-008-R01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=カード / 切替前=非公開 / 切替後=公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md（カード管理 — カード検索（一覧・条件抽出））
【操作】
1. 管理画面で カード管理 — カード検索（一覧・条件抽出） を開く
2. 対象データ: 担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
3. 「対象商品データダウンロードとして、商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」 からcsvファイルをダウンロードする」を実施する
【操作後確認】
4. カード管理 — カード検索（一覧・条件抽出） で対象キーと 処理後の画面表示 を記録する"	商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — カード検索（一覧・条件抽出）（M14-01） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-008-R01
合格条件: 商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」が完了したことを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-008-002/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-008-002、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-01_admin_card_card_search.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md / 商品登録・編集 / パターン8 / 経路1"
商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替）	STI-PRODUCT-008-003	M03-26	CSV/帳票	P1	正常系 #2: 顧客戦略チームが「CSV調整対応として、CSVファイル内の公開ステータスを変更する」を行い「CSVファイル内の公開ステータスを変更することを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-複数公開非公開切り替-008 複数公開、非公開切り替え作業（カード商品の公開切替）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）
最終業務状態: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コード2件と対象外商品1件を用意し、対象2件だけをCSVに記載する。商品種別に対応した登録画面を使う。
シードデータ: 担当者アカウント=st-user-product-008-r01 / 会員番号=ST-MEMBER-PRODUCT-008-R01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=カード / 切替前=非公開 / 切替後=公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
- 必須入力欄: CSV ファイル"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘1件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md（商品管理 — カード商品CSV登録）
14. 必須入力欄: CSV ファイル
【操作】
1. 管理画面で 商品管理 — カード商品CSV登録 を開く
2. 対象データ: 担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
3. 「CSV調整対応として、CSVファイル内の公開ステータスを変更する」を実施する
【操作後確認】
4. 商品管理 — カード商品CSV登録 で対象キーと 処理後の画面表示 を記録する"	CSVファイル内の公開ステータスを変更することを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: 商品管理 — カード商品CSV登録（M03-26） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-008-R01
合格条件: CSVファイル内の公開ステータスを変更することを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-008-003/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-008-003、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m03-26_admin_product_product_card_csv_import.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md / 商品登録・編集 / パターン8 / 経路1"
商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替）	STI-PRODUCT-008-004	M14-04	CSV/帳票	P1	正常系 #3: 顧客戦略チームが「公開ステータス変更として、カード商品CSV登録へ公開ステータス変更CSVをアップロードする」を行い「カード商品CSV登録へ公開ステータス変更CSVをアップロードすることを、出力されたCSV/帳票の件数と内容で確認できる」を確認する	"元シナリオ: SCN-PRODUCT-複数公開非公開切り替-008 複数公開、非公開切り替え作業（カード商品の公開切替）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）
最終業務状態: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コード2件と対象外商品1件を用意し、対象2件だけをCSVに記載する。商品種別に対応した登録画面を使う。
シードデータ: 担当者アカウント=st-user-product-008-r01 / 会員番号=ST-MEMBER-PRODUCT-008-R01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=カード / 切替前=非公開 / 切替後=公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
- 認証: http://localhost:8080/admin/login に admin / password でログインする
- 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
- 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開"	"担当者: 顧客戦略チーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: 使用機能に未実装指摘3件（drift_findings_list_open.tsv・機能単位のため当該工程に当たるかは要判断）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
10. 認証: http://localhost:8080/admin/login に admin / password でログインする
11. 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
12. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
13. 設計根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md（カード管理 — 新規登録・編集・削除（詳細フォーム））
14. 必須入力欄: カード名(英) / 点数で見たマナコスト / フォーマット（リーガリティ各行） / リーガリティ（制限区分、各行） / レアリティ / レイアウト / プロモ種別 / 言語（画像各行） / 表面／裏面（画像各行）
【操作】
1. 管理画面で カード管理 — 新規登録・編集・削除（詳細フォーム） を開く
2. 対象データ: 担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
3. 「公開ステータス変更として、カード商品CSV登録へ公開ステータス変更CSVをアップロードする」を実施する
【操作後確認】
4. カード管理 — 新規登録・編集・削除（詳細フォーム） で対象キーと 保存しました を記録する"	カード商品CSV登録へ公開ステータス変更CSVをアップロードすることを、出力されたCSV/帳票の件数と内容で確認できること。	"確認場所: カード管理 — 新規登録・編集・削除（詳細フォーム）（M14-04） / 出力されたCSV/帳票の件数と内容
照合キー: 商品コード=ST-PRODUCT-PRODUCT-008-R01
合格条件: カード商品CSV登録へ公開ステータス変更CSVをアップロードすることを、出力されたCSV/帳票の件数と内容で確認できること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
成功表示候補（設計書）: 保存しました
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-008-004/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-008-004、実施日時、実施者、実値、合否、証跡パスを記録する
判定根拠: functions/pf-eccube3/m14-04_admin_card_card_register_update_delete.md
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md / 商品登録・編集 / パターン8 / 経路1"
商品登録・編集 — 複数公開、非公開切り替え作業（カード商品の公開切替）	STI-PRODUCT-008-005	-	データ連鎖	P1	正常系 DL-01: 終端の成果物確認（後続工程への受け渡しは未判定） — #81 商品*6	"元シナリオ: SCN-PRODUCT-複数公開非公開切り替-008 複数公開、非公開切り替え作業（カード商品の公開切替）
業務: 商品登録・編集
経路ID: R01
経路種別: 正常代表
業務経路条件: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）
最終業務状態: 同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。
主アクター: トレードチーム
関連システム: EC-CUBE、AWS S3、在庫管理
データパターンID: DP-N001
データパターン種別: 正常系 代表
前提差分: 商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」） 標準権限の担当者でログインし、標準マスタと基準シードデータを使用する。 対象商品コード2件と対象外商品1件を用意し、対象2件だけをCSVに記載する。商品種別に対応した登録画面を使う。
シードデータ: 担当者アカウント=st-user-product-008-r01 / 会員番号=ST-MEMBER-PRODUCT-008-R01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 公開状態=非公開 / 商品種別=カード / 切替前=非公開 / 切替後=公開
準備手順:
- 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
- 開始条件: ブロッカー=M14-01, M03-26, M14-04; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
- 環境起動: cd ../ec-cube-enterprise
- 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
- 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
- fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
- 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
- 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
- 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
- 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
- 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
- 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
- 連鎖ID: DL-01
- 対象範囲: 終端の成果物確認（後続工程への受け渡しは未判定）
- 原典判定: 終端（消費先の記載なし・完了条件で観測）
- 判定根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md データ連鎖 DL-01 / 商品登録・編集 / パターン8 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22"	"データパターンID=DP-N001
種別=正常系 代表
目的=正常代表の代表データで業務経路を確認する。
入力=担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
連鎖ID=DL-01
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）"	"担当者: トレードチーム
【準備確認】
1. 実施区分: 条件付き実施（未実装指摘の影響判定が前提）
2. 開始条件: ブロッカー=M14-01, M03-26, M14-04; 未実装指摘あり=3（feasibility_by_scenario.tsv）を工程に照合し、対象外または対応済みと記録する
3. 環境起動: cd ../ec-cube-enterprise
4. 環境起動: docker compose -f docker-compose.yml -f docker-compose.pgsql.yml -f docker-compose.dev.yml up -d --wait
5. 基準データ: docker compose exec ec-cube bin/console eccube:seed:card
6. 基準データ: docker compose exec ec-cube bin/console eccube:seed:product
7. fixture準備: curl -sS -c /tmp/product-008-fixture.cookie http://localhost:8080/fixture/get_mall_role
8. 会員準備: curl -sS -b /tmp/product-008-fixture.cookie -X POST http://localhost:8080/fixture/customer を実行し、応答のid/emailを論理ID ST-MEMBER-PRODUCT-008-R01 に対応付ける（ログインPW=password）
9. 商品準備: curl -sS -b /tmp/product-008-fixture.cookie -H 'Content-Type: application/json' -d '{""product_name"":""ST-PRODUCT-PRODUCT-008-R01"",""product_class_num"":1}' http://localhost:8080/fixture/product/product/create を実行し、応答のid/商品規格IDを ST-PRODUCT-PRODUCT-008-R01 に対応付ける
10. 認証（管理画面）: http://localhost:8080/admin/login に admin / password でログインする
11. 業務環境: EC-CUBE、AWS S3、在庫管理 のうち経路で使用する外部サービス、帳票または現物を利用できる
12. 担当者識別子: st-user-product-008-r01 は証跡用の実施者IDとし、EC-CUBEのログインIDには使用しない
13. 対象状態: 操作前に対象キーで対象データを開き、入力データ記載の初期状態と一致することを確認する
【操作】
1. 経路ID R01（正常代表）の条件「商品種別=カード（原典本文 09_商品登録・編集.md R216–227「カード商品の場合は、「カード商品CSV登録」」）」を満たすことを確認する
2. 経路代表データ: 担当者アカウント=st-user-product-008-r01 / 商品コード=ST-PRODUCT-PRODUCT-008-R01 / 数量=3 / 店舗=晴れる屋テスト店舗 / カテゴリ=テストカテゴリ / 販売価格=500円 / 商品種別=カード / 切替前=非公開 / 切替後=公開
3. 正常系#1: 顧客戦略チームがカード管理 — カード検索（一覧・条件抽出）で「対象商品データダウンロードとして、商品マスターから該当する商品を検索し「(カードorグッズ)商品CSV出力」 からcsvファイルをダウンロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
4. 正常系#2: 顧客戦略チームが商品管理 — カード商品CSV登録で「CSV調整対応として、CSVファイル内の公開ステータスを変更する」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
5. 正常系#3: 顧客戦略チームがカード管理 — 新規登録・編集・削除（詳細フォーム）で「公開ステータス変更として、カード商品CSV登録へ公開ステータス変更CSVをアップロードする」を実施する
   対象: 商品コード=ST-PRODUCT-PRODUCT-008-R01
【操作後確認】
6. 最終業務状態「同じ商品コード群の公開ステータスが指定した公開/非公開へ変わり、対象外の商品は変更されないことを確認できること。」を対象キーで確認し、各工程の証跡を同じテストIDの証跡フォルダへ保存する
【準備確認】
連鎖ID=DL-01。以下の#番号は原典ノード番号。産出=#82 商品登録CSV、消費=終端（業務フロー図に消費先の記載なし）。
照合キー=商品ID＋商品規格ID（商品コードとの実ID対応を保存）。当該工程の登録または更新結果から実商品ID・商品規格IDを取得し、シードの商品コードとの対応を保存する。新規登録時は操作前の不存在と登録後の採番結果を記録する。
【操作】
産出工程の完了直後に#81 商品*6をproducer原本として保存する。
産出原本から 商品ID・商品規格ID・商品コード を読み取り、対象シードに対応付けた作業元の確定値（入力原本・出力対象の元明細・送信前プレビュー）と項目ごとに比較する。消費先の同一性を合格扱いしない。
【操作後確認】
照合表に項目名、産出値、消費値または対象シード値、差分、原本パスを記録する。"	産出工程 #82 商品登録CSV の成果物 #81 商品*6 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。	"確認場所: #81 商品*6
照合キー: 商品ID＋商品規格ID（商品コードとの実ID対応を保存）
合格条件: 産出工程 #82 商品登録CSV の成果物 #81 商品*6 の商品ID・商品規格ID・商品コードが、照合キー 商品ID＋商品規格ID（商品コードとの実ID対応を保存） に対応する作業元の確定値と一致する状態であること。
不合格条件: 照合キーが一致しない、期待した状態を観測できない、または処理エラーが残る場合は不合格とする。
証跡保存先: scenario_test/exec/evidence/STI-PRODUCT-008-005/
必須証跡: before.png / after.png / result.txt（API・CSV・メール・ログ・現物は該当する原本または写真）
判定記録: scenario_test/exec/test_result_template.tsv に STI-PRODUCT-008-005、実施日時、実施者、実値、合否、証跡パスを記録する
業務結果根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md / 商品登録・編集 / パターン8 / 経路1
判定根拠: scenario_test/scenario/SCN-PRODUCT-複数公開非公開切り替-008_複数公開、非公開切り替え作業（カード商品の公開切替）.md データ連鎖 DL-01 / 商品登録・編集 / パターン8 / 経路1 / excel_to_html/output/0204_基本設計仕様書(商品管理).html#sheet-22
連鎖判定: 終端（消費先の記載なし・完了条件で観測）
必須照合証跡: producer原本 / consumer原本（連鎖ありの場合） / comparison.tsv"
```
